"""Version-pinned UIA selectors for the BOSS desktop client.

The pre-form path resolves these with native UIA property conditions.  Do not
replace that resolver with pywinauto ``child_window`` or Python-side descendant
scans: the Electron UIA tree is large, slow, and ambiguous.
"""

from __future__ import annotations

from typing import Any, Final


VERIFIED_BOSS_VERSION: Final = "1.7.4.963"
SELECTOR_PROFILE: Final = "boss-1.7.4.963-native-uia-four-recruitment-v1"

JOBS_NAV: Final[dict[str, Any]] = {
    "title": "职位",
    "control_type": "Hyperlink",
}

# Anchor on the exact child text.  The parent Button's private-use icon is
# front-end generated and must not be part of the stable selector.
PUBLISH_JOB: Final[dict[str, Any]] = {
    "title": "发布职位",
    "control_type": "Text",
}

# In the draft prompt this visually button-like action is exposed as Text.
REPUBLISH: Final[dict[str, Any]] = {
    "title": "重新发布",
    "control_type": "Text",
}

UNSAVED_NAVIGATION_PROMPT: Final[dict[str, Any]] = {
    "title": "内容尚未保存，确定放弃？",
    "control_type": "Text",
}

KEEP_EDITING: Final[dict[str, Any]] = {
    "title": "取消",
    "control_type": "Text",
}

DISCARD_EDITING: Final[dict[str, Any]] = {
    "title": "确定",
    "control_type": "Text",
}

ADDRESS_SELECTOR_PROMPT: Final[dict[str, Any]] = {
    "title": "请选择工作地址",
    "control_type": "Text",
}

PHONE_EXCHANGE_TOGGLE: Final[dict[str, Any]] = {
    "control_type": "CheckBox",
}

FORM_RECRUITMENT_LABEL: Final[dict[str, Any]] = {
    "title": "招聘类型",
    "control_type": "Text",
}

FORM_TITLE_LABEL: Final[dict[str, Any]] = {
    "title": "职位名称",
    "control_type": "Text",
}

FORM_TITLE_EDIT: Final[dict[str, Any]] = {
    "control_type": "Edit",
    "found_index": 0,
}

FORM_TERMS_LINK: Final[dict[str, Any]] = {
    "title": "《招聘行为管理规范》",
    "control_type": "Hyperlink",
}

FORM_SCROLL_ANCHORS: Final[tuple[dict[str, Any], ...]] = (
    {"title": "职位类型", "control_type": "Text"},
    {"title": "元/天", "control_type": "Text"},
    {"title": "工作地址", "control_type": "Text"},
    {"title": "实习要求", "control_type": "Text"},
    {"title": "经验", "control_type": "Text"},
    {"title": "薪资范围", "control_type": "Text"},
    {"title": "兼职时间", "control_type": "Text"},
    {"title": "招聘截止时间", "control_type": "Text"},
    FORM_TERMS_LINK,
)

FINAL_PUBLISH: Final[dict[str, Any]] = {
    "title": "发布",
    "control_type": "Button",
}

LOGIN_PROBES: Final[tuple[dict[str, Any], ...]] = (
    {"title": "扫码登录", "control_type": "Text"},
    {"title": "登录 BOSS直聘", "control_type": "Text"},
    {"title": "手机号登录", "control_type": "Text"},
)

ACCESSIBILITY_PROBES: Final[tuple[tuple[str, dict[str, Any]], ...]] = (
    ("职位", JOBS_NAV),
    ("发布职位", PUBLISH_JOB),
    ("重新发布", REPUBLISH),
    ("招聘类型", FORM_RECRUITMENT_LABEL),
)
