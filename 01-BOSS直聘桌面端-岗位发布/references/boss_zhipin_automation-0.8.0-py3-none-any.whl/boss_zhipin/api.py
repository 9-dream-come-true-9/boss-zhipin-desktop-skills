from __future__ import annotations

import hashlib
import hmac
import importlib.metadata
import secrets
import sys
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from .adapter import BossUIAdapter, normalize_field_value, normalize_ui_text
from .config import BossConfig, DEFAULT_CONFIG
from .catalogs import RecruitmentType
from .diagnostics import Diagnostics
from .errors import (
    ConfirmationInvalid,
    ConfirmationRequired,
    ErrorContext,
    PublishOutcomeUnknown,
    ReadbackMismatch,
    RunStateError,
    ValidationError,
)
from .models import (
    FieldEvidence,
    JobPostSpec,
    PrepareOptions,
    PreparedJob,
    PublishFormReady,
    PublishReceipt,
    RunStatus,
    new_run_id,
)
from .session import BossSession, inspect_environment as _inspect_environment
from .state import RunStore, utc_now_iso
from .uielements import SELECTOR_PROFILE
from ._version import RUNTIME_BUILD_ID, __version__
from .waits import wait_until


def _evidence_dict(evidence: tuple[FieldEvidence, ...]) -> list[dict[str, Any]]:
    return [
        {
            "field": item.field,
            "expected": item.expected,
            "actual": item.actual,
            "verified": item.verified,
        }
        for item in evidence
    ]


def _evidence_hash(evidence: tuple[FieldEvidence, ...]) -> str:
    payload = "\n".join(
        f"{item.field}\0{normalize_field_value(item.field, item.expected)}\0"
        f"{normalize_field_value(item.field, item.actual)}\0{int(item.verified)}"
        for item in evidence
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _parse_evidence(items: list[dict[str, Any]]) -> tuple[FieldEvidence, ...]:
    return tuple(
        FieldEvidence(
            field=str(item["field"]),
            expected=str(item["expected"]),
            actual=str(item["actual"]),
            verified=bool(item["verified"]),
        )
        for item in items
    )


def _receipt(record: dict[str, Any], *, message: str | None = None) -> PublishReceipt:
    spec = JobPostSpec.from_dict(record["spec"])
    status = RunStatus(record["status"])
    return PublishReceipt(
        run_id=record["run_id"],
        status=status,
        title=spec.title,
        company=record.get("company"),
        verified=status is RunStatus.SUCCEEDED,
        submitted_at=record.get("submitted_at"),
        message=message or record.get("message") or status.value,
        artifact_dir=record.get("artifact_dir"),
    )


def _validate_idempotency_key(value: str) -> str:
    key = value.strip()
    if not 8 <= len(key) <= 200:
        raise ValidationError("idempotency_key 长度必须在 8 到 200 个字符之间")
    return key


def _error_details(exc: Exception) -> dict[str, Any]:
    as_dict = getattr(exc, "as_dict", None)
    if callable(as_dict):
        details = as_dict()
        if isinstance(details, dict):
            return details
    return {
        "code": type(exc).__name__,
        "message": str(exc),
    }


def _runtime_provenance() -> dict[str, str]:
    try:
        distribution_version = importlib.metadata.version("boss-zhipin-automation")
    except importlib.metadata.PackageNotFoundError:
        distribution_version = "<not-installed>"
    return {
        "runtime_version": __version__,
        "distribution_version": distribution_version,
        "runtime_build_id": RUNTIME_BUILD_ID,
        "selector_profile": SELECTOR_PROFILE,
        "module_path": str(Path(__file__).resolve()),
        "python_executable": sys.executable,
    }


def open_publish_form(
    *,
    options: PrepareOptions | None = None,
    config: BossConfig = DEFAULT_CONFIG,
) -> PublishFormReady:
    """Open a clean job form without filling fields or clicking final Publish."""

    opts = options or PrepareOptions()
    run_id = new_run_id()
    diagnostics = Diagnostics(
        run_id,
        requested_dir=opts.artifact_dir,
        config=config,
    )
    diagnostics.event("runtime_provenance", **_runtime_provenance())
    started = time.perf_counter()
    session = BossSession(
        config=config,
        timeout=opts.timeout_seconds,
        maximize=opts.maximize_window,
        restart_for_accessibility=False,
    )
    try:
        session.connect()
        adapter = BossUIAdapter(session=session, diagnostics=diagnostics)
        republish_clicked = adapter.open_publish_form()
        result = PublishFormReady(
            app_version=session.version,
            ready=True,
            republish_clicked=republish_clicked,
            elapsed_seconds=round(time.perf_counter() - started, 3),
            artifact_dir=str(diagnostics.directory),
        )
        diagnostics.event("publish_form_ready", **result.as_dict())
        return result
    except Exception as exc:
        if session.window is not None:
            diagnostics.capture(session.window, "open-form-failed")
        diagnostics.event("open_form_failed", error=_error_details(exc))
        raise


def _prepared_from_record(
    record: dict[str, Any],
    *,
    idempotency_key: str,
    token: str = "",
) -> PreparedJob:
    return PreparedJob(
        run_id=record["run_id"],
        idempotency_key=idempotency_key,
        status=RunStatus(record["status"]),
        spec_hash=record["spec_hash"],
        company=record.get("company"),
        evidence=_parse_evidence(record.get("evidence", [])),
        warnings=tuple(record.get("warnings", [])),
        confirmation_token=token,
        confirmation_expires_at=str(record.get("confirmation_expires_at") or ""),
        artifact_dir=record.get("artifact_dir"),
    )


def prepare_job_post(
    spec: JobPostSpec | dict[str, Any],
    *,
    idempotency_key: str,
    options: PrepareOptions | None = None,
    config: BossConfig = DEFAULT_CONFIG,
) -> PreparedJob:
    """Fill and verify a job form, returning a REVIEW_READY record."""

    normalized = (
        JobPostSpec.from_dict(spec) if isinstance(spec, dict) else spec.normalized()
    )
    key = _validate_idempotency_key(idempotency_key)
    opts = options or PrepareOptions()
    store = RunStore(config)
    key_hash = hashlib.sha256(key.encode("utf-8")).hexdigest()
    spec_hash = normalized.spec_hash()

    with store.locked():
        existing = store.find_by_idempotency(key)
        if existing and existing.get("spec_hash") != spec_hash:
            raise RunStateError(
                "同一个 idempotency_key 已绑定到不同职位内容",
                context=ErrorContext(
                    details={
                        "run_id": existing.get("run_id"),
                        "existing_spec_hash": existing.get("spec_hash"),
                        "requested_spec_hash": spec_hash,
                    }
                ),
            )
        if existing and existing.get("status") == RunStatus.SUCCEEDED.value:
            raise RunStateError(
                "该幂等键对应的职位已经发布成功，不能重新准备",
                context=ErrorContext(details={"run_id": existing["run_id"]}),
            )
        if existing and existing.get("status") in {
            RunStatus.SUBMITTING.value,
            RunStatus.COMMIT_UNKNOWN.value,
        }:
            raise RunStateError(
                "该幂等键处于提交中或结果未知；请调用 reconcile_job_post，禁止重新填写",
                context=ErrorContext(details={"run_id": existing["run_id"]}),
            )

        run_id = existing["run_id"] if existing else new_run_id()
        diagnostics = Diagnostics(
            run_id,
            requested_dir=opts.artifact_dir,
            config=config,
        )
        record: dict[str, Any] = existing or {
            "run_id": run_id,
            "idempotency_hash": key_hash,
            "spec": normalized.canonical_dict(),
            "spec_hash": spec_hash,
            "status": RunStatus.NEW.value,
            "submit_clicked": False,
            "token_consumed": False,
        }
        record.update(
            {
                "status": RunStatus.PREPARING.value,
                "artifact_dir": str(diagnostics.directory),
                "error": None,
                "error_details": None,
                "message": "正在准备职位表单",
                "prepare_options": {
                    "restart_for_accessibility": opts.restart_for_accessibility,
                    "maximize_window": opts.maximize_window,
                    "timeout_seconds": opts.timeout_seconds,
                },
            }
        )
        if existing:
            store.save(record)
        else:
            store.create(record)
        diagnostics.event("runtime_provenance", **_runtime_provenance())
        diagnostics.event(
            "prepare_started",
            spec_hash=spec_hash,
            recruitment_type=normalized.recruitment_type.value,
            title=normalized.title,
            description=normalized.description,
        )

        session = BossSession(
            config=config,
            timeout=opts.timeout_seconds,
            maximize=opts.maximize_window,
            restart_for_accessibility=opts.restart_for_accessibility,
        )
        try:
            session.connect()
            adapter = BossUIAdapter(session=session, diagnostics=diagnostics)
            adapter.open_publish_form()
            company = adapter.company_name()
            if normalized.expected_company:
                if not company or normalize_ui_text(normalized.expected_company) not in normalize_ui_text(company):
                    raise ReadbackMismatch(
                        "当前招聘公司与 expected_company 不一致",
                        context=ErrorContext(
                            step="verify_company",
                            details={
                                "expected": normalized.expected_company,
                                "actual": company,
                            },
                        ),
                    )

            adapter.select_recruitment_type(normalized.recruitment_type)
            adapter.fill_title_and_choose_suggestion(normalized.title)
            adapter.fill_description(normalized.description)
            if normalized.recruitment_type is RecruitmentType.SOCIAL_FULL_TIME:
                assert normalized.experience is not None
                adapter.select_experience(normalized.experience.value)
                adapter.select_social_fulltime_education(normalized.education.value)
            elif normalized.recruitment_type is RecruitmentType.PART_TIME:
                assert normalized.experience is not None
                adapter.select_experience(normalized.experience.value)
                adapter.select_education(normalized.education.value)
            else:
                adapter.select_education(normalized.education.value)
            adapter.select_salary(normalized)
            if normalized.recruitment_type is RecruitmentType.PART_TIME:
                assert normalized.part_time is not None
                adapter.select_part_time_settlement(normalized.part_time.settlement)
                adapter.select_part_time_schedule(
                    normalized.part_time.work_date,
                    normalized.part_time.work_period,
                    normalized.part_time.days_per_week,
                    normalized.part_time.work_hours,
                    normalized.part_time.shifts,
                )
                adapter.select_recruitment_deadline(
                    normalized.part_time.recruitment_deadline
                )
            if normalized.recruitment_type is RecruitmentType.CAMPUS:
                assert normalized.graduation_year_start is not None
                assert normalized.graduation_year_end is not None
                adapter.select_graduation_year_range(
                    str(normalized.graduation_year_start),
                    str(normalized.graduation_year_end),
                )
            if normalized.recruitment_type is RecruitmentType.INTERNSHIP:
                assert normalized.internship is not None
                adapter.select_internship_requirements(
                    normalized.internship.minimum_months,
                    normalized.internship.days_per_week,
                )
            address = adapter.ensure_address(normalized)
            adapter.set_phone_exchange(normalized.phone_exchange)
            adapter.verify_terms_notice()
            evidence = adapter.review(normalized, address)

            warnings: list[str] = []
            if normalized.phone_exchange is None:
                warnings.append("电话交换助手未指定，已保留当前状态。")
            if opts.restart_for_accessibility:
                warnings.append("本次允许在语义控件不可用时重启 BOSS 以启用可访问性。")
            record.update(
                {
                    "status": RunStatus.REVIEW_READY.value,
                    "company": company,
                    "address": address,
                    "evidence": _evidence_dict(evidence),
                    "evidence_hash": _evidence_hash(evidence),
                    "warnings": warnings,
                    "confirmation_token_hash": None,
                    "confirmation_expires_at": None,
                    "token_consumed": False,
                    "message": "表单已填充并逐字段回读；按当前任务要求继续内部授权或结束",
                }
            )
            store.save(record)
            diagnostics.event(
                "review_ready",
                company=company or "",
                evidence_hash=record["evidence_hash"],
            )
            return _prepared_from_record(
                record,
                idempotency_key=key,
            )
        except Exception as exc:
            if session.window is not None:
                diagnostics.capture(session.window, "prepare-failed")
            record.update(
                {
                    "status": RunStatus.FAILED_SAFE.value,
                    "message": "提交前安全失败，未点击发布",
                    "error": repr(exc),
                    "error_details": _error_details(exc),
                }
            )
            store.save(record)
            diagnostics.event("prepare_failed", error=_error_details(exc))
            raise


def authorize_job_post(
    run_id: str,
    *,
    config: BossConfig = DEFAULT_CONFIG,
) -> PreparedJob:
    """Issue a short-lived internal token for a REVIEW_READY job."""

    store = RunStore(config)
    with store.locked():
        record = store.load(run_id)
        if record["status"] != RunStatus.REVIEW_READY.value:
            raise RunStateError(f"运行状态不是 REVIEW_READY：{record['status']}")
        if record.get("token_consumed"):
            raise ConfirmationInvalid("该运行的发布授权令牌已经使用")
        token = secrets.token_urlsafe(32)
        expires = datetime.now(UTC) + timedelta(
            seconds=config.confirmation_ttl_seconds
        )
        record.update(
            {
                "confirmation_token_hash": hashlib.sha256(
                    token.encode("utf-8")
                ).hexdigest(),
                "confirmation_expires_at": expires.isoformat(),
                "message": "REVIEW_READY 已验证；内部短时发布授权令牌已签发",
            }
        )
        store.save(record)
        diagnostics = Diagnostics(run_id, config=config)
        if record.get("artifact_dir"):
            diagnostics.directory = Path(record["artifact_dir"])
            diagnostics.directory.mkdir(parents=True, exist_ok=True)
            diagnostics.log_path = diagnostics.directory / "events.jsonl"
        diagnostics.event(
            "publish_authorized",
            confirmation_expires_at=record["confirmation_expires_at"],
        )
        return _prepared_from_record(
            record,
            idempotency_key="<redacted>",
            token=token,
        )


def publish_prepared_job(
    run_id: str,
    *,
    confirmation_token: str,
    config: BossConfig = DEFAULT_CONFIG,
) -> PublishReceipt:
    """Re-verify a prepared form, click Publish at most once, and verify outcome."""

    if not confirmation_token:
        raise ConfirmationRequired(
            "必须先为 REVIEW_READY 运行签发内部发布授权令牌"
        )
    store = RunStore(config)
    with store.locked():
        record = store.load(run_id)
        if record["status"] == RunStatus.SUCCEEDED.value:
            return _receipt(record, message="该运行已发布成功，未重复点击")
        if record["status"] in {
            RunStatus.SUBMITTING.value,
            RunStatus.COMMIT_UNKNOWN.value,
        }:
            raise RunStateError(
                "提交动作已经开始，禁止再次点击；请调用 reconcile_job_post",
                context=ErrorContext(details={"run_id": run_id}),
            )
        if record["status"] != RunStatus.REVIEW_READY.value:
            raise RunStateError(f"运行状态不是 REVIEW_READY：{record['status']}")
        if record.get("token_consumed"):
            raise ConfirmationInvalid("发布授权令牌已经使用")
        expected_hash = str(record.get("confirmation_token_hash", ""))
        supplied_hash = hashlib.sha256(confirmation_token.encode("utf-8")).hexdigest()
        if not hmac.compare_digest(expected_hash, supplied_hash):
            raise ConfirmationInvalid("发布授权令牌不匹配")
        try:
            expires = datetime.fromisoformat(record["confirmation_expires_at"])
        except (KeyError, ValueError) as exc:
            raise ConfirmationInvalid("发布授权令牌记录损坏") from exc
        if datetime.now(UTC) >= expires:
            raise ConfirmationInvalid(
                "发布授权令牌已过期；重新回读表单后再签发"
            )

        spec = JobPostSpec.from_dict(record["spec"])
        prepare_options = record.get("prepare_options") or {}
        diagnostics = Diagnostics(
            run_id,
            requested_dir=None,
            config=config,
        )
        if record.get("artifact_dir"):
            diagnostics.directory = Path(record["artifact_dir"])
            diagnostics.directory.mkdir(parents=True, exist_ok=True)
            diagnostics.log_path = diagnostics.directory / "events.jsonl"
        session = BossSession(
            config=config,
            timeout=float(
                prepare_options.get("timeout_seconds", config.default_timeout_seconds)
            ),
            maximize=bool(prepare_options.get("maximize_window", True)),
            restart_for_accessibility=False,
        )
        try:
            session.connect()
            adapter = BossUIAdapter(session=session, diagnostics=diagnostics)
            if not adapter.is_publish_form():
                raise ConfirmationInvalid(
                    "发布表单已不在当前窗口；为防止错发，发布授权失效"
                )
            company = adapter.company_name()
            if normalize_ui_text(company or "") != normalize_ui_text(record.get("company") or ""):
                raise ConfirmationInvalid("当前公司/账号上下文发生变化")
            evidence = adapter.review(spec, str(record["address"]))
            if _evidence_hash(evidence) != record.get("evidence_hash"):
                raise ConfirmationInvalid("表单内容在 REVIEW_READY 后发生变化")
            adapter.verify_terms_notice()

            record.update(
                {
                    "status": RunStatus.SUBMITTING.value,
                    "token_consumed": True,
                    "submit_started_at": utc_now_iso(),
                    "message": "已进入 at-most-once 提交边界",
                }
            )
            store.save(record)
            diagnostics.event("submit_boundary_entered")
            try:
                adapter.click_publish_once()
                record["submit_clicked"] = True
                record["submit_clicked_at"] = utc_now_iso()
                store.save(record)
            except Exception as exc:
                record.update(
                    {
                        "status": RunStatus.COMMIT_UNKNOWN.value,
                        "message": "发布点击或回传结果不明确，禁止自动重试",
                        "error": repr(exc),
                        "error_details": _error_details(exc),
                    }
                )
                store.save(record)
                diagnostics.capture(session.window, "submit-action-unknown")
                raise PublishOutcomeUnknown(
                    "发布动作结果不明确；请调用 reconcile_job_post，切勿再次发布",
                    context=ErrorContext(
                        step="publish_once",
                        artifact_dir=str(diagnostics.directory),
                    ),
                ) from exc

            try:
                wait_until(
                    lambda: adapter.success_marker(spec.title),
                    timeout=session.wait_timeout,
                    description="发布成功标志或职位列表记录",
                )
            except Exception as exc:
                record.update(
                    {
                        "status": RunStatus.COMMIT_UNKNOWN.value,
                        "message": "已点击发布，但未能证明成功或失败",
                        "error": repr(exc),
                        "error_details": _error_details(exc),
                    }
                )
                store.save(record)
                diagnostics.capture(session.window, "publish-outcome-unknown")
                raise PublishOutcomeUnknown(
                    "已点击发布但结果未知；请调用 reconcile_job_post，禁止再次点击发布",
                    context=ErrorContext(
                        step="verify_publish",
                        artifact_dir=str(diagnostics.directory),
                    ),
                ) from exc

            record.update(
                {
                    "status": RunStatus.SUCCEEDED.value,
                    "submitted_at": utc_now_iso(),
                    "message": "职位发布成功且已通过界面标志验证",
                    "error": None,
                }
            )
            store.save(record)
            diagnostics.event("publish_verified", title=spec.title)
            return _receipt(record)
        except (ConfirmationInvalid, PublishOutcomeUnknown):
            raise
        except Exception as exc:
            # Before the at-most-once boundary, failure is safe. After it, the run
            # has already been marked SUBMITTING and must be reconciled.
            latest = store.load(run_id)
            if latest.get("status") == RunStatus.SUBMITTING.value:
                latest.update(
                    {
                        "status": RunStatus.COMMIT_UNKNOWN.value,
                        "message": "提交边界后的异常导致结果未知",
                        "error": repr(exc),
                        "error_details": _error_details(exc),
                    }
                )
                store.save(latest)
                raise PublishOutcomeUnknown(
                    "提交边界后的结果未知；请调用 reconcile_job_post"
                ) from exc
            raise


def publish_reviewed_job(
    run_id: str,
    *,
    config: BossConfig = DEFAULT_CONFIG,
) -> PublishReceipt:
    """Publish a REVIEW_READY job without a second user-confirmation step."""

    record = RunStore(config).load(run_id)
    if record["status"] == RunStatus.SUCCEEDED.value:
        return _receipt(record, message="该运行已发布成功，未重复点击")
    authorized = authorize_job_post(run_id, config=config)
    return publish_prepared_job(
        run_id,
        confirmation_token=authorized.confirmation_token,
        config=config,
    )


def reconcile_job_post(
    run_id: str,
    *,
    config: BossConfig = DEFAULT_CONFIG,
) -> PublishReceipt:
    """Read only: reconcile a prior unknown submission without clicking Publish."""

    store = RunStore(config)
    with store.locked():
        record = store.load(run_id)
        if record["status"] == RunStatus.SUCCEEDED.value:
            return _receipt(record, message="职位已验证发布成功")
        if record["status"] not in {
            RunStatus.SUBMITTING.value,
            RunStatus.COMMIT_UNKNOWN.value,
        }:
            raise RunStateError(
                f"只有 SUBMITTING/COMMIT_UNKNOWN 运行可以核对：{record['status']}"
            )
        spec = JobPostSpec.from_dict(record["spec"])
        prepare_options = record.get("prepare_options") or {}
        diagnostics = Diagnostics(run_id, config=config)
        if record.get("artifact_dir"):
            diagnostics.directory = Path(record["artifact_dir"])
            diagnostics.directory.mkdir(parents=True, exist_ok=True)
            diagnostics.log_path = diagnostics.directory / "events.jsonl"
        session = BossSession(
            config=config,
            timeout=float(
                prepare_options.get("timeout_seconds", config.default_timeout_seconds)
            ),
            maximize=bool(prepare_options.get("maximize_window", True)),
            restart_for_accessibility=False,
        )
        session.connect()
        adapter = BossUIAdapter(session=session, diagnostics=diagnostics)
        found = adapter.reconcile_title(spec.title)
        if found:
            record.update(
                {
                    "status": RunStatus.SUCCEEDED.value,
                    "submitted_at": record.get("submitted_at") or utc_now_iso(),
                    "message": "通过职位列表精确标题核对为已发布",
                    "error": None,
                }
            )
            store.save(record)
            diagnostics.event("reconcile_succeeded", title=spec.title)
            return _receipt(record)
        record.update(
            {
                "status": RunStatus.COMMIT_UNKNOWN.value,
                "message": "职位列表尚未找到精确标题；未执行任何提交动作",
            }
        )
        store.save(record)
        diagnostics.event("reconcile_inconclusive", title=spec.title)
        return _receipt(record)


def get_run_status(
    run_id: str,
    *,
    config: BossConfig = DEFAULT_CONFIG,
) -> dict[str, Any]:
    record = RunStore(config).load(run_id)
    return {
        "run_id": record["run_id"],
        "status": record["status"],
        "spec_hash": record.get("spec_hash"),
        "company": record.get("company"),
        "message": record.get("message"),
        "submitted_at": record.get("submitted_at"),
        "artifact_dir": record.get("artifact_dir"),
        "evidence": record.get("evidence", []),
        "warnings": record.get("warnings", []),
    }


def inspect_environment(config: BossConfig = DEFAULT_CONFIG) -> Any:
    return _inspect_environment(config)


class BossJobs:
    open_publish_form = staticmethod(open_publish_form)
    prepare_job_post = staticmethod(prepare_job_post)
    authorize_job_post = staticmethod(authorize_job_post)
    publish_prepared_job = staticmethod(publish_prepared_job)
    publish_reviewed_job = staticmethod(publish_reviewed_job)
    reconcile_job_post = staticmethod(reconcile_job_post)
    get_run_status = staticmethod(get_run_status)
    inspect_environment = staticmethod(inspect_environment)
