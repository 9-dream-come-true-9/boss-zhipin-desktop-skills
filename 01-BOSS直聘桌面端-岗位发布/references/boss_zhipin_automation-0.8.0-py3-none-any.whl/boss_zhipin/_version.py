from __future__ import annotations

__version__ = "0.8.0"
RUNTIME_BUILD_ID = "boss-job-publishing-20260812-internship-social-campus-parttime-v1"
