from __future__ import annotations

import contextlib
import re
import time
import unicodedata
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import date
from typing import Any

from .catalogs import (
    DAILY_SALARY_OPTIONS,
    EXPERIENCE_OPTIONS,
    GRADUATION_YEAR_OPTIONS,
    MONTHLY_SALARY_OPTIONS,
    PART_TIME_DAYS_PER_WEEK_OPTIONS,
    PART_TIME_SALARY_MAX_OPTIONS,
    PART_TIME_SALARY_MIN_OPTIONS,
    PART_TIME_SALARY_UNIT_OPTIONS,
    PART_TIME_SETTLEMENT_OPTIONS,
    PART_TIME_SHIFT_OPTIONS,
    PART_TIME_WORK_DATE_OPTIONS,
    PART_TIME_WORK_HOURS_OPTIONS,
    PART_TIME_WORK_PERIOD_OPTIONS,
    EDUCATION_OPTIONS,
    INTERNSHIP_DAY_OPTIONS,
    INTERNSHIP_MONTH_OPTIONS,
    RecruitmentType,
)
from .diagnostics import Diagnostics
from .errors import (
    AmbiguousElement,
    ElementNotFound,
    ErrorContext,
    FocusLost,
    FormRejected,
    ReadbackMismatch,
)
from .models import FieldEvidence, JobPostSpec
from .session import BossSession
from .uielements import (
    ADDRESS_SELECTOR_PROMPT,
    DISCARD_EDITING,
    FINAL_PUBLISH,
    FORM_RECRUITMENT_LABEL,
    FORM_SCROLL_ANCHORS,
    FORM_TERMS_LINK,
    FORM_TITLE_EDIT,
    FORM_TITLE_LABEL,
    JOBS_NAV,
    KEEP_EDITING,
    PHONE_EXCHANGE_TOGGLE,
    PUBLISH_JOB,
    REPUBLISH,
    UNSAVED_NAVIGATION_PROMPT,
)
from .waits import wait_until


ARROW_GLYPHS = ""
PLACEHOLDERS = {
    "title": "请填写职位名称",
    "description": "请勿填写QQ",
    "experience": "请选择经验要求",
    "education": "请选择最低学历",
    "salary": "最低月薪",
    "address": "选择工作地点",
    "internship_months": "最少实习月数",
    "internship_days": "最少周到岗天数",
}


def normalize_ui_text(value: str) -> str:
    value = unicodedata.normalize("NFKC", value or "")
    for glyph in ARROW_GLYPHS:
        value = value.replace(glyph, "")
    return re.sub(r"\s+", "", value).strip()


def normalize_description_text(value: str) -> str:
    """Normalize only line endings; spaces and paragraph breaks are evidence."""

    return (value or "").replace("\r\n", "\n").replace("\r", "\n").strip()


def normalize_field_value(field: str, value: str) -> str:
    if field == "description":
        return normalize_description_text(value)
    return normalize_ui_text(value)


def _control_type(control: Any) -> str:
    with contextlib.suppress(Exception):
        return str(control.element_info.control_type or "")
    with contextlib.suppress(Exception):
        return str(control.control_type() or "")
    return ""


def _rectangle(control: Any) -> Any:
    try:
        return control.rectangle()
    except Exception as exc:
        raise ElementNotFound("控件没有可用边界") from exc


def _rect_tuple(rect: Any) -> tuple[int, int, int, int]:
    return (int(rect.left), int(rect.top), int(rect.right), int(rect.bottom))


def _visible(control: Any) -> bool:
    try:
        rect = control.rectangle()
        return control.is_visible() and rect.width() > 1 and rect.height() > 1
    except Exception:
        return False


@dataclass(frozen=True)
class _AddressModal:
    prompt: Any
    address_header: Any
    region_header: Any
    operation_header: Any
    use_action: Any
    document_key: tuple[Any, ...]
    bounds: tuple[int, int, int, int]


@dataclass
class BossUIAdapter:
    session: BossSession
    diagnostics: Diagnostics

    @property
    def timeout(self) -> float:
        return self.session.wait_timeout

    def _all(
        self,
        control_type: str | None = None,
        *,
        visible_only: bool = True,
    ) -> list[Any]:
        window = self.session.fresh_window()
        try:
            controls = (
                window.descendants(control_type=control_type)
                if control_type
                else window.descendants()
            )
        except Exception as exc:
            raise ElementNotFound(
                "无法读取 BOSS 控件树",
                context=ErrorContext(step="enumerate_controls"),
            ) from exc
        if visible_only:
            return [control for control in controls if _visible(control)]
        return list(controls)

    def _text(self, control: Any) -> str:
        with contextlib.suppress(Exception):
            return str(control.window_text() or "").strip()
        return ""

    def _find_texts(
        self,
        expected: str,
        *,
        exact: bool = True,
        control_types: Iterable[str] = ("Text", "Hyperlink", "Button", "Edit"),
        predicate: Callable[[Any], bool] | None = None,
        visible_only: bool = True,
    ) -> list[Any]:
        wanted = normalize_ui_text(expected)
        matches: list[Any] = []
        for control_type in control_types:
            for control in self._all(control_type, visible_only=visible_only):
                actual = normalize_ui_text(self._text(control))
                matched = actual == wanted if exact else wanted in actual
                if matched and (predicate is None or predicate(control)):
                    matches.append(control)
        unique: dict[tuple[int, int, int, int, str], Any] = {}
        for control in matches:
            try:
                rect = _rectangle(control)
            except ElementNotFound:
                continue
            key = (rect.left, rect.top, rect.right, rect.bottom, _control_type(control))
            unique[key] = control
        return list(unique.values())

    def _unique(
        self,
        controls: list[Any],
        *,
        label: str,
        prefer: Callable[[Any], tuple[Any, ...]] | None = None,
    ) -> Any:
        if not controls:
            raise ElementNotFound(
                f"找不到控件：{label}",
                context=ErrorContext(selector=label),
            )
        if len(controls) == 1:
            return controls[0]
        if prefer:
            ranked = sorted(controls, key=prefer)
            if prefer(ranked[0]) != prefer(ranked[1]):
                return ranked[0]
        raise AmbiguousElement(
            f"控件不唯一：{label}（{len(controls)} 个）",
            context=ErrorContext(
                selector=label,
                details={
                    "matches": [
                        {
                            "text": self._text(control),
                            "type": _control_type(control),
                            "rect": list(_rect_tuple(_rectangle(control))),
                        }
                        for control in controls
                    ]
                },
            ),
        )

    def _exists_text(self, value: str, *, exact: bool = True) -> bool:
        return bool(self._find_texts(value, exact=exact))

    def _fixed_controls(self, selector: dict[str, Any]) -> list[Any]:
        return self._fixed_controls_with_visibility(selector, visible_only=True)

    def _fixed_controls_with_visibility(
        self,
        selector: dict[str, Any],
        *,
        visible_only: bool,
    ) -> list[Any]:
        criteria = dict(selector)
        found_index = criteria.pop("found_index", None)
        controls = list(self.session.find_fixed_controls(criteria))
        if visible_only:
            controls = [control for control in controls if _visible(control)]
        if found_index is not None:
            if found_index < 0 or found_index >= len(controls):
                return []
            return controls[found_index : found_index + 1]
        return controls

    def _fixed_exists(self, selector: dict[str, Any]) -> bool:
        return bool(self._fixed_controls(selector))

    def _fixed_exists_any_visibility(self, selector: dict[str, Any]) -> bool:
        return bool(
            self._fixed_controls_with_visibility(selector, visible_only=False)
        )

    def _fixed_control(
        self,
        selector: dict[str, Any],
        *,
        label: str,
        timeout: float | None = None,
    ) -> Any:
        try:
            controls = wait_until(
                lambda: self._fixed_controls(selector),
                timeout=self.timeout if timeout is None else timeout,
                interval=0.1,
                description=f"固定控件出现：{label}",
                retryable=(Exception,),
            )
            if len(controls) != 1:
                raise AmbiguousElement(
                    f"固定控件不唯一：{label}（{len(controls)} 个）",
                    context=ErrorContext(
                        selector=label,
                        details={"uia": dict(selector)},
                    ),
                )
            return controls[0]
        except Exception as exc:
            if isinstance(exc, AmbiguousElement):
                raise
            raise ElementNotFound(
                f"找不到固定控件：{label}",
                context=ErrorContext(
                    selector=label,
                    details={"uia": dict(selector)},
                ),
            ) from exc

    def _click(self, control: Any, *, step: str) -> None:
        self.session.focus()
        self._bring_into_view(control)
        try:
            control.click_input()
        except Exception as exc:
            raise FocusLost(
                f"点击失败：{step}",
                context=ErrorContext(step=step, selector=self._text(control)),
            ) from exc
        self.diagnostics.event("click", step=step, text=self._text(control))

    def _control_key(self, control: Any) -> tuple[Any, ...]:
        try:
            runtime_id = tuple(control.element_info.runtime_id or ())
        except Exception:
            runtime_id = ()
        if runtime_id:
            return ("runtime_id", *runtime_id)
        return ("object_id", id(control))

    def _ancestor_chain(self, control: Any, *, limit: int = 12) -> list[Any]:
        result: list[Any] = []
        current = control
        for _ in range(limit):
            if current is None:
                break
            result.append(current)
            try:
                current = current.parent()
            except Exception:
                break
        return result

    def _document_key(self, control: Any) -> tuple[Any, ...]:
        for candidate in self._ancestor_chain(control):
            if _control_type(candidate) == "Document":
                return self._control_key(candidate)
        raise ElementNotFound(
            "控件不属于可识别的 UIA Document",
            context=ErrorContext(step="scope_semantic_control"),
        )

    def _same_or_related_control(self, first: Any, second: Any) -> bool:
        first_key = self._control_key(first)
        second_key = self._control_key(second)
        first_ancestors = {
            self._control_key(item)
            for item in self._ancestor_chain(first)[1:]
        }
        second_ancestors = {
            self._control_key(item)
            for item in self._ancestor_chain(second)[1:]
        }
        return (
            first_key == second_key
            or first_key in second_ancestors
            or second_key in first_ancestors
        )

    def _control_at_point(self, x: int, y: int) -> Any:
        from pywinauto import Desktop

        return Desktop(backend="uia").from_point(x, y)

    def _activate_semantically_or_safe_click(
        self,
        control: Any,
        *,
        document_key: tuple[Any, ...],
        bounds: tuple[int, int, int, int],
        step: str,
    ) -> str:
        if self._document_key(control) != document_key:
            raise FocusLost(
                f"控件已离开预期语义作用域：{step}",
                context=ErrorContext(step=step),
            )
        rect = _rectangle(control)
        center_x = int((rect.left + rect.right) / 2)
        center_y = int((rect.top + rect.bottom) / 2)
        left, top, right, bottom = bounds
        if (
            not _visible(control)
            or not control.is_enabled()
            or not (left <= center_x <= right and top <= center_y <= bottom)
        ):
            raise FocusLost(
                f"控件不可安全激活：{step}",
                context=ErrorContext(
                    step=step,
                    details={
                        "rect": list(_rect_tuple(rect)),
                        "scope_bounds": list(bounds),
                    },
                ),
            )
        pattern_errors: dict[str, str] = {}
        for method, attribute, action in (
            ("uia_invoke_pattern", "iface_invoke", "Invoke"),
            (
                "uia_selection_item_pattern",
                "iface_selection_item",
                "Select",
            ),
        ):
            try:
                pattern = getattr(control, attribute)
                getattr(pattern, action)()
                self.diagnostics.event(
                    "activate_scoped_control",
                    step=step,
                    text=self._text(control),
                    method=method,
                )
                return method
            except Exception as exc:
                pattern_errors[method] = repr(exc)
        try:
            hit = self._control_at_point(center_x, center_y)
        except Exception as exc:
            pattern_errors["uia_hit_test"] = repr(exc)
            hit = None
        if hit is None or not self._same_or_related_control(hit, control):
            raise FocusLost(
                f"控件中心命中验证失败，未点击：{step}",
                context=ErrorContext(
                    step=step,
                    details={
                        "rect": list(_rect_tuple(rect)),
                        "scope_bounds": list(bounds),
                        "semantic_errors": pattern_errors,
                    },
                ),
            )
        self._click(control, step=step)
        self.diagnostics.event(
            "activate_scoped_control",
            step=step,
            text=self._text(control),
            method="semantic_wrapper_click_after_uia_hit_test",
        )
        return "semantic_wrapper_click_after_uia_hit_test"

    def _bring_into_view(self, control: Any) -> None:
        if _visible(control):
            return
        try:
            scroll_item = getattr(control, "iface_scroll_item", None)
        except Exception:
            scroll_item = None
        if scroll_item is not None:
            with contextlib.suppress(Exception):
                scroll_item.ScrollIntoView()
                time.sleep(0.1)
                return
        with contextlib.suppress(Exception):
            control.scroll_into_view()
            time.sleep(0.1)

    def navigate_to_jobs(self) -> bool:
        """Navigate to Jobs; return True when an unsaved form was preserved."""

        if self._fixed_exists(PUBLISH_JOB):
            return False
        target = self._fixed_control(
            JOBS_NAV,
            label="左侧导航/职位",
        )
        self._click(target, step="navigate_jobs")
        outcome = wait_until(
            lambda: (
                "unsaved_prompt"
                if self._fixed_exists(UNSAVED_NAVIGATION_PROMPT)
                else "jobs_page"
                if self._fixed_exists(PUBLISH_JOB)
                else False
            ),
            timeout=self.timeout,
            interval=0.1,
            description="职位管理页或未保存内容提示出现",
            retryable=(Exception,),
        )
        if outcome == "unsaved_prompt":
            self._cancel_unsaved_navigation_if_present()
            return True
        return False

    def _publish_job_button(self) -> Any:
        anchor = self._fixed_control(
            PUBLISH_JOB,
            label="职位管理页/发布职位文字锚点",
        )
        try:
            button = anchor.parent()
        except Exception as exc:
            raise ElementNotFound(
                "发布职位文字锚点没有可用父控件",
                context=ErrorContext(
                    selector="发布职位 Text -> parent Button",
                ),
            ) from exc
        if _control_type(button) != "Button" or not _visible(button):
            raise ElementNotFound(
                "发布职位文字锚点的父控件不是可见 Button",
                context=ErrorContext(
                    selector="发布职位 Text -> parent Button",
                    details={"actual_parent_type": _control_type(button)},
                ),
            )
        return button

    def _click_republish_if_present(self) -> bool:
        if not self._fixed_exists(REPUBLISH):
            return False
        target = self._fixed_control(
            REPUBLISH,
            label="未发布职位提示/重新发布",
            timeout=min(2.0, self.timeout),
        )
        self._click(target, step="republish_unpublished_draft")
        self._wait_for_stable_clean_form(
            description="重新发布后新职位表单稳定",
        )
        return True

    def _form_markers_present(self) -> bool:
        return (
            self._fixed_exists(FORM_RECRUITMENT_LABEL)
            and self._fixed_exists(FORM_TITLE_EDIT)
        )

    def _form_semantics_present(self) -> bool:
        """Recognize a scrolled form without requiring top fields to be visible."""

        if self._form_markers_present():
            return True
        if not (
            self._fixed_exists_any_visibility(FORM_RECRUITMENT_LABEL)
            and self._fixed_exists_any_visibility(FORM_TITLE_LABEL)
        ):
            return False
        visible_body_anchors = sum(
            bool(self._fixed_exists(selector))
            for selector in FORM_SCROLL_ANCHORS
        )
        return visible_body_anchors >= 2

    def _resolve_unsaved_cancel(
        self,
    ) -> tuple[Any, tuple[Any, ...], tuple[int, int, int, int]]:
        prompt = self._fixed_control(
            UNSAVED_NAVIGATION_PROMPT,
            label="未保存内容提示",
            timeout=min(2.0, self.timeout),
        )
        prompt_rect = _rectangle(prompt)
        document_key = self._document_key(prompt)
        cancels = self._fixed_controls(KEEP_EDITING)
        confirms = self._fixed_controls(DISCARD_EDITING)
        pairs: list[tuple[Any, Any]] = []
        for cancel in cancels:
            cancel_rect = _rectangle(cancel)
            if (
                self._document_key(cancel) != document_key
                or cancel_rect.top < prompt_rect.bottom
                or cancel_rect.top > prompt_rect.bottom + 240
            ):
                continue
            for confirm in confirms:
                confirm_rect = _rectangle(confirm)
                if (
                    self._document_key(confirm) == document_key
                    and confirm_rect.top >= prompt_rect.bottom
                    and confirm_rect.top <= prompt_rect.bottom + 240
                    and abs(confirm_rect.top - cancel_rect.top) <= 24
                    and cancel_rect.left < confirm_rect.left
                    and cancel_rect.left >= prompt_rect.left
                    and confirm_rect.right <= prompt_rect.right + 500
                ):
                    pairs.append((cancel, confirm))
        if len(pairs) != 1:
            error_type = ElementNotFound if not pairs else AmbiguousElement
            raise error_type(
                "未保存内容提示内的“取消/确定”操作组不唯一",
                context=ErrorContext(
                    step="keep_unsaved_publish_form",
                    details={
                        "cancel_count": len(cancels),
                        "confirm_count": len(confirms),
                        "scoped_pair_count": len(pairs),
                    },
                ),
            )
        cancel, confirm = pairs[0]
        confirm_rect = _rectangle(confirm)
        bounds = (
            prompt_rect.left - 80,
            prompt_rect.top - 80,
            max(prompt_rect.right, confirm_rect.right) + 80,
            confirm_rect.bottom + 80,
        )
        return cancel, document_key, bounds

    def _cancel_unsaved_navigation_if_present(self) -> bool:
        if not self._fixed_exists(UNSAVED_NAVIGATION_PROMPT):
            return False
        cancel, document_key, bounds = self._resolve_unsaved_cancel()
        self._activate_semantically_or_safe_click(
            cancel,
            document_key=document_key,
            bounds=bounds,
            step="keep_unsaved_publish_form",
        )
        wait_until(
            lambda: not self._fixed_exists(UNSAVED_NAVIGATION_PROMPT),
            timeout=min(5.0, self.timeout),
            interval=0.1,
            description="未保存内容提示关闭",
            retryable=(Exception,),
        )
        wait_until(
            self._form_semantics_present,
            timeout=min(5.0, self.timeout),
            interval=0.1,
            description="取消放弃后发布表单保留",
            retryable=(Exception,),
        )
        return True

    def _wait_for_stable_clean_form(
        self,
        *,
        description: str,
        stable_seconds: float = 5.0,
    ) -> None:
        stable_since: float | None = None
        required_stable = min(stable_seconds, max(0.1, self.timeout / 4))

        def stable() -> bool:
            nonlocal stable_since
            if self._fixed_exists(REPUBLISH) or not self._form_markers_present():
                stable_since = None
                return False
            if stable_since is None:
                stable_since = time.monotonic()
            return time.monotonic() - stable_since >= required_stable

        wait_until(
            stable,
            timeout=self.timeout,
            interval=0.1,
            description=description,
            retryable=(Exception,),
        )

    def _wait_for_stable_existing_form(
        self,
        *,
        description: str,
        stable_seconds: float = 1.0,
    ) -> None:
        stable_since: float | None = None
        required_stable = min(stable_seconds, max(0.1, self.timeout / 4))

        def stable() -> bool:
            nonlocal stable_since
            if (
                self._fixed_exists(REPUBLISH)
                or self._fixed_exists(UNSAVED_NAVIGATION_PROMPT)
                or not self._form_semantics_present()
            ):
                stable_since = None
                return False
            if stable_since is None:
                stable_since = time.monotonic()
            return time.monotonic() - stable_since >= required_stable

        wait_until(
            stable,
            timeout=self.timeout,
            interval=0.1,
            description=description,
            retryable=(Exception,),
        )

    def _wait_for_form_or_draft_prompt(self) -> None:
        stable_form_since: float | None = None
        required_stable = min(5.0, max(0.1, self.timeout / 4))

        def ready() -> bool:
            nonlocal stable_form_since
            if self._fixed_exists(REPUBLISH):
                return True
            if self._form_markers_present():
                if stable_form_since is None:
                    stable_form_since = time.monotonic()
                # BOSS can mount the form, remove it during a second render,
                # then mount the final form.  Require a continuous window.
                return time.monotonic() - stable_form_since >= required_stable
            stable_form_since = None
            return False

        wait_until(
            ready,
            timeout=self.timeout,
            interval=0.1,
            description="发布职位表单或未发布职位提示出现",
            retryable=(Exception,),
        )

    def open_publish_form(self) -> bool:
        """Open a clean publish form; return whether “重新发布” was clicked."""

        if self._cancel_unsaved_navigation_if_present():
            self._wait_for_stable_existing_form(
                description="保留的发布职位表单稳定",
            )
            return False
        if self._address_selector_open():
            self._select_unique_saved_address()
            self._wait_for_stable_existing_form(
                description="选择账号地址后的发布职位表单稳定",
            )
            return False
        if self._click_republish_if_present():
            return True
        if self._fixed_exists(PUBLISH_JOB):
            target = self._publish_job_button()
        else:
            if self.is_publish_form():
                self._wait_for_stable_existing_form(
                    description="现有发布职位表单稳定",
                )
                return False
            if self.navigate_to_jobs():
                self._wait_for_stable_existing_form(
                    description="取消离开后的发布职位表单稳定",
                )
                return False
            target = self._publish_job_button()
        self._click(target, step="open_publish_form")
        self._wait_for_form_or_draft_prompt()
        if self._click_republish_if_present():
            return True
        return False

    def _is_publish_form_once(self) -> bool:
        return (
            not self._fixed_exists(REPUBLISH)
            and not self._fixed_exists(UNSAVED_NAVIGATION_PROMPT)
            and not self._fixed_exists(ADDRESS_SELECTOR_PROMPT)
            and self._form_semantics_present()
        )

    def is_publish_form(self) -> bool:
        try:
            return bool(
                wait_until(
                    self._is_publish_form_once,
                    timeout=min(3.0, self.timeout),
                    interval=0.1,
                    description="确认发布职位表单",
                    retryable=(Exception,),
                )
            )
        except Exception:
            return False

    def _find_edit(
        self,
        text: str,
        *,
        contains: bool,
        required: bool = True,
    ) -> Any | None:
        candidates = self._find_texts(
            text,
            exact=not contains,
            control_types=("Edit",),
        )
        if not candidates:
            if required:
                raise ElementNotFound(
                    f"找不到输入框：{text}",
                    context=ErrorContext(selector=f"Edit:{text}"),
                )
            return None
        return self._unique(
            candidates,
            label=f"Edit:{text}",
            prefer=lambda item: (_rectangle(item).top, _rectangle(item).left),
        )

    def _edit_for_label(
        self,
        label: str,
        *,
        placeholder: str | None = None,
        required: bool = True,
    ) -> Any | None:
        if placeholder:
            direct = self._find_edit(placeholder, contains=True, required=False)
            if direct is not None:
                return direct
        try:
            label_control = self._label(label)
        except ElementNotFound:
            if required:
                raise
            return None
        label_rect = _rectangle(label_control)
        label_center_y = (label_rect.top + label_rect.bottom) / 2
        candidates: list[tuple[float, Any]] = []
        for control in self._all("Edit"):
            rect = _rectangle(control)
            if rect.left < label_rect.right - 8:
                continue
            vertical_distance = min(
                abs(rect.top - label_rect.top),
                abs((rect.top + rect.bottom) / 2 - label_center_y),
            )
            if vertical_distance <= 90:
                candidates.append(
                    (
                        vertical_distance + max(0, rect.left - label_rect.right) * 0.01,
                        control,
                    )
                )
        if not candidates:
            if required:
                raise ElementNotFound(
                    f"找不到 {label} 关联输入框",
                    context=ErrorContext(selector=f"label-associated Edit:{label}"),
                )
            return None
        candidates.sort(key=lambda item: item[0])
        if len(candidates) > 1 and abs(candidates[0][0] - candidates[1][0]) < 0.1:
            raise AmbiguousElement(f"{label} 关联输入框不唯一")
        return candidates[0][1]

    def read_value(self, control: Any) -> str:
        readers: list[Callable[[], Any]] = []
        try:
            get_value = getattr(control, "get_value", None)
        except Exception:
            get_value = None
        if callable(get_value):
            readers.append(get_value)
        try:
            iface_value = getattr(control, "iface_value", None)
        except Exception:
            iface_value = None
        if iface_value is not None:
            readers.append(lambda: iface_value.CurrentValue)
        try:
            legacy_properties = getattr(control, "legacy_properties", None)
        except Exception:
            legacy_properties = None
        if callable(legacy_properties):
            readers.append(lambda: (control.legacy_properties() or {}).get("Value"))
        readers.append(lambda: control.window_text())
        for reader in readers:
            try:
                value = reader()
            except Exception:
                continue
            if value is not None and str(value).strip():
                return str(value).strip()
        return ""

    def _replace_text(self, control: Any, value: str, *, field: str) -> None:
        current = self.read_value(control)
        if normalize_field_value(field, current) == normalize_field_value(field, value):
            return
        self.session.focus()
        self._bring_into_view(control)
        with contextlib.suppress(Exception):
            control.click_input()
        errors: list[str] = []
        written = False
        try:
            setter = getattr(control, "set_edit_text", None)
        except Exception:
            setter = None
        if callable(setter):
            try:
                setter(value)
                written = True
            except Exception as exc:
                errors.append(f"set_edit_text={exc!r}")
        if not written:
            try:
                iface_value = getattr(control, "iface_value", None)
            except Exception as exc:
                iface_value = None
                errors.append(f"iface_value={exc!r}")
            if iface_value is not None:
                try:
                    iface_value.SetValue(value)
                    written = True
                except Exception as exc:
                    errors.append(f"SetValue={exc!r}")
        if not written:
            raise FocusLost(
                f"{field} 输入框不支持安全的 ValuePattern 写入；未使用剪贴板回退",
                context=ErrorContext(
                    step=f"set_text:{field}",
                    details={"errors": errors},
                ),
            )
        def written_value_matches() -> bool:
            actual = self.read_value(control)
            if value == "":
                normalized_actual = normalize_field_value(field, actual)
                placeholder = PLACEHOLDERS.get(field)
                return (
                    not normalized_actual
                    or (
                        placeholder is not None
                        and normalize_field_value(field, placeholder)
                        in normalized_actual
                    )
                )
            return (
                normalize_field_value(field, actual)
                == normalize_field_value(field, value)
            )

        wait_until(
            written_value_matches,
            timeout=self.timeout,
            description=f"{field} 输入回读",
        )
        if field == "description":
            self.diagnostics.event("set_text", field=field, description=value)
        else:
            self.diagnostics.event("set_text", field=field, value=value)

    def _job_title_edit(self) -> Any:
        return self._edit_for_label(
            "职位名称",
            placeholder=PLACEHOLDERS["title"],
        )

    def _description_edit(self) -> Any:
        return self._edit_for_label(
            "职位描述",
            placeholder=PLACEHOLDERS["description"],
        )

    def _list_item_text(self, control: Any) -> str:
        parts: list[tuple[int, int, str]] = []
        with contextlib.suppress(Exception):
            for item in control.descendants(control_type="Text"):
                text = self._text(item)
                if not text:
                    continue
                rect = _rectangle(item)
                parts.append((rect.top, rect.left, text))
        if parts:
            return "".join(item[2] for item in sorted(parts))
        return self._text(control)

    def fill_title_and_choose_suggestion(self, title: str) -> None:
        edit = self._job_title_edit()
        if normalize_ui_text(self.read_value(edit)) == normalize_ui_text(title):
            self._replace_text(edit, "", field="title")
            edit = self._job_title_edit()
        self._replace_text(edit, title, field="title")
        title_rect = _rectangle(edit)

        def candidate_controls() -> list[Any]:
            matches: list[Any] = []
            for control in self._all("ListItem"):
                rect = _rectangle(control)
                actual = normalize_ui_text(self._list_item_text(control))
                if (
                    actual == normalize_ui_text(title)
                    and rect.top >= title_rect.bottom - 4
                    and rect.top <= title_rect.bottom + 520
                    and rect.right >= title_rect.left
                    and rect.left <= title_rect.right
                ):
                    matches.append(control)
            return matches

        candidates = wait_until(
            candidate_controls,
            timeout=min(8.0, self.timeout),
            description="职位名称精确联想项",
        )
        candidate = self._unique(
            candidates,
            label=f"职位联想项:{title}",
            prefer=lambda item: (_rectangle(item).top, _rectangle(item).left),
        )
        candidate_rect = _rectangle(candidate)
        try:
            candidate.iface_invoke.Invoke()
        except Exception as exc:
            raise FocusLost(
                "职位名称联想项不支持安全的 UIA InvokePattern；未进行物理点击",
                context=ErrorContext(
                    step="select_title_suggestion",
                    details={"title": title},
                ),
            ) from exc
        self.diagnostics.event(
            "activate_title_suggestion",
            title=title,
            option_rect=list(_rect_tuple(candidate_rect)),
            method="uia_invoke_pattern",
        )
        wait_until(
            lambda: not candidate_controls(),
            timeout=min(4.0, self.timeout),
            description="职位名称联想列表关闭",
        )
        actual = self.read_value(self._job_title_edit())
        if normalize_ui_text(actual) != normalize_ui_text(title):
            raise ReadbackMismatch(
                "职位名称联想选择后回读不一致",
                context=ErrorContext(
                    step="select_title_suggestion",
                    details={"expected": title, "actual": actual},
                ),
            )

    def fill_description(self, description: str) -> None:
        self._replace_text(self._description_edit(), description, field="description")

    def select_recruitment_type(self, value: RecruitmentType) -> None:
        if value is RecruitmentType.SOCIAL_FULL_TIME:
            self._label("招聘类型")
            if not self._find_texts(
                "社招全职", control_types=("Text",), visible_only=False
            ):
                raise ReadbackMismatch(
                    "发布表单默认招聘类型不是社招全职",
                    context=ErrorContext(
                        step="verify_default_recruitment_type",
                        details={"expected": "社招全职", "actual": ""},
                    ),
                )
            self.diagnostics.event(
                "verify_default_recruitment_type",
                value="社招全职",
                method="readback_only_no_action",
            )
            return
        if value not in {RecruitmentType.INTERNSHIP, RecruitmentType.CAMPUS, RecruitmentType.PART_TIME}:
            raise FormRejected("当前自动化不支持该招聘类型")
        self._label("招聘类型")
        candidates = self._find_texts(value.value, control_types=("Text",))
        target = self._unique(
            candidates,
            label=f"招聘类型:{value.value}",
            prefer=lambda item: (_rectangle(item).top, _rectangle(item).left),
        )
        self._click(target, step=f"select_recruitment_type:{value.value}")

        def postcondition() -> bool:
            marker = {
                RecruitmentType.INTERNSHIP: "实习要求",
                RecruitmentType.CAMPUS: "毕业时间",
                RecruitmentType.PART_TIME: "结算方式",
            }[value]
            return bool(
                self._find_texts(
                    marker,
                    control_types=("Text",),
                    visible_only=False,
                )
            )

        wait_until(
            postcondition,
            timeout=self.timeout,
            description=f"招聘类型切换为 {value.value}",
        )

    def _label(self, label: str) -> Any:
        candidates = self._find_texts(label, control_types=("Text",))
        if not candidates:
            offscreen = self._find_texts(
                label,
                control_types=("Text",),
                visible_only=False,
            )
            target = self._unique(
                offscreen,
                label=f"字段标签:{label}",
                prefer=lambda item: (_rectangle(item).top, _rectangle(item).left),
            )
            self._bring_into_view(target)
            candidates = wait_until(
                lambda: self._find_texts(label, control_types=("Text",)),
                timeout=min(5.0, self.timeout),
                description=f"滚动到字段标签 {label}",
            )
        return self._unique(
            candidates,
            label=f"字段标签:{label}",
            prefer=lambda item: (_rectangle(item).top, _rectangle(item).left),
        )

    def _groups_for_label(self, label: str) -> list[Any]:
        label_control = self._label(label)
        label_rect = _rectangle(label_control)
        center_y = (label_rect.top + label_rect.bottom) / 2
        groups: list[Any] = []
        for control in self._all("Group"):
            rect = _rectangle(control)
            group_center_y = (rect.top + rect.bottom) / 2
            if (
                rect.left >= label_rect.right - 5
                and abs(group_center_y - center_y) <= max(32, label_rect.height() * 1.8)
                and rect.width() >= 50
                and rect.width() <= 420
            ):
                groups.append(control)
        unique: dict[tuple[int, int, int, int], Any] = {}
        for control in groups:
            unique[_rect_tuple(_rectangle(control))] = control
        return sorted(unique.values(), key=lambda item: _rectangle(item).left)

    def _group_value(self, group: Any) -> str:
        candidates: list[str] = []
        candidates.append(self._text(group))
        with contextlib.suppress(Exception):
            candidates.extend(
                self._text(item)
                for item in group.descendants(control_type="Text")
                if self._text(item)
            )
        for candidate in candidates:
            normalized = normalize_ui_text(candidate)
            if normalized:
                return normalized
        return ""

    def _group_resolver(self, label: str, index: int) -> Callable[[], Any]:
        def resolve() -> Any:
            groups = self._groups_for_label(label)
            if len(groups) <= index:
                raise ElementNotFound(
                    f"{label} 第 {index + 1} 个下拉框不存在",
                    context=ErrorContext(
                        selector=f"{label}[{index}]",
                        details={"group_count": len(groups)},
                    ),
                )
            return groups[index]

        return resolve

    def _dropdown_lists_for_group(self, group: Any) -> list[Any]:
        group_rect = _rectangle(group)
        candidates: list[Any] = []
        for control in self._all("List"):
            rect = _rectangle(control)
            aligned_below = (
                group_rect.bottom - 4 <= rect.top <= group_rect.bottom + 40
            )
            aligned_above = (
                group_rect.top - 40 <= rect.bottom <= group_rect.top + 4
            )
            if (
                abs(rect.left - group_rect.left) <= 16
                and (aligned_below or aligned_above)
                and rect.width() >= max(80, group_rect.width() * 0.7)
                and rect.width() <= group_rect.width() + 80
            ):
                candidates.append(control)
        return candidates

    def _dropdown_items(self, dropdown: Any, target: str) -> list[Any]:
        matches: list[Any] = []
        try:
            items = dropdown.descendants(control_type="ListItem")
        except Exception as exc:
            raise ElementNotFound(
                "无法读取当前下拉列表选项",
                context=ErrorContext(step="enumerate_dropdown_items"),
            ) from exc
        for item in items:
            if normalize_ui_text(self._list_item_text(item)) == target:
                matches.append(item)
        return matches

    def _resolve_dropdown_option(
        self,
        resolve_group: Callable[[], Any],
        target: str,
        *,
        label: str,
    ) -> tuple[Any, Any]:
        group = resolve_group()
        matches: list[tuple[Any, Any]] = []
        for dropdown in self._dropdown_lists_for_group(group):
            for item in self._dropdown_items(dropdown, target):
                matches.append((dropdown, item))
        if not matches:
            raise ElementNotFound(
                f"{label} 当前下拉列表中找不到精确选项",
                context=ErrorContext(
                    step="resolve_dropdown_option",
                    details={"label": label, "target": target},
                ),
            )
        if len(matches) != 1:
            raise AmbiguousElement(
                f"{label} 当前下拉列表精确选项不唯一（{len(matches)} 个）",
                context=ErrorContext(
                    step="resolve_dropdown_option",
                    details={"label": label, "target": target},
                ),
            )
        return matches[0]

    def _activate_dropdown_option(
        self,
        item: Any,
        *,
        label: str,
        index: int,
        value: str,
        dropdown: Any,
        method: str,
    ) -> str | None:
        item_rect = _rectangle(item)
        dropdown_rect = _rectangle(dropdown)
        try:
            if method == "uia_invoke_pattern":
                item.iface_invoke.Invoke()
            elif method == "uia_selection_item_pattern":
                item.iface_selection_item.Select()
            else:
                raise ValueError(f"unsupported semantic option method: {method}")
        except Exception as exc:
            return repr(exc)
        self.diagnostics.event(
            "activate_option",
            label=label,
            index=index,
            value=value,
            option_rect=list(_rect_tuple(item_rect)),
            dropdown_rect=list(_rect_tuple(dropdown_rect)),
            method=method,
        )
        return None

    def select_catalog_option(
        self,
        *,
        label: str,
        index: int,
        value: str,
        catalog: tuple[str, ...],
    ) -> None:
        normalized_catalog = tuple(normalize_ui_text(item) for item in catalog)
        target = normalize_ui_text(value)
        if target not in normalized_catalog:
            raise FormRejected(
                f"{label} 不存在平台选项：{value}",
                context=ErrorContext(
                    step="select_catalog_option",
                    details={"label": label, "value": value, "catalog": list(catalog)},
                ),
            )
        resolve = self._group_resolver(label, index)
        if normalize_ui_text(self._group_value(resolve())) == target:
            return

        group = resolve()
        if not self._dropdown_lists_for_group(group):
            self._click(group, step=f"open_dropdown:{label}[{index}]")

        wait_until(
            lambda: self._resolve_dropdown_option(
                resolve,
                target,
                label=label,
            ),
            timeout=min(5.0, self.timeout),
            description=f"{label} 当前下拉列表出现精确选项 {value}",
            retryable=(Exception,),
        )

        def postcondition() -> bool:
            fresh_group = resolve()
            return (
                normalize_ui_text(self._group_value(fresh_group)) == target
                and not self._dropdown_lists_for_group(fresh_group)
            )

        pattern_errors: dict[str, str] = {}
        selected = False
        for method in (
            "uia_invoke_pattern",
            "uia_selection_item_pattern",
        ):
            if postcondition():
                selected = True
                break
            try:
                dropdown, candidate = self._resolve_dropdown_option(
                    resolve,
                    target,
                    label=label,
                )
            except Exception as exc:
                pattern_errors[method] = repr(exc)
                continue
            error = self._activate_dropdown_option(
                candidate,
                label=label,
                index=index,
                value=value,
                dropdown=dropdown,
                method=method,
            )
            if error is not None:
                pattern_errors[method] = error
                continue
            try:
                wait_until(
                    postcondition,
                    timeout=min(2.0, self.timeout),
                    interval=0.1,
                    description=f"{label} 回读 {value} 且下拉关闭",
                    retryable=(Exception,),
                )
                selected = True
                break
            except Exception as exc:
                pattern_errors[method] = repr(exc)
        if not selected:
            actual = self._group_value(resolve())
            raise ReadbackMismatch(
                f"{label} 选择后回读不一致；未进行物理点击",
                context=ErrorContext(
                    step="select_catalog_option",
                    details={
                        "expected": value,
                        "actual": actual,
                        "pattern_errors": pattern_errors,
                    },
                ),
            )
        self.diagnostics.event(
            "select_option",
            label=label,
            index=index,
            value=value,
            method="active_dropdown_exact_semantic_option",
        )

    def select_education(self, value: str) -> None:
        self.select_catalog_option(
            label="学历",
            index=0,
            value=value,
            catalog=EDUCATION_OPTIONS,
        )

    def select_social_fulltime_education(self, value: str) -> None:
        # On the social-fulltime form, education can be visible at the very
        # bottom of the viewport while its dropdown is mounted completely
        # offscreen. Bring the following salary label into view first so the
        # education dropdown has visible space, then reuse the original exact
        # catalog selector. This method is never used by the internship branch.
        salary_labels = self._find_texts(
            "薪资详情",
            exact=True,
            control_types=("Text",),
            visible_only=False,
        )
        salary_label = self._unique(salary_labels, label="后续字段锚点:薪资详情")
        self._bring_into_view(salary_label)
        self.select_education(value)

    def select_experience(self, value: str) -> None:
        self.select_catalog_option(
            label="经验",
            index=0,
            value=value,
            catalog=EXPERIENCE_OPTIONS,
        )

    def select_salary(self, spec: JobPostSpec) -> None:
        salary = spec.salary
        if spec.recruitment_type is RecruitmentType.PART_TIME:
            unit = salary.unit.value
            self.select_catalog_option(
                label="薪资范围", index=2, value=unit,
                catalog=PART_TIME_SALARY_UNIT_OPTIONS,
            )
            self.select_catalog_option(
                label="薪资范围", index=0, value=str(salary.minimum),
                catalog=PART_TIME_SALARY_MIN_OPTIONS[unit],
            )
            upper_catalog = tuple(
                value for value in PART_TIME_SALARY_MAX_OPTIONS[unit]
                if int(value) > salary.minimum
            )
            self.select_catalog_option(
                label="薪资范围", index=1, value=str(salary.maximum),
                catalog=upper_catalog,
            )
            return
        if spec.recruitment_type is RecruitmentType.CAMPUS:
            lower = f"{salary.minimum}k"
            upper = f"{salary.maximum}k"
            self.select_catalog_option(
                label="薪资范围",
                index=0,
                value=lower,
                catalog=MONTHLY_SALARY_OPTIONS,
            )
            self.select_catalog_option(
                label="薪资范围",
                index=1,
                value=upper,
                catalog=tuple(f"{value}k" for value in range(salary.minimum + 1, 101)),
            )
            return
        if spec.recruitment_type is RecruitmentType.SOCIAL_FULL_TIME:
            lower = f"{salary.minimum}k"
            upper = f"{salary.maximum}k"
            salary_detail = self._label("薪资详情")
            salary_anchors = self._find_texts(
                "补充薪资明细，更吸引求职者",
                control_types=("Text",),
            )
            anchor_label = "社招薪资详情输入区域提示"
            if not salary_anchors:
                salary_anchors = self._find_texts(
                    "薪资范围：",
                    exact=False,
                    control_types=("Text",),
                )
                anchor_label = "社招薪资详情已填值"
            salary_anchor = self._unique(salary_anchors, label=anchor_label)
            anchor_rect = _rectangle(salary_anchor)
            label_rect = _rectangle(salary_detail)
            click_x = max(anchor_rect.right + 60, label_rect.right + 263)
            click_y = int((anchor_rect.top + anchor_rect.bottom) / 2)
            form_document = self._control_at_point(click_x, click_y)
            if _control_type(form_document) != "Document":
                raise FocusLost(
                    "社招薪资详情输入区域命中验证失败，未点击",
                    context=ErrorContext(
                        step="open_social_fulltime_salary_detail",
                        details={"point": [click_x, click_y], "hit_type": _control_type(form_document)},
                    ),
                )
            self.session.focus()
            try:
                from pywinauto import mouse
                mouse.click(coords=(click_x, click_y))
            except Exception as exc:
                raise FocusLost(
                    "社招薪资详情输入区域点击失败",
                    context=ErrorContext(step="open_social_fulltime_salary_detail"),
                ) from exc
            self.diagnostics.event(
                "click",
                step="open_social_fulltime_salary_detail",
                text=self._text(salary_detail),
                point=[click_x, click_y],
                method="validated_form_document_point",
            )
            wait_until(
                lambda: bool(self._find_texts("薪资范围：", control_types=("Text",))),
                timeout=min(5.0, self.timeout),
                description="社招薪资详情弹窗出现",
                retryable=(Exception,),
            )
            self.select_catalog_option(
                label="薪资范围：",
                index=0,
                value=lower,
                catalog=MONTHLY_SALARY_OPTIONS,
            )
            self.select_catalog_option(
                label="薪资范围：",
                index=1,
                value=upper,
                catalog=tuple(
                    f"{value}k" for value in range(salary.minimum + 1, 101)
                ),
            )
            confirm = self._unique(
                self._find_texts("确定", control_types=("Text",)),
                label="社招薪资详情/确定",
                prefer=lambda item: (-_rectangle(item).top, -_rectangle(item).left),
            )
            self._click(confirm, step="confirm_social_fulltime_salary_detail")
            wait_until(
                lambda: not bool(self._find_texts("薪资范围：", control_types=("Text",))),
                timeout=min(5.0, self.timeout),
                description="社招薪资详情弹窗关闭",
                retryable=(Exception,),
            )
            return
        lower = str(salary.minimum)
        upper = str(salary.maximum)
        self.select_catalog_option(
            label="薪资范围",
            index=0,
            value=lower,
            catalog=DAILY_SALARY_OPTIONS,
        )
        upper_catalog = tuple(
            str(value) for value in range(salary.minimum + 10, 1001, 10)
        )
        self.select_catalog_option(
            label="薪资范围",
            index=1,
            value=upper,
            catalog=upper_catalog,
        )

    def select_part_time_settlement(self, value: str) -> None:
        self.select_catalog_option(
            label="结算方式", index=0, value=value,
            catalog=PART_TIME_SETTLEMENT_OPTIONS,
        )

    def _part_time_edit(self) -> Any:
        return self._edit_for_label("兼职时间", placeholder="请选择兼职时间")

    def read_part_time_schedule(self) -> str:
        edit = self._part_time_edit()
        with contextlib.suppress(Exception):
            return str(edit.iface_value.CurrentValue or "").strip()
        return self.read_value(edit)

    def _part_time_popup_text(self, value: str, *, band: int) -> Any:
        heading = self._unique(
            self._find_texts("工作日期：", control_types=("Text",)),
            label="兼职时间弹层/工作日期",
        )
        top = _rectangle(heading).top
        bands = {
            0: (top - 10, top + 90),
            1: (top + 90, top + 190),
            2: (top + 190, top + 290),
            3: (top + 290, top + 390),
            4: (top + 315, top + 375),  # early/noon/evening/night shifts
            5: (top + 375, top + 455),  # confirm action
        }
        low, high = bands[band]
        candidates = []
        for control in self._find_texts(value, control_types=("Text",)):
            rect = _rectangle(control)
            if low <= rect.top <= high and rect.left >= _rectangle(heading).left + 80:
                candidates.append(control)
        return self._unique(candidates, label=f"兼职时间弹层:{band}:{value}")

    def select_part_time_schedule(
        self, work_date: str, work_period: str,
        days_per_week: str, work_hours: str,
        shifts: tuple[str, ...] = (),
    ) -> None:
        # BOSS ValuePattern encodes selected shifts in the work-time field:
        # 早班=1, 午班=2, 晚班=3, 夜班=4; multiple values are comma-joined.
        shift_codes = {"早班": "1", "午班": "2", "晚班": "3", "夜班": "4"}
        work_hours_actual = (
            ",".join(shift_codes[item] for item in shifts)
            if work_hours == "按班次" else work_hours
        )
        expected = (
            f"工作日期:{work_date};工作时间段:{work_period};"
            f"每周工作天数:{days_per_week};工作时间:{work_hours_actual};"
        )
        if normalize_ui_text(self.read_part_time_schedule()) == normalize_ui_text(expected):
            return
        edit = self._part_time_edit()
        self._bring_into_view(edit)
        self._click(edit, step="open_part_time_schedule")
        wait_until(
            lambda: bool(self._find_texts("工作日期：", control_types=("Text",))),
            timeout=min(5.0, self.timeout), description="兼职时间弹层出现",
        )
        for value, band, field in (
            (work_date, 0, "work_date"),
            (work_period, 1, "work_period"),
            (days_per_week, 2, "days_per_week"),
        ):
            target = self._part_time_popup_text(value, band=band)
            self._click(target, step=f"select_part_time_{field}:{value}")
        if work_hours == "按班次":
            # Switching to non-shift mode clears any stale shift checkboxes from
            # a retained draft. Re-enter shift mode before selecting the exact set.
            reset = self._part_time_popup_text("不限时间", band=3)
            self._click(reset, step="reset_part_time_shifts")
            target = self._part_time_popup_text("按班次", band=3)
            self._click(target, step="select_part_time_work_hours:按班次")
        else:
            target = self._part_time_popup_text(work_hours, band=3)
            self._click(target, step=f"select_part_time_work_hours:{work_hours}")
        if work_hours == "按班次":
            for shift in shifts:
                if shift not in PART_TIME_SHIFT_OPTIONS:
                    raise FormRejected(f"不支持的兼职班次：{shift}")
                target = self._part_time_popup_text(shift, band=4)
                self._click(target, step=f"select_part_time_shift:{shift}")
        confirm = self._part_time_popup_text("确定", band=5)
        self._click(confirm, step="confirm_part_time_schedule")
        wait_until(
            lambda: not bool(self._find_texts("工作日期：", control_types=("Text",))),
            timeout=min(5.0, self.timeout), description="兼职时间弹层关闭",
        )
        actual = self.read_part_time_schedule()
        if normalize_ui_text(actual) != normalize_ui_text(expected) and work_hours == "按班次":
            # Drafts can retain checkbox state even after toggling the radio mode.
            # Reconcile by ValuePattern, then toggle only the symmetric difference.
            reverse_codes = {"1": "早班", "2": "午班", "3": "晚班", "4": "夜班"}
            match = re.search(r"工作时间\s*:\s*([1-4](?:\s*,\s*[1-4])*)", actual)
            if match:
                actual_shifts = {
                    reverse_codes[item.strip()]
                    for item in match.group(1).split(",")
                }
                desired_shifts = set(shifts)
                edit = self._part_time_edit()
                self._click(edit, step="reopen_part_time_schedule_for_shift_reconcile")
                wait_until(
                    lambda: bool(self._find_texts("工作日期：", control_types=("Text",))),
                    timeout=min(5.0, self.timeout), description="兼职时间弹层重新出现",
                )
                for shift in PART_TIME_SHIFT_OPTIONS:
                    if shift in actual_shifts.symmetric_difference(desired_shifts):
                        target = self._part_time_popup_text(shift, band=4)
                        self._click(target, step=f"reconcile_part_time_shift:{shift}")
                confirm = self._part_time_popup_text("确定", band=5)
                self._click(confirm, step="confirm_reconciled_part_time_shifts")
                wait_until(
                    lambda: not bool(self._find_texts("工作日期：", control_types=("Text",))),
                    timeout=min(5.0, self.timeout), description="兼职时间班次校准弹层关闭",
                )
                actual = self.read_part_time_schedule()
        if normalize_ui_text(actual) != normalize_ui_text(expected):
            raise ReadbackMismatch(
                "兼职时间回读不一致",
                context=ErrorContext(
                    step="select_part_time_schedule",
                    details={"expected": expected, "actual": actual},
                ),
            )

    def _deadline_edit(self) -> Any:
        return self._edit_for_label(
            "招聘截止时间", placeholder="选择招聘截止时间"
        )

    def read_recruitment_deadline(self) -> str:
        # The selected date remains in the UIA tree when the row is offscreen,
        # but offscreen nodes have a zero rectangle. Resolve by the strict ISO
        # date shape; the publish form exposes exactly one such text value.
        candidates = []
        for control in self._all("Text", visible_only=False):
            text = self._text(control)
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
                candidates.append(control)
        if not candidates:
            return ""
        item = self._unique(candidates, label="招聘截止时间当前值")
        return self._text(item)

    def select_recruitment_deadline(self, value: str) -> None:
        target_date = date.fromisoformat(value)
        if self.read_recruitment_deadline() == value:
            return
        edit = self._deadline_edit()
        self._bring_into_view(edit)
        self._click(edit, step="open_recruitment_deadline_calendar")
        def month_header() -> str:
            matches = []
            for control in self._all("Text"):
                text = self._text(control)
                if re.fullmatch(r"\d{4}年\s*\d{1,2}月", text):
                    matches.append(control)
            return self._text(self._unique(matches, label="招聘截止月历月份"))
        wait_until(month_header, timeout=min(5.0, self.timeout), description="招聘截止月历出现")
        target_month = target_date.year * 12 + target_date.month
        for _ in range(60):
            header = month_header()
            match = re.fullmatch(r"(\d{4})年\s*(\d{1,2})月", header)
            assert match is not None
            current_month = int(match.group(1)) * 12 + int(match.group(2))
            if current_month == target_month:
                break
            symbol = ">" if current_month < target_month else "<"
            nav = self._unique(
                self._find_texts(symbol, control_types=("Hyperlink",)),
                label=f"招聘截止月历导航:{symbol}",
            )
            self._click(nav, step=f"navigate_recruitment_deadline:{symbol}")
            previous = header
            wait_until(lambda: month_header() != previous, timeout=min(3.0, self.timeout), description="招聘截止月份变化")
        else:
            raise FormRejected("招聘截止时间超出可导航范围")
        candidates = []
        for control in self._all("DataItem"):
            if self._text(control) == str(target_date.day) and _visible(control):
                candidates.append(control)
        day = self._unique(candidates, label=f"招聘截止日期:{value}")
        self._click(day, step=f"select_recruitment_deadline:{value}")
        wait_until(lambda: self.read_recruitment_deadline() == value, timeout=min(5.0, self.timeout), description="招聘截止日期回读")

    def select_graduation_year_range(self, start: str, end: str) -> None:
        # The client exposes two same-row groups. Selecting the start resets
        # the end to the same value, so order is strictly start then end.
        self.select_catalog_option(
            label="毕业时间",
            index=0,
            value=start,
            catalog=GRADUATION_YEAR_OPTIONS,
        )
        if start == "不限":
            end_catalog = ("不限",)
        else:
            start_year = int(start)
            end_catalog = (str(start_year),) + (
                (str(start_year + 1),)
                if str(start_year + 1) in GRADUATION_YEAR_OPTIONS
                else ()
            )
        self.select_catalog_option(
            label="毕业时间",
            index=1,
            value=end,
            catalog=end_catalog,
        )

    def select_internship_requirements(self, months: int, days: int) -> None:
        self.select_catalog_option(
            label="实习要求",
            index=0,
            value=f"{months}个月",
            catalog=INTERNSHIP_MONTH_OPTIONS,
        )
        self.select_catalog_option(
            label="实习要求",
            index=1,
            value=f"{days}天",
            catalog=INTERNSHIP_DAY_OPTIONS,
        )

    def _address_edit(self) -> Any:
        return self._edit_for_label(
            "工作地址",
            placeholder=PLACEHOLDERS["address"],
        )

    def read_address(self) -> str:
        edit = self._address_edit()
        value = self.read_value(edit)
        if normalize_ui_text(value) != normalize_ui_text(PLACEHOLDERS["address"]):
            return value
        with contextlib.suppress(Exception):
            legacy = edit.legacy_properties() or {}
            candidate = str(legacy.get("Value") or "").strip()
            if candidate and normalize_ui_text(candidate) != normalize_ui_text(
                PLACEHOLDERS["address"]
            ):
                return candidate
        return ""

    def _address_selector_open(self) -> bool:
        return self._fixed_exists(ADDRESS_SELECTOR_PROMPT)

    def _resolve_address_modal(self) -> _AddressModal:
        prompt = self._fixed_control(
            ADDRESS_SELECTOR_PROMPT,
            label="地址选择器/标题",
            timeout=min(5.0, self.timeout),
        )
        prompt_rect = _rectangle(prompt)
        document_key = self._document_key(prompt)

        def same_document(control: Any) -> bool:
            try:
                return self._document_key(control) == document_key
            except ElementNotFound:
                return False

        address_headers = [
            item
            for item in self._find_texts("地址", control_types=("Text",))
            if same_document(item)
        ]
        region_headers = [
            item
            for item in self._find_texts("区域", control_types=("Text",))
            if same_document(item)
        ]
        operation_headers = [
            item
            for item in self._find_texts("操作", control_types=("Text",))
            if same_document(item)
        ]
        use_actions = [
            item
            for item in self._find_texts(
                "使用该地址",
                control_types=("Text",),
            )
            if same_document(item)
        ]
        combinations: list[tuple[Any, Any, Any, Any]] = []
        for address_header in address_headers:
            address_rect = _rectangle(address_header)
            for region_header in region_headers:
                region_rect = _rectangle(region_header)
                if (
                    region_rect.left <= address_rect.left
                    or abs(region_rect.top - address_rect.top) > 24
                ):
                    continue
                for operation_header in operation_headers:
                    operation_rect = _rectangle(operation_header)
                    if (
                        operation_rect.left <= region_rect.left
                        or abs(operation_rect.top - address_rect.top) > 24
                    ):
                        continue
                    for use_action in use_actions:
                        use_rect = _rectangle(use_action)
                        if (
                            address_rect.top <= prompt_rect.bottom
                            or use_rect.top <= address_rect.bottom
                            or use_rect.left < region_rect.left
                            or use_rect.right > operation_rect.right + 160
                        ):
                            continue
                        combinations.append(
                            (
                                address_header,
                                region_header,
                                operation_header,
                                use_action,
                            )
                        )
        if len(combinations) != 1:
            error_type = ElementNotFound if not combinations else AmbiguousElement
            raise error_type(
                "工作地址弹层结构不唯一",
                context=ErrorContext(
                    step="resolve_address_modal",
                    details={
                        "address_headers": len(address_headers),
                        "region_headers": len(region_headers),
                        "operation_headers": len(operation_headers),
                        "use_actions": len(use_actions),
                        "matching_combinations": len(combinations),
                    },
                ),
            )
        (
            address_header,
            region_header,
            operation_header,
            use_action,
        ) = combinations[0]
        address_rect = _rectangle(address_header)
        operation_rect = _rectangle(operation_header)
        use_rect = _rectangle(use_action)
        bounds = (
            min(prompt_rect.left, address_rect.left) - 120,
            prompt_rect.top - 80,
            max(operation_rect.right, use_rect.right) + 120,
            use_rect.bottom + 80,
        )
        return _AddressModal(
            prompt=prompt,
            address_header=address_header,
            region_header=region_header,
            operation_header=operation_header,
            use_action=use_action,
            document_key=document_key,
            bounds=bounds,
        )

    def _saved_address_rows(
        self,
        modal: _AddressModal | None = None,
    ) -> list[tuple[Any, Any]]:
        current_modal = modal or self._resolve_address_modal()
        address_rect = _rectangle(current_modal.address_header)
        region_rect = _rectangle(current_modal.region_header)
        operation_rect = _rectangle(current_modal.operation_header)
        use_rect = _rectangle(current_modal.use_action)
        left, top, right, bottom = current_modal.bounds

        def in_modal(control: Any) -> bool:
            try:
                rect = _rectangle(control)
                return (
                    self._document_key(control) == current_modal.document_key
                    and left <= rect.left
                    and rect.right <= right
                    and top <= rect.top
                    and rect.bottom <= bottom
                )
            except Exception:
                return False

        texts = [
            item
            for item in self._all("Text")
            if in_modal(item)
        ]
        view_links = [
            item
            for item in self._find_texts(
                "查看",
                control_types=("Hyperlink",),
            )
            if in_modal(item)
            and _rectangle(item).left >= operation_rect.left - 40
            and _rectangle(item).top > operation_rect.bottom
            and _rectangle(item).top < use_rect.top
        ]
        rows: list[tuple[Any, Any]] = []
        for address_control in texts:
            rect = _rectangle(address_control)
            text = self._text(address_control)
            if (
                not text
                or rect.top <= address_rect.bottom + 10
                or rect.top >= use_rect.top - 10
                or rect.left < address_rect.left
                or rect.right >= region_rect.left
            ):
                continue
            regions = [
                item
                for item in texts
                if (
                    _rectangle(item).left >= region_rect.left - 20
                    and _rectangle(item).right < operation_rect.left
                    and abs(_rectangle(item).top - rect.top) <= 16
                    and self._text(item)
                )
            ]
            actions = [
                item
                for item in view_links
                if abs(_rectangle(item).top - rect.top) <= 16
            ]
            if len(regions) == 1 and len(actions) == 1:
                rows.append((address_control, regions[0]))
        unique: dict[
            tuple[str, str, tuple[int, int, int, int]],
            tuple[Any, Any],
        ] = {}
        for address_control, region_control in rows:
            key = (
                normalize_ui_text(self._text(address_control)),
                normalize_ui_text(self._text(region_control)),
                _rect_tuple(_rectangle(address_control)),
            )
            unique[key] = (address_control, region_control)
        return list(unique.values())

    def _wait_for_stable_saved_address_rows(
        self,
        *,
        stable_seconds: float = 0.75,
    ) -> tuple[_AddressModal, list[tuple[Any, Any]]]:
        stable_since: float | None = None
        last_snapshot: tuple[Any, ...] | None = None
        required_stable = min(
            stable_seconds,
            max(0.1, self.timeout / 4),
        )

        def stable() -> tuple[_AddressModal, list[tuple[Any, Any]]] | bool:
            nonlocal stable_since, last_snapshot
            modal = self._resolve_address_modal()
            rows = self._saved_address_rows(modal)
            snapshot = tuple(
                sorted(
                    (
                        normalize_ui_text(self._text(address_control)),
                        normalize_ui_text(self._text(region_control)),
                        _rect_tuple(_rectangle(address_control)),
                        _rect_tuple(_rectangle(region_control)),
                    )
                    for address_control, region_control in rows
                )
            )
            if snapshot != last_snapshot:
                last_snapshot = snapshot
                stable_since = time.monotonic()
                return False
            if stable_since is None:
                stable_since = time.monotonic()
                return False
            if time.monotonic() - stable_since >= required_stable:
                return modal, rows
            return False

        return wait_until(
            stable,
            timeout=min(5.0, self.timeout),
            interval=0.1,
            description="账号保存工作地址列表稳定",
            retryable=(Exception,),
        )

    def _address_matches_selected(
        self,
        actual: str,
        selected_address: str,
        selected_region: str,
    ) -> bool:
        normalized_actual = normalize_ui_text(actual)
        detail = normalize_ui_text(selected_address)
        if not detail or detail not in normalized_actual:
            return False
        region_tokens = [
            normalize_ui_text(item)
            for item in re.split(r"[·•\s]+", selected_region)
            if normalize_ui_text(item)
        ]
        for token in region_tokens[:2]:
            alternatives = {token}
            without_suffix = re.sub(r"[省市]$", "", token)
            if without_suffix:
                alternatives.add(without_suffix)
            if not any(item in normalized_actual for item in alternatives):
                return False
        return True

    def _select_unique_saved_address(self) -> str:
        modal, rows = self._wait_for_stable_saved_address_rows()
        if not rows:
            raise ElementNotFound(
                "账号没有可用的已保存工作地址",
                context=ErrorContext(step="select_account_default_address"),
            )
        if len(rows) != 1:
            raise AmbiguousElement(
                f"账号保存了 {len(rows)} 条地址，无法确定默认地址",
                context=ErrorContext(
                    step="select_account_default_address",
                    details={
                        "address_count": len(rows),
                        "addresses": [
                            {
                                "address": self._text(address_control),
                                "region": self._text(region_control),
                            }
                            for address_control, region_control in rows
                        ],
                    },
                ),
            )
        address_control, region_control = rows[0]
        selected_address = self._text(address_control)
        selected_region = self._text(region_control)
        # Resolve once more immediately before interaction so a late-rendered
        # second row or a rerendered wrapper causes a safe failure.
        modal = wait_until(
            self._resolve_address_modal,
            timeout=min(5.0, self.timeout),
            interval=0.1,
            description="操作前地址弹层仍可解析",
            retryable=(Exception,),
        )
        fresh_rows = self._saved_address_rows(modal)
        matching_rows = [
            (address_item, region_item)
            for address_item, region_item in fresh_rows
            if (
                normalize_ui_text(self._text(address_item))
                == normalize_ui_text(selected_address)
                and normalize_ui_text(self._text(region_item))
                == normalize_ui_text(selected_region)
            )
        ]
        if len(fresh_rows) != 1 or len(matching_rows) != 1:
            raise AmbiguousElement(
                "地址列表在操作前发生变化，已停止",
                context=ErrorContext(
                    step="select_account_default_address",
                    details={
                        "stable_address_count": len(rows),
                        "fresh_address_count": len(fresh_rows),
                    },
                ),
            )
        address_control, region_control = matching_rows[0]
        self._activate_semantically_or_safe_click(
            address_control,
            document_key=modal.document_key,
            bounds=modal.bounds,
            step="select_unique_saved_address",
        )

        def address_row_outcome() -> tuple[str, Any] | bool:
            if not self._address_selector_open():
                actual = self.read_address()
                if self._address_matches_selected(
                    actual,
                    selected_address,
                    selected_region,
                ):
                    return "committed", actual
                return False
            try:
                return "modal", self._resolve_address_modal()
            except Exception:
                return False

        row_outcome = wait_until(
            address_row_outcome,
            timeout=min(5.0, self.timeout),
            interval=0.1,
            description="选择地址后出现操作区或地址已提交",
            retryable=(Exception,),
        )
        if row_outcome[0] == "modal":
            modal = row_outcome[1]
            self._activate_semantically_or_safe_click(
                modal.use_action,
                document_key=modal.document_key,
                bounds=modal.bounds,
                step="use_selected_address",
            )
        else:
            self.diagnostics.event(
                "address_row_committed",
                method="unique_saved_address_row",
            )
        wait_until(
            lambda: not self._address_selector_open(),
            timeout=min(5.0, self.timeout),
            interval=0.1,
            description="地址选择器关闭",
            retryable=(Exception,),
        )
        last_actual = ""

        def selected_address_readback() -> str | bool:
            nonlocal last_actual
            last_actual = self.read_address()
            if self._address_matches_selected(
                last_actual,
                selected_address,
                selected_region,
            ):
                return last_actual
            return False

        try:
            address = wait_until(
                selected_address_readback,
                timeout=min(5.0, self.timeout),
                interval=0.1,
                description="所选账号工作地址精确回读",
                retryable=(Exception,),
            )
        except Exception as exc:
            raise ReadbackMismatch(
                "工作地址回读与所选账号地址不一致",
                context=ErrorContext(
                    step="verify_account_default_address",
                    details={
                        "selected_address": selected_address,
                        "selected_region": selected_region,
                        "actual": last_actual,
                    },
                ),
            ) from exc
        self.diagnostics.event(
            "select_account_address",
            address=selected_address,
            region=selected_region,
            actual=address,
            method="unique_saved_address_semantic_row",
        )
        return address

    def ensure_address(self, spec: JobPostSpec) -> str:
        address = self.read_address()
        if spec.address.mode == "account_default":
            if address:
                self.diagnostics.event("preserve_prefilled_address", address=address)
                return address
            if not self._address_selector_open():
                self._click(
                    self._address_edit(),
                    step="open_account_address_selector",
                )
                wait_until(
                    self._address_selector_open,
                    timeout=min(5.0, self.timeout),
                    interval=0.1,
                    description="工作地址选择器出现",
                    retryable=(Exception,),
                )
            return self._select_unique_saved_address()
        raise FormRejected(
            "工作地址只支持 account_default；仅保留账号预填地址，"
            "或在地址选择器中选择账号唯一保存地址"
        )

    def _phone_text(self) -> Any:
        matches = self._find_texts(
            "电话交换助手：",
            exact=False,
            control_types=("Text",),
        )
        if not matches:
            offscreen = self._find_texts(
                "电话交换助手：",
                exact=False,
                control_types=("Text",),
                visible_only=False,
            )
            target = self._unique(
                offscreen,
                label="电话交换助手",
                prefer=lambda item: (-_rectangle(item).top, _rectangle(item).left),
            )
            self._bring_into_view(target)
            matches = wait_until(
                lambda: self._find_texts(
                    "电话交换助手：",
                    exact=False,
                    control_types=("Text",),
                ),
                timeout=min(5.0, self.timeout),
                description="滚动到电话交换助手",
            )
        return self._unique(
            matches,
            label="电话交换助手",
            prefer=lambda item: (-_rectangle(item).top, _rectangle(item).left),
        )

    def _phone_toggle_control(self) -> Any:
        # Scroll the phone section into view before resolving the version-pinned
        # CheckBox.  The verified client exposes exactly one visible CheckBox.
        self._phone_text()
        return self._fixed_control(
            PHONE_EXCHANGE_TOGGLE,
            label="电话交换助手/TogglePattern CheckBox",
            timeout=min(5.0, self.timeout),
        )

    def _coerce_phone_toggle_state(self, raw: Any, *, source: str) -> bool:
        try:
            state = int(raw)
        except (TypeError, ValueError) as exc:
            raise ReadbackMismatch(
                "电话交换助手返回了无效的语义状态",
                context=ErrorContext(
                    step="read_phone_exchange",
                    details={"source": source, "raw": repr(raw)},
                ),
            ) from exc
        if state == 0:
            return False
        if state == 1:
            return True
        raise ReadbackMismatch(
            "电话交换助手处于不确定的语义状态",
            context=ErrorContext(
                step="read_phone_exchange",
                details={"source": source, "raw": state},
            ),
        )

    def _read_phone_toggle_state(self, toggle: Any) -> bool:
        errors: dict[str, str] = {}
        try:
            get_toggle_state = getattr(toggle, "get_toggle_state", None)
        except Exception as exc:
            errors["get_toggle_state"] = repr(exc)
            get_toggle_state = None
        if callable(get_toggle_state):
            try:
                return self._coerce_phone_toggle_state(
                    get_toggle_state(),
                    source="get_toggle_state",
                )
            except ReadbackMismatch:
                raise
            except Exception as exc:
                errors["get_toggle_state"] = repr(exc)
        try:
            raw = toggle.iface_toggle.CurrentToggleState
            return self._coerce_phone_toggle_state(
                raw,
                source="TogglePattern.CurrentToggleState",
            )
        except ReadbackMismatch:
            raise
        except Exception as exc:
            errors["TogglePattern.CurrentToggleState"] = repr(exc)
        raise ElementNotFound(
            "电话交换助手没有可读的 TogglePattern；未使用截图或相对坐标",
            context=ErrorContext(
                step="read_phone_exchange",
                details={"semantic_errors": errors},
            ),
        )

    def set_phone_exchange(self, desired: bool | None) -> bool | None:
        if desired is None:
            self.diagnostics.event("preserve_phone_exchange")
            return None
        current = self.phone_exchange_state()
        if current == desired:
            return current
        self.session.focus()
        # Resolve again after state reading/scrolling so Toggle() never targets
        # a stale Electron UIA wrapper.
        toggle = self._phone_toggle_control()
        if self._read_phone_toggle_state(toggle) == desired:
            return desired
        try:
            toggle.iface_toggle.Toggle()
        except Exception as exc:
            raise FocusLost(
                "电话交换助手 TogglePattern 调用失败；未进行物理点击",
                context=ErrorContext(step="toggle_phone_exchange"),
            ) from exc
        wait_until(
            lambda: self.phone_exchange_state() == desired,
            timeout=min(4.0, self.timeout),
            description="电话交换助手状态变化",
            retryable=(Exception,),
        )
        actual = self.phone_exchange_state()
        self.diagnostics.event(
            "set_phone_exchange",
            desired=desired,
            actual=actual,
            method="uia_toggle_pattern",
        )
        return actual

    def phone_exchange_state(self) -> bool:
        return self._read_phone_toggle_state(self._phone_toggle_control())

    def verify_terms_notice(self) -> None:
        """The current client shows a notice, not a separate terms checkbox."""

        terms = self._label("已阅读并遵守")
        if not _visible(terms):
            raise ElementNotFound("未找到《招聘行为管理规范》提示")
        if not self._find_texts(
            "《招聘行为管理规范》",
            control_types=("Hyperlink", "Text"),
        ):
            raise ElementNotFound("未找到《招聘行为管理规范》链接")
        self.diagnostics.event("terms_notice_verified")

    def _read_group(self, label: str, index: int) -> str:
        return self._group_value(self._group_resolver(label, index)())

    def company_name(self) -> str | None:
        # `_label` deliberately searches the offscreen UIA tree and uses
        # ScrollItemPattern when the previous prepare left the form at the
        # footer. Whitespace normalization also covers the client's spaced
        # rendering ("公       司"), so no visible-only pre-check is needed.
        label = self._label("公司")
        rect = _rectangle(label)
        candidates: list[tuple[int, str]] = []
        for control in self._all("Text"):
            item_rect = _rectangle(control)
            text = self._text(control)
            if (
                item_rect.left >= rect.right
                and abs(item_rect.top - rect.top) <= 45
                and len(text) >= 4
            ):
                candidates.append((item_rect.left, text))
        return sorted(candidates)[0][1] if candidates else None

    def _read_social_fulltime_salary(self) -> tuple[str, str]:
        salary_detail = self._label("薪资详情")
        salary_values = self._find_texts(
            "薪资范围：",
            exact=False,
            control_types=("Text",),
        )
        salary_value = self._unique(
            salary_values,
            label="社招薪资详情已填值",
        )
        value_rect = _rectangle(salary_value)
        label_rect = _rectangle(salary_detail)
        click_x = max(value_rect.right + 60, label_rect.right + 263)
        click_y = int((value_rect.top + value_rect.bottom) / 2)
        form_document = self._control_at_point(click_x, click_y)
        if _control_type(form_document) != "Document":
            raise FocusLost(
                "社招薪资详情回读区域命中验证失败，未点击",
                context=ErrorContext(step="open_social_fulltime_salary_detail_for_readback"),
            )
        self.session.focus()
        try:
            from pywinauto import mouse
            mouse.click(coords=(click_x, click_y))
        except Exception as exc:
            raise FocusLost(
                "社招薪资详情回读区域点击失败",
                context=ErrorContext(step="open_social_fulltime_salary_detail_for_readback"),
            ) from exc
        self.diagnostics.event(
            "click",
            step="open_social_fulltime_salary_detail_for_readback",
            text=self._text(salary_detail),
            point=[click_x, click_y],
            method="validated_form_document_point",
        )
        wait_until(
            lambda: bool(self._find_texts("薪资范围：", control_types=("Text",))),
            timeout=min(5.0, self.timeout),
            description="社招薪资详情弹窗出现以供回读",
            retryable=(Exception,),
        )
        try:
            lower = self._read_group("薪资范围：", 0)
            upper = self._read_group("薪资范围：", 1)
        finally:
            cancel = self._unique(
                self._find_texts("取消", control_types=("Text",)),
                label="社招薪资详情/取消",
                prefer=lambda item: (-_rectangle(item).top, -_rectangle(item).left),
            )
            self._click(cancel, step="close_social_fulltime_salary_detail_after_readback")
            wait_until(
                lambda: not bool(self._find_texts("薪资范围：", control_types=("Text",))),
                timeout=min(5.0, self.timeout),
                description="社招薪资详情回读弹窗关闭",
                retryable=(Exception,),
            )
        return lower, upper

    def review(self, spec: JobPostSpec, address: str) -> tuple[FieldEvidence, ...]:
        evidence: list[FieldEvidence] = []

        def add(field: str, expected: str, actual: str) -> None:
            evidence.append(
                FieldEvidence(
                    field=field,
                    expected=expected,
                    actual=actual,
                    verified=normalize_field_value(field, expected)
                    == normalize_field_value(field, actual),
                )
            )

        if spec.recruitment_type is RecruitmentType.SOCIAL_FULL_TIME:
            recruitment_actual = (
                "社招全职"
                if self._find_texts(
                    "社招全职",
                    control_types=("Text",),
                    visible_only=False,
                )
                else ""
            )
            add("recruitment_type", "社招全职", recruitment_actual)
            add("title", spec.title, self.read_value(self._job_title_edit()))
            add("description", spec.description, self.read_value(self._description_edit()))
            add("education", spec.education.value, self._read_group("学历", 0))
            assert spec.experience is not None
            add("experience", spec.experience.value, self._read_group("经验", 0))
            salary_min_actual, salary_max_actual = self._read_social_fulltime_salary()
            add(
                "salary_min",
                f"{spec.salary.minimum}k",
                salary_min_actual,
            )
            add(
                "salary_max",
                f"{spec.salary.maximum}k",
                salary_max_actual,
            )
        elif spec.recruitment_type is RecruitmentType.PART_TIME:
            recruitment_actual = "兼职招聘" if self._find_texts(
                "结算方式", control_types=("Text",), visible_only=False
            ) else ""
            add("recruitment_type", "兼职招聘", recruitment_actual)
            add("title", spec.title, self.read_value(self._job_title_edit()))
            add("description", spec.description, self.read_value(self._description_edit()))
            add("education", spec.education.value, self._read_group("学历", 0))
            assert spec.experience is not None and spec.part_time is not None
            add("experience", spec.experience.value, self._read_group("经验", 0))
            add("settlement", spec.part_time.settlement, self._read_group("结算方式", 0))
            add("salary_min", str(spec.salary.minimum), self._read_group("薪资范围", 0))
            add("salary_max", str(spec.salary.maximum), self._read_group("薪资范围", 1))
            add("salary_unit", spec.salary.unit.value, self._read_group("薪资范围", 2))
            shift_codes = {"早班": "1", "午班": "2", "晚班": "3", "夜班": "4"}
            work_hours_actual = (
                ",".join(shift_codes[item] for item in spec.part_time.shifts)
                if spec.part_time.work_hours == "按班次"
                else spec.part_time.work_hours
            )
            expected_schedule = (
                f"工作日期:{spec.part_time.work_date};"
                f"工作时间段:{spec.part_time.work_period};"
                f"每周工作天数:{spec.part_time.days_per_week};"
                f"工作时间:{work_hours_actual};"
            )
            add("part_time_schedule", expected_schedule, self.read_part_time_schedule())
            add("recruitment_deadline", spec.part_time.recruitment_deadline, self.read_recruitment_deadline())
        elif spec.recruitment_type is RecruitmentType.CAMPUS:
            recruitment_actual = (
                "应届校园招聘"
                if self._find_texts(
                    "毕业时间",
                    control_types=("Text",),
                    visible_only=False,
                )
                else ""
            )
            add("recruitment_type", "应届校园招聘", recruitment_actual)
            add("title", spec.title, self.read_value(self._job_title_edit()))
            add("description", spec.description, self.read_value(self._description_edit()))
            add("education", spec.education.value, self._read_group("学历", 0))
            add("experience", "在校/应届", self._read_group("经验", 0))
            add("salary_min", f"{spec.salary.minimum}k", self._read_group("薪资范围", 0))
            add("salary_max", f"{spec.salary.maximum}k", self._read_group("薪资范围", 1))
            assert spec.graduation_year_start is not None
            assert spec.graduation_year_end is not None
            add(
                "graduation_year_start",
                str(spec.graduation_year_start),
                self._read_group("毕业时间", 0),
            )
            add(
                "graduation_year_end",
                str(spec.graduation_year_end),
                self._read_group("毕业时间", 1),
            )
        else:
            recruitment_actual = (
                "实习生招聘"
                if self._find_texts(
                    "实习要求",
                    control_types=("Text",),
                    visible_only=False,
                )
                else ""
            )
            add("recruitment_type", "实习生招聘", recruitment_actual)
            add("title", spec.title, self.read_value(self._job_title_edit()))
            add("description", spec.description, self.read_value(self._description_edit()))
            add("education", spec.education.value, self._read_group("学历", 0))
            add("experience", "在校/应届", self._read_group("经验", 0))
            add("salary_min", str(spec.salary.minimum), self._read_group("薪资范围", 0))
            add("salary_max", str(spec.salary.maximum), self._read_group("薪资范围", 1))
            salary_unit = (
                "元/天"
                if self._find_texts(
                    "元/天",
                    control_types=("Text",),
                    visible_only=False,
                )
                else ""
            )
            add("salary_unit", "元/天", salary_unit)
            assert spec.internship is not None
            add(
                "internship_months",
                f"{spec.internship.minimum_months}个月",
                self._read_group("实习要求", 0),
            )
            add(
                "days_per_week",
                f"{spec.internship.days_per_week}天",
                self._read_group("实习要求", 1),
            )
        add("address", address, self.read_address())
        if spec.phone_exchange is not None:
            expected_phone = "已开启" if spec.phone_exchange else "未开启"
            actual_phone = "已开启" if self.phone_exchange_state() else "未开启"
            add("phone_exchange", expected_phone, actual_phone)
        failed = [item for item in evidence if not item.verified]
        if failed:
            raise ReadbackMismatch(
                "表单复核失败",
                context=ErrorContext(
                    step="review",
                    details={
                        "failed": [
                            {
                                "field": item.field,
                                "expected": item.expected,
                                "actual": item.actual,
                            }
                            for item in failed
                        ]
                    },
                ),
            )
        return tuple(evidence)

    def _active_publish_form_document_key(self) -> tuple[Any, ...]:
        documents: dict[tuple[Any, ...], set[int]] = {}
        for index, selector in enumerate(FORM_SCROLL_ANCHORS):
            for control in self._fixed_controls(selector):
                key = self._document_key(control)
                documents.setdefault(key, set()).add(index)
        candidates = [
            key
            for key, anchor_indexes in documents.items()
            if len(anchor_indexes) >= 2
        ]
        if len(candidates) != 1:
            error_type = ElementNotFound if not candidates else AmbiguousElement
            raise error_type(
                "无法唯一确定当前发布表单作用域",
                context=ErrorContext(
                    step="resolve_final_publish_scope",
                    details={
                        "candidate_document_count": len(candidates),
                        "visible_anchor_counts": [
                            len(items) for items in documents.values()
                        ],
                    },
                ),
            )
        return candidates[0]

    def _final_publish_footer_document_key(self) -> tuple[Any, ...]:
        address_edit = self._address_edit()
        terms = self._fixed_control(
            FORM_TERMS_LINK,
            label="发布表单页脚/招聘行为管理规范",
            timeout=min(5.0, self.timeout),
        )
        phone_toggle = self._phone_toggle_control()
        document_keys = {
            self._document_key(address_edit),
            self._document_key(terms),
            self._document_key(phone_toggle),
        }
        if len(document_keys) != 1:
            raise FormRejected("发布表单页脚锚点不在同一语义作用域")
        return next(iter(document_keys))

    def _final_publish_button(self, document_key: tuple[Any, ...]) -> Any:
        button = self._unique(
            [
                candidate
                for candidate in self._fixed_controls(FINAL_PUBLISH)
                if self._document_key(candidate) == document_key
            ],
            label="活动发布表单内唯一的最终发布按钮",
        )
        try:
            enabled = bool(button.is_enabled())
        except Exception as exc:
            raise FormRejected("无法确认最终发布按钮是否可用") from exc
        if not enabled:
            raise FormRejected("发布按钮不可用，表单可能仍有未通过项")
        return button

    def click_publish_once(self) -> None:
        if not self.is_publish_form():
            raise FormRejected("当前页面不是稳定的发布职位表单")
        # Focus first, then resolve every wrapper again. Never invoke a control
        # captured before the target BOSS window became active.
        self.session.focus()
        document_key = self._active_publish_form_document_key()
        footer_document_key = self._final_publish_footer_document_key()
        if footer_document_key != document_key:
            raise FormRejected("最终发布按钮页脚与当前表单作用域不一致")
        button = self._final_publish_button(document_key)
        try:
            button.iface_invoke.Invoke()
        except Exception as exc:
            raise FocusLost(
                "最终发布按钮不支持可靠的 UIA InvokePattern；未回退到物理点击",
                context=ErrorContext(
                    step="publish_once",
                    selector='Button(name="发布")',
                ),
            ) from exc
        self.diagnostics.event(
            "invoke",
            step="publish_once",
            text=self._text(button),
            method="uia_invoke_pattern",
        )

    def success_marker(self, title: str) -> bool:
        # An exact title can belong to a pre-existing row. Only an explicit
        # success acknowledgement is strong enough to cross the commit boundary.
        return self._exists_text("发布成功", exact=False)

    def reconcile_title(self, title: str) -> bool:
        if self.success_marker(title):
            return True
        exact = self._find_texts(
            title,
            control_types=("Text",),
            exact=True,
            visible_only=False,
        )
        if exact:
            self.diagnostics.event(
                "reconcile_title_seen_but_unproven",
                title=title,
                reason="an existing row with the same title cannot prove this run succeeded",
            )
        return False
