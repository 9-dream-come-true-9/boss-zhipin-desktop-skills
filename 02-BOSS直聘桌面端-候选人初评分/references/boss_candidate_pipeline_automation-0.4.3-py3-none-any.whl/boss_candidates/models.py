from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Iterable


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def stable_hash(*parts: Any) -> str:
    payload = canonical_json(parts).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def normalize_text(value: str | None) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


class Serializable:
    def as_dict(self) -> dict[str, Any]:
        def convert(value: Any) -> Any:
            if isinstance(value, StrEnum):
                return value.value
            if isinstance(value, tuple):
                return [convert(item) for item in value]
            if isinstance(value, list):
                return [convert(item) for item in value]
            if isinstance(value, dict):
                return {key: convert(item) for key, item in value.items()}
            return value

        return convert(asdict(self))


class BindingStrength(StrEnum):
    EXACT = "EXACT"
    STRONG = "STRONG"
    WEAK = "WEAK"


class IdentityConfidence(StrEnum):
    EXACT = "EXACT"
    STRONG = "STRONG"
    POSSIBLE = "POSSIBLE"
    UNRESOLVED = "UNRESOLVED"


class DiscoveryState(StrEnum):
    DISCOVERED = "DISCOVERED"
    PROFILE_READ = "PROFILE_READ"
    ASSESSED = "ASSESSED"


class CommunicationState(StrEnum):
    NONE = "NONE"
    INBOUND_RECEIVED = "INBOUND_RECEIVED"
    OUTREACH_PREPARED = "OUTREACH_PREPARED"
    REPLY_PREPARED = "REPLY_PREPARED"
    SUBMITTING = "SUBMITTING"
    SENT = "SENT"
    REPLIED = "REPLIED"
    CLOSED = "CLOSED"
    COMMIT_UNKNOWN = "COMMIT_UNKNOWN"


class ResumeState(StrEnum):
    NONE = "NONE"
    REQUEST_PREPARED = "REQUEST_PREPARED"
    REQUESTED = "REQUESTED"
    RECEIVED = "RECEIVED"
    DOWNLOADED = "DOWNLOADED"
    VALIDATED = "VALIDATED"
    PARSED = "PARSED"
    REVIEWED = "REVIEWED"
    UNREADABLE = "UNREADABLE"
    COMMIT_UNKNOWN = "COMMIT_UNKNOWN"


class EvaluationState(StrEnum):
    NOT_EVALUATED = "NOT_EVALUATED"
    EVALUATED = "EVALUATED"
    STALE = "STALE"


class DispositionState(StrEnum):
    ACTIVE = "ACTIVE"
    HOLD = "HOLD"
    NOT_ADVANCING = "NOT_ADVANCING"
    WITHDRAWN = "WITHDRAWN"


class RecommendationBand(StrEnum):
    PRIORITY_REVIEW = "PRIORITY_REVIEW"
    PROMISING_WITH_GAPS = "PROMISING_WITH_GAPS"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"
    NOT_RECOMMENDED = "NOT_RECOMMENDED"


class EvidenceKind(StrEnum):
    GATE = "GATE"
    WEIGHTED = "WEIGHTED"
    RISK = "RISK"


class EvidenceOutcome(StrEnum):
    MATCH = "MATCH"
    PARTIAL = "PARTIAL"
    MISMATCH = "MISMATCH"
    UNKNOWN = "UNKNOWN"
    CONFLICT = "CONFLICT"


class HardGate(StrEnum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"


class ActionKind(StrEnum):
    GREETING = "GREETING"
    REPLY = "REPLY"
    RESUME_REQUEST = "RESUME_REQUEST"


class ActionState(StrEnum):
    PREPARED = "PREPARED"
    AWAITING_CONFIRMATION = "AWAITING_CONFIRMATION"
    SUBMITTING = "SUBMITTING"
    SUCCEEDED = "SUCCEEDED"
    FAILED_SAFE = "FAILED_SAFE"
    COMMIT_UNKNOWN = "COMMIT_UNKNOWN"


class ConversationDirection(StrEnum):
    INBOUND = "INBOUND"
    OUTBOUND = "OUTBOUND"
    SYSTEM = "SYSTEM"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class JobBindingHint(Serializable):
    title: str
    city: str | None = None
    salary: str | None = None
    recruitment_type: str | None = None
    company: str | None = None
    submitted_at: str | None = None
    publish_run_id: str | None = None

    def normalized(self) -> "JobBindingHint":
        return JobBindingHint(
            title=normalize_text(self.title),
            city=normalize_text(self.city) or None,
            salary=normalize_text(self.salary) or None,
            recruitment_type=normalize_text(self.recruitment_type) or None,
            company=normalize_text(self.company) or None,
            submitted_at=self.submitted_at,
            publish_run_id=self.publish_run_id,
        )


@dataclass(frozen=True)
class JobRef(Serializable):
    job_key: str
    title: str
    city: str | None
    salary: str | None
    status: str
    platform_job_id: str | None = None
    company: str | None = None
    recruitment_type: str | None = None
    binding_strength: BindingStrength = BindingStrength.STRONG
    binding_evidence: tuple[str, ...] = ()
    source_publish_run_id: str | None = None


@dataclass(frozen=True)
class CandidateRef(Serializable):
    candidate_key: str
    job_key: str
    display_name: str | None = None
    platform_candidate_id: str | None = None
    conversation_id: str | None = None
    identity_confidence: IdentityConfidence = IdentityConfidence.UNRESOLVED


@dataclass(frozen=True)
class CandidateSnapshot(Serializable):
    candidate_ref: CandidateRef
    source: str
    observed_at: str
    profile: dict[str, Any]
    content_hash: str
    evidence_refs: tuple[str, ...] = ()

    @classmethod
    def create(
        cls,
        candidate_ref: CandidateRef,
        *,
        source: str,
        profile: dict[str, Any],
        evidence_refs: Iterable[str] = (),
        observed_at: str | None = None,
    ) -> "CandidateSnapshot":
        safe_profile = dict(profile)
        return cls(
            candidate_ref=candidate_ref,
            source=source,
            observed_at=observed_at or utc_now(),
            profile=safe_profile,
            content_hash=stable_hash(candidate_ref.candidate_key, source, safe_profile),
            evidence_refs=tuple(evidence_refs),
        )


@dataclass(frozen=True)
class CandidatePage(Serializable):
    job_ref: JobRef
    channel: str
    items: tuple[CandidateSnapshot, ...]
    next_cursor: str | None
    context_evidence: tuple[str, ...] = ()


@dataclass(frozen=True)
class ConversationMessage(Serializable):
    message_id: str
    text: str
    direction: ConversationDirection = ConversationDirection.UNKNOWN


@dataclass(frozen=True)
class ConversationSnapshot(Serializable):
    job_key: str
    candidate_ref: CandidateRef
    observed_at: str
    messages: tuple[ConversationMessage, ...]
    latest_inbound_message_id: str | None
    latest_inbound_text: str | None
    evidence: tuple[str, ...]


@dataclass(frozen=True)
class ConversationPlan(Serializable):
    policy_version: str
    candidate_question_ids: tuple[str, ...]
    answered_screening_question_ids: tuple[str, ...]
    pending_screening_question_ids: tuple[str, ...]
    answer_entry_ids: tuple[str, ...]
    question_ids_to_ask: tuple[str, ...]
    rendered_text: str
    requires_confirmation: bool = True


@dataclass(frozen=True)
class CriterionEvidence(Serializable):
    criterion_id: str
    kind: EvidenceKind
    expected: str
    outcome: EvidenceOutcome
    observed_summary: str
    evidence_refs: tuple[str, ...]
    confidence: float
    weight: float


@dataclass(frozen=True)
class Assessment(Serializable):
    rubric_version: str
    hard_gate: HardGate
    score: int
    coverage: float
    band: RecommendationBand
    evidence: tuple[CriterionEvidence, ...]
    reason_codes: tuple[str, ...] = ()
    gaps: tuple[str, ...] = ()
    conflicts: tuple[str, ...] = ()
    assessed_at: str = field(default_factory=utc_now)


@dataclass(frozen=True)
class CandidateRecord(Serializable):
    candidate_ref: CandidateRef
    sources: tuple[str, ...]
    discovery_state: DiscoveryState
    communication_state: CommunicationState
    resume_state: ResumeState
    evaluation_state: EvaluationState
    disposition_state: DispositionState
    latest_snapshot: CandidateSnapshot | None
    assessment: Assessment | None
    first_seen_at: str
    last_seen_at: str


@dataclass(frozen=True)
class PreparedAction(Serializable):
    action_id: str
    job_key: str
    candidate_key: str
    kind: ActionKind
    payload: str
    payload_hash: str
    triggering_event_id: str | None
    state: ActionState
    prepared_at: str
    confirmation_expires_at: str


@dataclass(frozen=True)
class ActionReceipt(Serializable):
    action_id: str
    state: ActionState
    evidence: tuple[str, ...] = ()
    message: str | None = None
    updated_at: str = field(default_factory=utc_now)


@dataclass(frozen=True)
class ResumeReceipt(Serializable):
    receipt_id: str
    candidate_ref: CandidateRef
    file_name: str
    attachment_id: str | None
    received_at: str | None
    evidence: tuple[str, ...]


@dataclass(frozen=True)
class ResumePreviewContent(Serializable):
    """Text exposed by one verified BOSS semantic attachment preview."""

    candidate_ref: CandidateRef
    file_name: str
    preview_title: str
    text: str
    text_hash: str
    size_bytes: int
    observed_at: str
    evidence: tuple[str, ...]


@dataclass(frozen=True)
class ResumeArtifact(Serializable):
    artifact_id: str
    job_key: str
    candidate_key: str
    source_file_name: str
    stored_path: str
    sha256: str
    size_bytes: int
    media_type: str
    state: ResumeState
    parse_quality: float | None = None
    text_hash: str | None = None
    error: str | None = None


@dataclass(frozen=True)
class ResumeParseResult(Serializable):
    artifact: ResumeArtifact
    text: str
    page_count: int | None
    warnings: tuple[str, ...]
    parse_quality: float


@dataclass(frozen=True)
class ReportReceipt(Serializable):
    job_key: str
    total_candidates: int
    output_files: tuple[str, ...]
    generated_at: str
