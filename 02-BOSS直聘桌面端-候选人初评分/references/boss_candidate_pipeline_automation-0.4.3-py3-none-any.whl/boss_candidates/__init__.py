from __future__ import annotations

from ._version import __version__
from .api import BossCandidatePipeline
from .config import CandidatePipelineConfig, DEFAULT_CONFIG
from .conversation import (
    RecruitingConversationPolicy,
    compose_recruiter_message,
)
from .models import (
    ActionKind,
    ActionReceipt,
    ActionState,
    Assessment,
    CandidatePage,
    CandidateRecord,
    CandidateRef,
    CandidateSnapshot,
    ConversationMessage,
    ConversationPlan,
    ConversationSnapshot,
    JobBindingHint,
    JobRef,
    PreparedAction,
    ReportReceipt,
    ResumeArtifact,
    ResumePreviewContent,
    ResumeReceipt,
)


RUNTIME_BUILD_ID = "boss-candidate-pipeline-20260803-v9"

__all__ = [
    "ActionKind",
    "ActionReceipt",
    "ActionState",
    "Assessment",
    "BossCandidatePipeline",
    "CandidatePage",
    "CandidatePipelineConfig",
    "CandidateRecord",
    "CandidateRef",
    "CandidateSnapshot",
    "ConversationMessage",
    "ConversationPlan",
    "ConversationSnapshot",
    "DEFAULT_CONFIG",
    "JobBindingHint",
    "JobRef",
    "PreparedAction",
    "RecruitingConversationPolicy",
    "ReportReceipt",
    "ResumeArtifact",
    "ResumePreviewContent",
    "ResumeReceipt",
    "RUNTIME_BUILD_ID",
    "compose_recruiter_message",
    "__version__",
]
