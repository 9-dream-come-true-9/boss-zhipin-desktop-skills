from __future__ import annotations

import contextlib
import hashlib
import json
import msvcrt
import os
import re
import time
import unicodedata
from pathlib import Path
from typing import Any, Iterable, Iterator

from ..config import CandidatePipelineConfig, DEFAULT_CONFIG
from ..errors import (
    AccessibilityUnavailable,
    AmbiguousJob,
    CandidateIdentityConflict,
    CommitUnknown,
    ContextMismatch,
    ErrorContext,
)
from ..models import (
    ActionKind,
    ActionReceipt,
    ActionState,
    BindingStrength,
    CandidatePage,
    CandidateRef,
    CandidateSnapshot,
    ConversationDirection,
    ConversationMessage,
    ConversationSnapshot,
    IdentityConfidence,
    JobBindingHint,
    JobRef,
    PreparedAction,
    ResumePreviewContent,
    ResumeReceipt,
    normalize_text,
    stable_hash,
    utc_now,
)
from ..resume import normalize_uia_preview_text
from . import selectors
from .session import BossCandidateSession


EXCLUDED_CARD_TEXTS = {
    "打招呼",
    "继续沟通",
    "刚刚活跃",
    "在线",
    "面议",
    "本科",
    "硕士",
    "博士",
    "大专",
}

PROTECTED_TEXT_PATTERNS = (
    re.compile(r"^\d{1,2}岁$"),
    re.compile(r"^(男|女)$"),
    re.compile(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}"),
    re.compile(r"(?<!\d)1\d{10}(?!\d)"),
    re.compile(
        r"(?:微信|wechat|wx|QQ)\s*(?:号|[:：])?\s*[A-Za-z0-9_-]{4,}",
        re.IGNORECASE,
    ),
    re.compile(r"(?:电话|手机|联系方式)\s*[:：]?\s*[\d -]{6,}"),
)


def _cursor_offset(cursor: str | None) -> int:
    match = re.fullmatch(r"offset-v1:(\d+)", cursor or "")
    return int(match.group(1)) if match else 0


def _next_offset_cursor(
    offset: int, returned_count: int, *, has_more: bool
) -> str | None:
    if not has_more or returned_count <= 0:
        return None
    return f"offset-v1:{offset + returned_count}"


def _offset_page(
    items: tuple[Any, ...],
    cursor: str | None,
    limit: int,
    *,
    exhausted: bool,
) -> tuple[tuple[Any, ...], str | None]:
    offset = _cursor_offset(cursor)
    page_limit = max(1, limit)
    page = items[offset : offset + page_limit]
    has_more = len(items) > offset + len(page) or (
        not exhausted and len(page) == page_limit
    )
    return page, _next_offset_cursor(
        offset, len(page), has_more=has_more
    )


class _UILock:
    def __init__(self, path: Path, timeout: float):
        self.path = path
        self.timeout = timeout
        self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+b")
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
                return self
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("等待 BOSS UI 串行锁超时")
                time.sleep(0.1)

    def __exit__(self, exc_type, exc, tb):
        if self.handle is not None:
            try:
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            finally:
                self.handle.close()


def _safe_visible_texts(values: Iterable[str]) -> tuple[str, ...]:
    result: list[str] = []
    for value in values:
        text = normalize_text(value)
        if not text:
            continue
        if any(pattern.search(text) for pattern in PROTECTED_TEXT_PATTERNS):
            continue
        result.append(text)
    return tuple(result)


def _wrapper_identity(control: Any) -> str | None:
    info = control.element_info
    automation_id = (getattr(info, "automation_id", "") or "").strip()
    if automation_id:
        return f"automation:{automation_id}"
    try:
        runtime_id = tuple(info.runtime_id)
    except Exception:
        runtime_id = ()
    if runtime_id:
        return "runtime:" + ".".join(str(item) for item in runtime_id)
    return None


def _likely_name(texts: Iterable[str]) -> str | None:
    for value in texts:
        text = normalize_text(value)
        if (
            not text
            or text in EXCLUDED_CARD_TEXTS
            or len(text) > 20
            or any(character.isdigit() for character in text)
            or any(marker in text for marker in ("期望", "学历", "工作经历", "教育经历"))
        ):
            continue
        if re.fullmatch(r"[\u4e00-\u9fffA-Za-z·.\-]{1,20}", text):
            return text
        if text == "求职者":
            return text
    return None


def _profile_from_texts(texts: tuple[str, ...]) -> dict[str, Any]:
    safe = _safe_visible_texts(texts)
    education = next(
        (
            text
            for text in safe
            if any(level in text for level in ("博士", "硕士", "本科", "大专"))
        ),
        None,
    )
    desired_role = next(
        (text for text in safe if text.startswith("期望") or "期望职位" in text),
        None,
    )
    availability = next(
        (
            text
            for text in safe
            if any(
                marker in text
                for marker in (
                    "应届",
                    "在校",
                    "随时到岗",
                    "月内到岗",
                    "每周",
                    "出勤",
                    "个月",
                    "到岗",
                )
            )
        ),
        None,
    )
    school_or_major = [
        text
        for text in safe
        if any(marker in text for marker in ("大学", "学院", "专业"))
    ][:4]
    work_evidence = [
        text
        for text in safe
        if any(
            marker in text
            for marker in (
                "运营",
                "文案",
                "编辑",
                "策划",
                "设计",
                "实习",
                "客户成功",
                "产品",
            )
        )
    ][:8]
    skills = [
        text
        for text in safe
        if len(text) <= 30
        and any(
            marker.casefold() in text.casefold()
            for marker in (
                "python",
                "java",
                "aigc",
                "ps",
                "pr",
                "figma",
                "内容策划",
                "视频剪辑",
                "小红书",
            )
        )
    ][:8]
    return {
        "education": education,
        "major": "；".join(school_or_major) or None,
        "availability": availability,
        "desired_role": desired_role,
        "experience_summary": "；".join(work_evidence) or None,
        "skills": skills,
        "_source_text_hash": stable_hash(safe),
    }


def _visible_job_facts(
    texts: Iterable[str],
    *,
    candidate_name: str | None,
    job_title: str,
    max_items: int = 24,
    max_item_chars: int = 240,
    max_total_chars: int = 3000,
) -> list[str]:
    """Keep bounded general evidence while excluding protected/UI text."""

    excluded = {
        normalize_text(candidate_name),
        normalize_text(job_title),
        "在线",
        "刚刚活跃",
        "今日活跃",
        "牛人分析器",
        "在线简历",
        "附件简历",
        "求简历",
        "发送",
        "不合适",
        "新招呼",
        "沟通中",
        "已约面",
        "全部",
        "未读",
    }
    facts: list[str] = []
    total = 0
    for text in _safe_visible_texts(texts):
        if text in excluded:
            continue
        if re.fullmatch(
            r"(?:\d{1,2}:\d{2}|昨天|前天|星期[一二三四五六日天]|"
            r"\d{1,2}月\d{1,2}日)",
            text,
        ):
            continue
        bounded = text[:max_item_chars].strip()
        if not bounded or bounded in facts:
            continue
        if total + len(bounded) > max_total_chars:
            break
        facts.append(bounded)
        total += len(bounded)
        if len(facts) >= max_items:
            break
    return facts


def _candidate_name_and_profile_from_chat_texts(
    texts: tuple[str, ...],
    *,
    preferred_name: str | None = None,
) -> tuple[str, dict[str, Any]]:
    safe = tuple(
        normalized
        for value in texts
        if (normalized := normalize_text(value))
    )
    anchor_indexes = [
        index
        for index, text in enumerate(safe)
        if re.fullmatch(r"\d{1,3}岁", text)
    ]
    if not anchor_indexes:
        anchor_indexes = [
            index
            for index, text in enumerate(safe)
            if text == "牛人分析器"
        ]
    excluded = {
        "刚刚活跃",
        "今日活跃",
        "在线",
        "牛人分析器",
        "附件简历",
        "本科",
        "硕士",
        "博士",
        "大专",
    }
    name = normalize_text(preferred_name) if preferred_name else None
    name_index = None
    if name:
        matching_indexes = [
            index for index, value in enumerate(safe) if value == name
        ]
        if matching_indexes:
            # Prefer the occurrence immediately before a visible age anchor.
            # This selects the live chat/profile header rather than duplicate
            # text left in a closed resume preview.
            name_index = min(
                matching_indexes,
                key=lambda index: min(
                    (
                        anchor - index
                        for anchor in anchor_indexes
                        if 0 < anchor - index <= 7
                    ),
                    default=1000,
                ),
            )
    if name_index is None:
        name = None
        for anchor in anchor_indexes:
            for index in range(anchor - 1, max(-1, anchor - 7), -1):
                candidate = safe[index]
                if candidate in excluded or candidate.endswith("活跃"):
                    continue
                if _likely_name((candidate,)) == candidate:
                    name = candidate
                    name_index = index
                    break
            if name:
                break
    if name is None or name_index is None:
        raise CandidateIdentityConflict(
            "当前聊天资料区无法回读唯一候选人姓名"
        )
    end_index = next(
        (
            index
            for index in range(name_index + 1, len(safe))
            if safe[index] in {"沟通职位：", "沟通职位:"}
        ),
        min(len(safe), name_index + 30),
    )
    profile = _profile_from_texts(safe[name_index + 1 : end_index])
    profile["_ui_source"] = "messages.current_conversation"
    return name, profile


def _message_preview(
    texts: tuple[str, ...],
    *,
    candidate_name: str | None,
    job_title: str,
) -> str | None:
    excluded = {
        candidate_name,
        job_title,
        "刚刚",
        "昨天",
        "前天",
        "本科",
        "硕士",
        "博士",
        "大专",
        "在线",
        "已读",
        "未读",
        "送达",
    }
    candidates = []
    for value in _safe_visible_texts(texts):
        if value in excluded:
            continue
        if re.fullmatch(r"\d+", value):
            continue
        if re.fullmatch(r"\d{1,2}:\d{2}", value):
            continue
        if re.fullmatch(r"\d{1,2}岁", value):
            continue
        candidates.append(value)
    if not candidates:
        return None
    preview = max(candidates, key=len)
    if preview.startswith(("我：", "我:", "[我]", "招聘者：", "招聘者:")):
        return None
    return preview


def _normalize_job_selector_part(value: str | None) -> str:
    return normalize_text(
        unicodedata.normalize("NFKC", value or "")
    ).casefold()


def _normalize_job_selector_salary(value: str | None) -> str:
    normalized = _normalize_job_selector_part(value)
    return re.sub(r"[\s,，]", "", normalized).replace("—", "-").replace(
        "–", "-"
    )


def _parse_message_job_selector(
    value: str | None,
) -> tuple[str, str, str] | None:
    normalized = normalize_text(
        unicodedata.normalize("NFKC", value or "")
    )
    if " _ " not in normalized:
        return None
    title, remainder = normalized.split(" _ ", 1)
    if not title or " " not in remainder:
        return None
    city, salary = remainder.rsplit(" ", 1)
    if not city or not salary:
        return None
    if not re.fullmatch(
        r"\d+(?:\.\d+)?(?:-\d+(?:\.\d+)?)?"
        r"(?:元/天|元/月|元/小时|k(?:·\d+薪)?)",
        _normalize_job_selector_salary(salary),
        re.IGNORECASE,
    ):
        return None
    return title, city, salary


def _job_selector_value_matches(
    value: str | None, job_ref: JobRef
) -> bool:
    parsed = _parse_message_job_selector(value)
    if parsed is None:
        return False
    title, city, salary = parsed
    if _normalize_job_selector_part(title) != _normalize_job_selector_part(
        job_ref.title
    ):
        return False
    if job_ref.city and _normalize_job_selector_part(
        city
    ) != _normalize_job_selector_part(job_ref.city):
        return False
    if job_ref.salary and _normalize_job_selector_salary(
        salary
    ) != _normalize_job_selector_salary(job_ref.salary):
        return False
    return True


class LiveBossAdapter:
    """Fixed-function pywinauto adapter for the verified BOSS desktop build."""

    def __init__(
        self,
        *,
        config: CandidatePipelineConfig = DEFAULT_CONFIG,
        restart_for_accessibility: bool = False,
    ):
        self.config = config
        self.restart_for_accessibility = restart_for_accessibility
        self._last_session: BossCandidateSession | None = None
        self._last_job: JobRef | None = None

    @contextlib.contextmanager
    def _connected(self) -> Iterator[BossCandidateSession]:
        lock = _UILock(
            self.config.state_dir / "boss-ui.lock",
            self.config.default_timeout_seconds,
        )
        with lock:
            session = BossCandidateSession(
                config=self.config,
                timeout=self.config.default_timeout_seconds,
                maximize=True,
                restart_for_accessibility=self.restart_for_accessibility,
            ).connect()
            self._last_session = session
            yield session

    def inspect_environment(self) -> dict[str, Any]:
        session = BossCandidateSession(config=self.config)
        return session.inspect_environment()

    def _unique_preferred(
        self,
        session: BossCandidateSession,
        selector_group: Iterable[dict[str, Any]],
        *,
        label: str,
        scope: Any | None = None,
    ) -> Any:
        ambiguous = 0
        for selector in selector_group:
            controls = session.find_all(
                selector, scope=scope, actionable_only=True
            )
            if len(controls) == 1:
                return controls[0]
            ambiguous = max(ambiguous, len(controls))
        raise AccessibilityUnavailable(
            f"{label} 没有唯一固定语义控件",
            context=ErrorContext(
                step="unique_preferred",
                details={"label": label, "max_count": ambiguous},
            ),
        )

    def _click_label(
        self,
        session: BossCandidateSession,
        selector_group: Iterable[dict[str, Any]],
        *,
        label: str,
        scope: Any | None = None,
    ) -> None:
        control = self._unique_preferred(
            session, selector_group, label=label, scope=scope
        )
        session.invoke(control)
        session.refresh()

    def _message_navigation_control(
        self, session: BossCandidateSession
    ) -> Any:
        """Resolve exact Messages text to its badge-bearing Hyperlink parent."""
        labels = session.find_all(
            {"title": "消息", "control_type": "Text"},
            actionable_only=False,
        )
        matches: dict[str, Any] = {}
        for anchor in labels:
            try:
                parent = anchor.parent()
                info = parent.element_info
                name = normalize_text(
                    getattr(info, "name", "") or parent.window_text()
                ).replace(" ", "")
                anchor_visible = anchor.is_visible()
                actionable = parent.is_visible() and parent.is_enabled()
            except Exception:
                continue
            if getattr(info, "control_type", "") != "Hyperlink":
                continue
            if (
                not anchor_visible
                or not actionable
                or not re.fullmatch(r"消息(?:\d+\+?)?", name)
            ):
                continue
            matches[_wrapper_identity(parent) or stable_hash(name)] = parent
        if len(matches) != 1:
            raise AccessibilityUnavailable(
                "左侧导航-消息没有唯一固定语义父控件",
                context=ErrorContext(
                    step="message_navigation_parent",
                    details={"labels": len(labels), "parents": len(matches)},
                ),
            )
        return next(iter(matches.values()))

    def _message_header_new_greetings_anchor(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
    ) -> Any:
        """Return the exact ``新招呼`` Text in the Messages header.

        The selected-job control provides the first semantic anchor.  The
        verified ``新招呼`` control must be immediately below it and inside its
        horizontal span.  This excludes candidate-card text and the left
        navigation without relying on a list index or an absolute coordinate.
        """

        job_controls = self._message_job_selector_controls(session, job_ref)
        greeting_controls = session.find_all_alternatives(
            selectors.MESSAGES_NEW_GREETINGS,
            actionable_only=False,
        )
        matched: dict[str, Any] = {}
        for greeting in greeting_controls:
            try:
                greeting_rect = greeting.rectangle()
                greeting_width = greeting_rect.right - greeting_rect.left
                greeting_height = greeting_rect.bottom - greeting_rect.top
            except Exception:
                continue
            if greeting_width <= 0 or greeting_height <= 0:
                continue
            if not 1.5 <= greeting_width / greeting_height <= 5.0:
                continue
            for job_control in job_controls:
                try:
                    job_rect = job_control.rectangle()
                except Exception:
                    continue
                below_job = (
                    greeting_rect.top >= job_rect.bottom
                    and greeting_rect.top - job_rect.bottom
                    <= greeting_height * 2.5
                )
                within_job_span = (
                    job_rect.left <= greeting_rect.left
                    and greeting_rect.right <= job_rect.right
                )
                if below_job and within_job_span:
                    identity = _wrapper_identity(greeting) or (
                        f"object:{id(greeting)}"
                    )
                    matched[identity] = greeting
                    break
        if len(matched) != 1:
            raise AccessibilityUnavailable(
                "消息头“新招呼”语义锚点必须相对当前岗位唯一定位",
                context=ErrorContext(
                    step="message_header_anchor",
                    details={
                        "job_selector_count": len(job_controls),
                        "new_greetings_count": len(greeting_controls),
                        "aligned_count": len(matched),
                        "selector_profile": selectors.SELECTOR_PROFILE,
                    },
                ),
            )
        return next(iter(matched.values()))

    def _message_header_tab_controls(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        selector_group: Iterable[dict[str, Any]],
        *,
        label: str,
    ) -> list[Any]:
        """Filter exact semantic matches to the top Messages tab row."""

        anchor = self._message_header_new_greetings_anchor(session, job_ref)
        anchor_rect = anchor.rectangle()
        anchor_width = anchor_rect.right - anchor_rect.left
        anchor_height = anchor_rect.bottom - anchor_rect.top
        if label == "新招呼":
            expected_x = anchor_rect.left + anchor_width * 0.5
        elif label in selectors.MESSAGE_HEADER_TAB_X_RATIOS:
            expected_x = (
                anchor_rect.left
                + anchor_width
                * selectors.MESSAGE_HEADER_TAB_X_RATIOS[label]
            )
        else:
            expected_x = None
        matched: dict[str, Any] = {}
        for control in session.find_all_alternatives(
            selector_group,
            actionable_only=False,
        ):
            try:
                rect = control.rectangle()
                width = rect.right - rect.left
                height = rect.bottom - rect.top
            except Exception:
                continue
            if width <= 0 or height <= 0:
                continue
            same_header_row = abs(
                (rect.top + rect.bottom) / 2
                - (anchor_rect.top + anchor_rect.bottom) / 2
            ) <= max(anchor_height, height) * 0.8
            horizontally_expected = (
                expected_x is None
                or abs((rect.left + rect.right) / 2 - expected_x)
                <= max(anchor_width, width)
            )
            if same_header_row and horizontally_expected:
                identity = _wrapper_identity(control) or (
                    f"object:{id(control)}"
                )
                matched[identity] = control
        return list(matched.values())

    def _message_tab_surface_ready(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
    ) -> bool:
        """Validate that a relative tab click stayed in the bound Messages UI."""

        if not self._message_job_selector_controls(session, job_ref):
            return False
        try:
            self._message_header_new_greetings_anchor(session, job_ref)
        except AccessibilityUnavailable:
            return False
        return True

    def _click_message_header_tab(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        selector_group: Iterable[dict[str, Any]],
        *,
        label: str,
    ) -> str:
        """Click one fixed Messages header tab and validate page context.

        Exact UIA controls are always preferred.  On BOSS 1.7.4.963 only the
        known painted tabs may fall back to one semantic-anchor-relative click.
        No retry is attempted after either click, preserving at-most-once
        behavior even when post-click validation fails.
        """

        anchor = self._message_header_new_greetings_anchor(session, job_ref)
        semantic = self._message_header_tab_controls(
            session,
            job_ref,
            selector_group,
            label=label,
        )
        if len(semantic) > 1:
            raise AccessibilityUnavailable(
                f"消息头“{label}”语义控件不唯一",
                context=ErrorContext(
                    step="message_header_tab",
                    details={"label": label, "count": len(semantic)},
                ),
            )
        if semantic:
            session.invoke(semantic[0])
            method = "semantic"
        else:
            ratio = selectors.MESSAGE_HEADER_TAB_X_RATIOS.get(label)
            if ratio is None:
                raise AccessibilityUnavailable(
                    f"消息头“{label}”没有已验证的相对布局规则",
                    context=ErrorContext(
                        step="message_header_tab",
                        details={
                            "label": label,
                            "selector_profile": selectors.SELECTOR_PROFILE,
                        },
                    ),
                )
            session.click_relative_to_semantic_anchor(
                anchor,
                x_ratio=ratio,
                y_ratio=0.5,
            )
            method = "semantic-anchor-relative"
        session.refresh()
        if not session.wait_for(
            lambda: self._message_tab_surface_ready(
                session, job_ref
            ),
            timeout=session.wait_timeout,
        ):
            raise AccessibilityUnavailable(
                f"点击消息头“{label}”后未能回读当前岗位消息页",
                context=ErrorContext(
                    step="message_header_tab_verify",
                    details={
                        "label": label,
                        "method": method,
                        "selector_profile": selectors.SELECTOR_PROFILE,
                    },
                ),
            )
        return method

    def _message_job_selector_region_matches(
        self,
        session: BossCandidateSession,
        control: Any,
    ) -> bool:
        greeting_anchors = session.find_all_alternatives(
            selectors.MESSAGES_NEW_GREETINGS,
            actionable_only=False,
        )
        try:
            control_rect = control.rectangle()
        except Exception:
            return False
        try:
            window_rect = session.window.rectangle()
        except Exception:
            window_rect = None
        if window_rect is not None:
            window_height = window_rect.bottom - window_rect.top
            if control_rect.bottom > window_rect.top + window_height * 0.4:
                return False
        for greeting in greeting_anchors:
            try:
                greeting_rect = greeting.rectangle()
            except Exception:
                continue
            horizontal_overlap = (
                min(control_rect.right, greeting_rect.right)
                - max(control_rect.left, greeting_rect.left)
            )
            control_height = control_rect.bottom - control_rect.top
            greeting_height = greeting_rect.bottom - greeting_rect.top
            vertical_gap = greeting_rect.top - control_rect.bottom
            if (
                horizontal_overlap > 0
                and vertical_gap >= 0
                and vertical_gap
                <= max(control_height * 4, greeting_height * 8)
            ):
                return True
        return False

    def _message_job_selector_controls(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
    ) -> list[Any]:
        """Return semantic controls for the selected job in Messages.

        Electron exposes this control either as a ComboBox value or as an
        actionable Text label. Text labels must use the verified
        ``title _ city salary`` shape, which excludes job-title occurrences
        in candidate cards and chat content.
        """

        controls: dict[str, Any] = {}
        for control_type in ("ComboBox", "Text"):
            for control in session.find_all(
                {"control_type": control_type},
                actionable_only=False,
            ):
                values = [
                    normalize_text(
                        getattr(control.element_info, "name", "")
                    )
                ]
                try:
                    values.append(normalize_text(control.window_text()))
                except Exception:
                    pass
                try:
                    values.append(normalize_text(control.get_value()))
                except Exception:
                    pass
                if not any(
                    _job_selector_value_matches(value, job_ref)
                    for value in values
                ):
                    continue
                if not self._message_job_selector_region_matches(
                    session, control
                ):
                    continue
                identity = _wrapper_identity(control) or (
                    f"object:{id(control)}"
                )
                controls[identity] = control
        return list(controls.values())

    def _on_messages_surface(
        self, session: BossCandidateSession
    ) -> bool:
        return bool(
            session.find_all_alternatives(
                selectors.MESSAGES_NEW_GREETINGS,
                actionable_only=False,
            )
        )

    def _message_header_more_control(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
    ) -> Any:
        """Select Messages' header ``更多`` relative to the job selector.

        The verified build exposes two exact ``更多`` controls: one in the
        global left navigation and one in the Messages queue header. The
        latter is in the message column (to the right of the selected-job
        control's leading edge) and below that control. This comparison uses
        only semantic wrappers and their relative layout; it does not use a
        screen coordinate, OCR, a screenshot, a candidate name, or a list
        index.
        """

        anchors = self._message_job_selector_controls(session, job_ref)
        more_controls = session.find_all_alternatives(
            selectors.MESSAGES_MORE,
            actionable_only=True,
        )
        matched: dict[str, Any] = {}
        for control in more_controls:
            try:
                control_rect = control.rectangle()
            except Exception:
                continue
            for anchor in anchors:
                try:
                    anchor_rect = anchor.rectangle()
                except Exception:
                    continue
                in_message_column = (
                    control_rect.left >= anchor_rect.left
                )
                below_job_selector = (
                    control_rect.top >= anchor_rect.top
                    and control_rect.bottom > anchor_rect.bottom
                )
                if in_message_column and below_job_selector:
                    identity = _wrapper_identity(control) or (
                        f"object:{id(control)}"
                    )
                    matched[identity] = control
                    break
        if len(matched) != 1:
            raise AccessibilityUnavailable(
                "消息头“更多”必须相对当前岗位选择器唯一定位",
                context=ErrorContext(
                    step="message_header_more",
                    details={
                        "job_selector_count": len(anchors),
                        "more_count": len(more_controls),
                        "aligned_count": len(matched),
                    },
                ),
            )
        return next(iter(matched.values()))

    def _click_message_header_more(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
    ) -> None:
        control = self._message_header_more_control(session, job_ref)
        session.invoke(control)
        session.refresh()

    def _navigate(
        self,
        session: BossCandidateSession,
        selector_group: Iterable[dict[str, Any]],
        *,
        label: str,
    ) -> None:
        if selector_group is selectors.NAV_MESSAGES:
            control = self._message_navigation_control(session)
            session.invoke(control)
            session.refresh()
        else:
            self._click_label(
                session, selector_group, label=f"左侧导航-{label}"
            )
        time.sleep(0.5)

    def _ancestor_with_texts(
        self,
        session: BossCandidateSession,
        control: Any,
        *,
        required: Iterable[str],
        max_levels: int = 10,
    ) -> Any:
        required_set = set(required)
        try:
            anchor_text = normalize_text(control.window_text())
        except Exception:
            anchor_text = ""
        current = control
        best = None
        for _ in range(max_levels):
            try:
                current = current.parent()
            except Exception:
                break
            texts = set(_safe_visible_texts(session.texts_within(current)))
            if anchor_text:
                texts.add(anchor_text)
            if required_set <= texts:
                best = current
                if len(texts) >= max(3, len(required_set)):
                    return current
        if best is not None:
            return best
        raise AccessibilityUnavailable(
            "无法把语义锚点限定到唯一候选卡片",
            context=ErrorContext(
                step="ancestor_scope",
                details={"required": sorted(required_set)},
            ),
        )

    def _job_cards(
        self,
        session: BossCandidateSession,
        hint: JobBindingHint,
    ) -> list[tuple[Any, tuple[str, ...]]]:
        title_controls = session.find_all(
            {"title": hint.title, "control_type": "Text"},
            actionable_only=False,
        )
        cards: list[tuple[Any, tuple[str, ...]]] = []
        seen: set[str] = set()
        for title_control in title_controls:
            current = title_control
            for _ in range(10):
                try:
                    current = current.parent()
                except Exception:
                    break
                texts = _safe_visible_texts(session.texts_within(current))
                combined = " | ".join(texts)
                if (
                    hint.title in texts
                    and "开放中" in combined
                    and ("编辑" in combined or "关闭" in combined)
                ):
                    identity = _wrapper_identity(current) or stable_hash(texts)
                    if identity not in seen:
                        seen.add(identity)
                        cards.append((current, texts))
                    break
        return cards

    def _bound_job_card(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
    ) -> tuple[Any, tuple[str, ...]]:
        hint = JobBindingHint(
            title=job_ref.title,
            city=job_ref.city,
            salary=job_ref.salary,
            recruitment_type=job_ref.recruitment_type,
            company=job_ref.company,
            publish_run_id=job_ref.source_publish_run_id,
        )
        candidates: list[tuple[Any, tuple[str, ...]]] = []
        for card, texts in self._job_cards(session, hint):
            combined = " ".join(texts)
            if job_ref.city and job_ref.city not in combined:
                continue
            if job_ref.salary:
                salary_digits = re.findall(r"\d+", job_ref.salary)
                if salary_digits and not all(
                    number in combined for number in salary_digits
                ):
                    continue
            candidates.append((card, texts))
        if len(candidates) != 1:
            raise AmbiguousJob(
                f"开放职位卡必须唯一，实际匹配 {len(candidates)} 个",
                context=ErrorContext(
                    step="bound_job_card",
                    details={
                        "job_key": job_ref.job_key,
                        "title": job_ref.title,
                        "candidate_count": len(candidates),
                    },
                ),
            )
        return candidates[0]

    def _job_edit_form_scope(
        self, session: BossCandidateSession
    ) -> Any:
        required = {"职位名称", "职位描述", "学历", "实习要求"}
        matched: dict[str, Any] = {}
        for document in session.find_all(
            {"control_type": "Document"}, actionable_only=False
        ):
            texts = set(session.texts_within(document, limit=500))
            if not required <= texts:
                continue
            edits = session.find_all(
                {"control_type": "Edit"},
                scope=document,
                actionable_only=False,
            )
            if len(edits) < 2:
                continue
            identity = _wrapper_identity(document) or stable_hash(
                "job-edit-form", sorted(texts)
            )
            matched[identity] = document
        if not matched:
            raise AccessibilityUnavailable(
                "岗位编辑表单 Document 未找到",
                context=ErrorContext(
                    step="job_scoring_form_scope",
                    details={"document_count": 0},
                ),
            )
        if len(matched) == 1:
            return next(iter(matched.values()))

        # Electron may expose the same semantic form through nested Documents:
        # the root renderer, the page document, and the content document.
        # Select the smallest visible semantic scope rather than failing merely
        # because ancestors repeat the same descendants.  This remains UIA-
        # semantic and DPI/window-size independent; no fixed coordinate is used.
        ranked: list[tuple[int, int, str, Any]] = []
        for identity, document in matched.items():
            try:
                rect = document.rectangle()
                width = max(0, rect.right - rect.left)
                height = max(0, rect.bottom - rect.top)
                area = width * height
            except Exception:
                area = 0
            try:
                text_count = len(session.texts_within(document, limit=500))
            except Exception:
                text_count = 10**9
            # Zero-area scopes are hidden/stale and rank last.  A smaller
            # positive area is the more specific nested content Document.
            ranked.append((0 if area > 0 else 1, area if area > 0 else 10**18, text_count, identity, document))
        ranked.sort(key=lambda item: item[:4])
        best = ranked[0]
        if len(ranked) > 1 and best[:3] == ranked[1][:3]:
            raise AccessibilityUnavailable(
                f"岗位编辑表单 Document 无法唯一消歧，实际为 {len(matched)}",
                context=ErrorContext(
                    step="job_scoring_form_scope",
                    details={"document_count": len(matched)},
                ),
            )
        return best[4]

    @staticmethod
    def _control_value(control: Any) -> str:
        readers = []
        try:
            get_value = getattr(control, "get_value", None)
        except Exception:
            get_value = None
        if callable(get_value):
            readers.append(get_value)
        try:
            iface_value = getattr(control, "iface_value", None)
        except Exception:
            iface_value = None
        if iface_value is not None:
            readers.append(lambda: iface_value.CurrentValue)
        try:
            legacy = getattr(control, "legacy_properties", None)
        except Exception:
            legacy = None
        if callable(legacy):
            readers.append(lambda: (legacy() or {}).get("Value"))
        readers.append(control.window_text)
        for reader in readers:
            try:
                value = reader()
            except Exception:
                continue
            if value is not None and str(value).strip():
                return str(value).strip()
        return ""

    def _job_form_label(
        self,
        session: BossCandidateSession,
        form: Any,
        label: str,
    ) -> Any:
        controls = session.find_all(
            {"title": label, "control_type": "Text"},
            scope=form,
            actionable_only=False,
        )
        if len(controls) != 1:
            raise AccessibilityUnavailable(
                f"岗位编辑表单字段“{label}”必须唯一，实际为 {len(controls)}",
                context=ErrorContext(
                    step="job_scoring_form_label",
                    details={"label": label, "count": len(controls)},
                ),
            )
        return controls[0]

    def _job_form_edit_value(
        self,
        session: BossCandidateSession,
        form: Any,
        label: str,
    ) -> str:
        anchor = self._job_form_label(session, form, label)
        current = anchor
        for _ in range(7):
            try:
                current = current.parent()
            except Exception:
                break
            edits = session.find_all(
                {"control_type": "Edit"},
                scope=current,
                actionable_only=False,
            )
            valued = [
                (control, value)
                for control in edits
                if (value := self._control_value(control))
            ]
            if len(valued) == 1:
                return valued[0][1]

        # Some Electron builds flatten the field row in UIA.  Fall back to
        # relative geometry scaled by the actual label/input dimensions; no
        # fixed pixel, screen coordinate, DPI, or window-size constant is used.
        anchor_rect = anchor.rectangle()
        anchor_height = max(1, anchor_rect.bottom - anchor_rect.top)
        anchor_width = max(1, anchor_rect.right - anchor_rect.left)
        anchor_center = (anchor_rect.top + anchor_rect.bottom) / 2
        candidates: list[tuple[float, Any]] = []
        for control in session.find_all(
            {"control_type": "Edit"},
            scope=form,
            actionable_only=False,
        ):
            rect = control.rectangle()
            control_height = max(1, rect.bottom - rect.top)
            if rect.left < anchor_rect.right - anchor_width * 0.1:
                continue
            center = (rect.top + rect.bottom) / 2
            distance = min(
                abs(rect.top - anchor_rect.top),
                abs(center - anchor_center),
            )
            if distance <= max(anchor_height * 4, control_height * 2):
                candidates.append(
                    (
                        distance
                        + (
                            max(0, rect.left - anchor_rect.right)
                            / anchor_width
                        )
                        * 0.01,
                        control,
                    )
                )
        candidates.sort(key=lambda item: item[0])
        if not candidates or (
            len(candidates) > 1
            and abs(candidates[0][0] - candidates[1][0]) < 0.1
        ):
            raise AccessibilityUnavailable(
                f"岗位编辑表单字段“{label}”关联输入框不唯一",
                context=ErrorContext(
                    step="job_scoring_form_edit",
                    details={"label": label, "count": len(candidates)},
                ),
            )
        value = self._control_value(candidates[0][1])
        if not value:
            raise AccessibilityUnavailable(
                f"岗位编辑表单字段“{label}”回读为空"
            )
        return value

    def _job_form_group_values(
        self,
        session: BossCandidateSession,
        form: Any,
        label: str,
        *,
        required_patterns: tuple[str, ...],
    ) -> tuple[str, ...]:
        anchor = self._job_form_label(session, form, label)

        def values_within(scope: Any) -> tuple[str, ...]:
            values: list[str] = []
            for control in session.find_all(
                {"control_type": "Group"},
                scope=scope,
                actionable_only=False,
            ):
                values.append(self._control_value(control))
            values.extend(session.texts_within(scope, limit=80))
            normalized = tuple(
                dict.fromkeys(
                    value
                    for raw in values
                    if (value := normalize_text(raw))
                )
            )
            if all(
                any(re.search(pattern, value) for value in normalized)
                for pattern in required_patterns
            ):
                return normalized
            return ()

        # Prefer the smallest UIA ancestor containing both the field label and
        # all required values.  This follows semantic ownership and is stable
        # across screen sizes, DPI settings, fonts, and window placement.
        current = anchor
        for _ in range(7):
            try:
                current = current.parent()
            except Exception:
                break
            values = values_within(current)
            if values:
                return values

        # Flattened UIA fallback: associate groups on the same scaled row.
        anchor_rect = anchor.rectangle()
        anchor_height = max(1, anchor_rect.bottom - anchor_rect.top)
        anchor_width = max(1, anchor_rect.right - anchor_rect.left)
        anchor_center = (anchor_rect.top + anchor_rect.bottom) / 2
        values: list[str] = []
        for control in session.find_all(
            {"control_type": "Group"},
            scope=form,
            actionable_only=False,
        ):
            rect = control.rectangle()
            height = max(1, rect.bottom - rect.top)
            center = (rect.top + rect.bottom) / 2
            if (
                rect.left < anchor_rect.right - anchor_width * 0.1
                or abs(center - anchor_center)
                > max(anchor_height * 3, height * 1.5)
            ):
                continue
            raw_values = [self._control_value(control)]
            raw_values.extend(session.texts_within(control, limit=30))
            values.extend(
                normalized
                for value in raw_values
                if (normalized := normalize_text(value))
            )
        return tuple(dict.fromkeys(values))

    def read_job_scoring_context(
        self, job_ref: JobRef
    ) -> dict[str, Any]:
        """Read scoring fields from one bound open job without saving it."""

        with self._connected() as session:
            self._navigate(session, selectors.NAV_JOBS, label="职位")
            try:
                self._click_label(
                    session,
                    selectors.JOBS_OPEN_TAB,
                    label="开放中",
                )
            except AccessibilityUnavailable:
                pass
            if not session.wait_for(
                lambda: bool(
                    session.find_all(
                        {"title": job_ref.title, "control_type": "Text"},
                        actionable_only=False,
                    )
                ),
                timeout=session.wait_timeout,
            ):
                raise AmbiguousJob(f"开放职位中未找到：{job_ref.title}")
            card, card_texts = self._bound_job_card(session, job_ref)
            edit = session.find_unique(
                selectors.JOB_EDIT,
                label="绑定岗位卡内编辑",
                scope=card,
                actionable_only=True,
            )
            session.invoke(edit)
            session.refresh()
            form: Any | None = None

            def form_is_ready() -> bool:
                nonlocal form
                try:
                    form = self._job_edit_form_scope(session)
                except AccessibilityUnavailable:
                    return False
                return True

            if not session.wait_for(
                form_is_ready, timeout=session.wait_timeout
            ) or form is None:
                raise AccessibilityUnavailable("岗位编辑表单没有稳定加载")

            title = normalize_text(
                self._job_form_edit_value(
                    session, form, "职位名称"
                )
            )
            description = self._job_form_edit_value(
                session, form, "职位描述"
            )
            if title != job_ref.title:
                raise ContextMismatch("岗位编辑表单标题与绑定岗位不一致")

            education_values = self._job_form_group_values(
                session,
                form,
                "学历",
                required_patterns=(
                    r"不限|初中及以下|中专/中技|高中|大专|本科|硕士|博士",
                ),
            )
            education_levels = {
                match.group(0)
                for value in education_values
                for match in re.finditer(
                    r"不限|初中及以下|中专/中技|高中|大专|本科|硕士|博士",
                    value,
                )
            }
            if len(education_levels) != 1:
                raise AccessibilityUnavailable(
                    "岗位编辑表单学历回读必须唯一",
                    context=ErrorContext(
                        step="job_scoring_education",
                        details={"values": sorted(education_levels)},
                    ),
                )
            education = next(iter(education_levels))

            internship_values = self._job_form_group_values(
                session,
                form,
                "实习要求",
                required_patterns=(r"\d+\s*个月", r"\d+\s*天"),
            )
            months = {
                int(match.group(1))
                for value in internship_values
                for match in re.finditer(r"(\d+)\s*个月", value)
            }
            days = {
                int(match.group(1))
                for value in internship_values
                for match in re.finditer(r"(\d+)\s*天", value)
            }
            if len(months) != 1 or len(days) != 1:
                raise AccessibilityUnavailable(
                    "岗位编辑表单实习要求回读必须唯一",
                    context=ErrorContext(
                        step="job_scoring_internship",
                        details={
                            "months": sorted(months),
                            "days_per_week": sorted(days),
                        },
                    ),
                )
            internship = {
                "minimum_months": next(iter(months)),
                "days_per_week": next(iter(days)),
            }
            scoring_fields = {
                "title": title,
                "description": description,
                "education": education,
                "internship": internship,
            }
            source_hash = hashlib.sha256(
                json.dumps(
                    scoring_fields,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode("utf-8")
            ).hexdigest()
            self._last_job = job_ref
            return {
                "job_key": job_ref.job_key,
                **scoring_fields,
                "source": "boss_job_edit_form",
                "source_hash": source_hash,
                "evidence": [
                    f"开放职位卡精确标题={job_ref.title}",
                    f"职位卡摘要哈希={stable_hash(card_texts)}",
                    "岗位卡编辑控件=唯一",
                    f"职位描述哈希={stable_hash(description)}",
                    f"学历={education}",
                    (
                        "实习要求="
                        f"{internship['minimum_months']}个月/"
                        f"每周{internship['days_per_week']}天"
                    ),
                    "表单提交动作=未调用",
                ],
            }

    def bind_published_job(self, hint: JobBindingHint) -> JobRef:
        with self._connected() as session:
            self._navigate(
                session, selectors.NAV_JOBS, label="职位"
            )
            try:
                self._click_label(
                    session,
                    selectors.JOBS_OPEN_TAB,
                    label="开放中",
                )
            except AccessibilityUnavailable:
                # Already on the open list may expose the selected tab as
                # disabled/non-actionable. The card evidence below is decisive.
                pass
            if not session.wait_for(
                lambda: bool(
                    session.find_all(
                        {"title": hint.title, "control_type": "Text"}
                    )
                ),
                timeout=session.wait_timeout,
            ):
                raise AmbiguousJob(f"开放职位中未找到：{hint.title}")
            candidates = []
            for card, texts in self._job_cards(session, hint):
                combined = " ".join(texts)
                if hint.city and hint.city not in combined:
                    continue
                if hint.salary:
                    salary_digits = re.findall(r"\d+", hint.salary)
                    if salary_digits and not all(
                        number in combined for number in salary_digits
                    ):
                        continue
                candidates.append((card, texts))
            if len(candidates) != 1:
                raise AmbiguousJob(
                    f"职位绑定必须唯一，实际匹配 {len(candidates)} 个",
                    context=ErrorContext(
                        step="bind_job",
                        details={
                            "title": hint.title,
                            "candidate_count": len(candidates),
                        },
                    ),
                )
            card, texts = candidates[0]
            platform_identity = _wrapper_identity(card)
            platform_job_id = (
                platform_identity.removeprefix("automation:")
                if platform_identity
                and platform_identity.startswith("automation:")
                else None
            )
            job_key = stable_hash(
                platform_job_id
                or (
                    hint.company,
                    hint.title,
                    hint.city,
                    hint.salary,
                    hint.recruitment_type,
                    hint.submitted_at,
                )
            )
            evidence = (
                f"开放职位卡精确标题={hint.title}",
                f"职位卡状态=开放中",
                f"职位卡摘要哈希={stable_hash(texts)}",
            )
            job = JobRef(
                job_key=job_key,
                platform_job_id=platform_job_id,
                title=hint.title,
                city=hint.city,
                salary=hint.salary,
                status="开放中",
                company=hint.company,
                recruitment_type=hint.recruitment_type,
                binding_strength=(
                    BindingStrength.EXACT
                    if platform_job_id
                    else BindingStrength.STRONG
                ),
                binding_evidence=evidence,
                source_publish_run_id=hint.publish_run_id,
            )
            self._last_job = job
            return job

    def _job_context_values(
        self, session: BossCandidateSession
    ) -> tuple[str, ...]:
        values: list[str] = []
        for control_type in ("ComboBox", "Text"):
            controls = session.find_all(
                {"control_type": control_type},
                actionable_only=False,
            )
            for control in controls[:80]:
                candidates = [
                    getattr(control.element_info, "name", ""),
                ]
                try:
                    candidates.append(control.window_text())
                except Exception:
                    pass
                try:
                    candidates.append(control.get_value())
                except Exception:
                    pass
                for value in candidates:
                    text = normalize_text(value)
                    if text:
                        values.append(text)
        return tuple(values)

    def verify_job_context(self, job_ref: JobRef) -> tuple[str, ...]:
        with self._connected() as session:
            if self._on_messages_surface(session):
                selected = self._message_job_selector_controls(
                    session, job_ref
                )
                if len(selected) == 1:
                    evidence = (
                        f"消息页当前岗位={job_ref.title}",
                        f"岗位选择器哈希={stable_hash(self._control_value(selected[0]))}",
                    )
                    self._last_job = job_ref
                    return evidence
                if len(selected) > 1:
                    raise ContextMismatch(
                        f"消息页当前岗位选择器不唯一，实际为 {len(selected)}"
                    )
                # Do not treat a candidate row or chat line containing the
                # job title as selected-job evidence. Rebind from Jobs below.
            else:
                values = self._job_context_values(session)
                matching = [
                    value
                    for value in values
                    if job_ref.title in value
                    and (not job_ref.city or job_ref.city in value)
                ]
                if matching:
                    evidence = (
                        f"当前岗位控件包含={job_ref.title}",
                        f"岗位上下文哈希={stable_hash(matching)}",
                    )
                    self._last_job = job_ref
                    return evidence
            # A page without a job selector is verified by returning to the
            # job list and checking the exact open card.
            hint = JobBindingHint(
                title=job_ref.title,
                city=job_ref.city,
                salary=job_ref.salary,
                recruitment_type=job_ref.recruitment_type,
                company=job_ref.company,
                publish_run_id=job_ref.source_publish_run_id,
            )
        rebound = self.bind_published_job(hint)
        if rebound.job_key != job_ref.job_key:
            raise ContextMismatch("重新核验后的岗位与已绑定岗位不一致")
        return rebound.binding_evidence

    def _select_job(
        self, session: BossCandidateSession, job_ref: JobRef
    ) -> None:
        selected = self._message_job_selector_controls(session, job_ref)
        if len(selected) == 1:
            return
        if len(selected) > 1:
            raise ContextMismatch(
                f"消息页当前岗位选择器不唯一，实际为 {len(selected)}"
            )
        combo_boxes = session.find_all(
            {"control_type": "ComboBox"}, actionable_only=True
        )
        candidates: list[Any] = []
        for combo in combo_boxes:
            current = ""
            try:
                current = normalize_text(combo.get_value())
            except Exception:
                try:
                    current = normalize_text(combo.window_text())
                except Exception:
                    pass
            if (
                ("职位" in current or current == "" or current == "全部职位")
                and self._message_job_selector_region_matches(
                    session, combo
                )
            ):
                candidates.append(combo)
        if not candidates:
            # Electron exposes this selector as an actionable Text in
            # BOSS 1.7.4.963 rather than as a ComboBox.
            for control in session.find_all(
                {"control_type": "Text"}, actionable_only=True
            ):
                control_values = [
                    getattr(control.element_info, "name", ""),
                ]
                try:
                    control_values.append(control.window_text())
                except Exception:
                    pass
                if any(
                    (value := normalize_text(item)) == "全部职位"
                    or (
                        " _ " in value
                        and ("元/天" in value or "K" in value)
                    )
                    for item in control_values
                ) and self._message_job_selector_region_matches(
                    session, control
                ):
                    candidates.append(control)
        if len(candidates) != 1:
            raise ContextMismatch(
                f"岗位选择器必须唯一，实际为 {len(candidates)}"
            )
        session.invoke(candidates[0])
        session.refresh()
        text_controls = session.find_all(
            {"control_type": "Text"}, actionable_only=True
        )
        items: dict[str, Any] = {}
        for control in text_controls:
            value = normalize_text(
                getattr(control.element_info, "name", "")
            )
            if not value:
                value = normalize_text(control.window_text())
            if not _job_selector_value_matches(value, job_ref):
                continue
            try:
                parent = control.parent()
            except Exception:
                continue
            if (
                getattr(parent.element_info, "control_type", "")
                != "ListItem"
            ):
                continue
            identity = _wrapper_identity(parent) or f"object:{id(parent)}"
            items[identity] = parent
        if len(items) != 1:
            raise ContextMismatch(
                f"岗位下拉项必须唯一，实际为 {len(items)}"
            )
        session.invoke(next(iter(items.values())))
        session.refresh()
        if not session.wait_for(
            lambda: len(
                self._message_job_selector_controls(session, job_ref)
            )
            == 1,
            timeout=session.wait_timeout,
        ):
            raise ContextMismatch("切换岗位后无法回读当前岗位")

    def _card_from_anchor(
        self,
        session: BossCandidateSession,
        anchor: Any,
        anchor_label: str,
    ) -> Any:
        return self._ancestor_with_texts(
            session, anchor, required=(anchor_label,)
        )

    def _candidate_snapshot(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        card: Any,
        *,
        source: str,
    ) -> CandidateSnapshot:
        texts = _safe_visible_texts(session.texts_within(card))
        name = _likely_name(texts)
        strong_identity = _wrapper_identity(card)
        if strong_identity and strong_identity.startswith("automation:"):
            candidate_key = stable_hash("candidate", strong_identity)
            platform_candidate_id = strong_identity.removeprefix("automation:")
            confidence = IdentityConfidence.EXACT
        elif strong_identity:
            candidate_key = stable_hash("candidate", job_ref.job_key, strong_identity)
            platform_candidate_id = None
            confidence = IdentityConfidence.STRONG
        else:
            # Source is deliberately included so weak fingerprints from two
            # channels are not auto-merged. A later identity resolver can merge
            # them after stronger evidence appears.
            candidate_key = stable_hash(
                "weak-candidate", job_ref.job_key, source, name, texts
            )
            platform_candidate_id = None
            confidence = IdentityConfidence.POSSIBLE
        ref = CandidateRef(
            candidate_key=candidate_key,
            job_key=job_ref.job_key,
            display_name=name,
            platform_candidate_id=platform_candidate_id,
            conversation_id=(
                strong_identity
                if source.startswith("messages.")
                or source.startswith("interactions.")
                else None
            ),
            identity_confidence=confidence,
        )
        profile = _profile_from_texts(texts)
        profile["_ui_source"] = source
        profile["_card_hash"] = stable_hash(texts)
        if source.startswith("messages."):
            profile["latest_message_preview"] = _message_preview(
                texts,
                candidate_name=name,
                job_title=job_ref.title,
            )
        snapshot = CandidateSnapshot.create(
            ref,
            source=source,
            profile=profile,
            evidence_refs=(f"uia-card:{profile['_card_hash']}",),
        )
        return snapshot

    def _scroll_once(self, card: Any) -> bool:
        current = card
        for _ in range(8):
            try:
                current = current.parent()
            except Exception:
                break
            try:
                current.iface_scroll.Scroll(2, 3)
                return True
            except Exception:
                continue
        return False

    def _collect_by_action(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        *,
        action_selectors: Iterable[dict[str, Any]],
        action_label: str,
        source: str,
        cursor: str | None,
        limit: int,
    ) -> tuple[tuple[CandidateSnapshot, ...], str | None]:
        offset = _cursor_offset(cursor)
        target = offset + max(1, limit) + 1
        found: dict[str, CandidateSnapshot] = {}
        previous_signature = None
        stalled = 0
        exhausted = False
        for _ in range(max(20, min(100, target))):
            anchors = session.find_all_alternatives(
                action_selectors, actionable_only=True
            )
            cards = []
            for anchor in anchors:
                try:
                    card = self._card_from_anchor(
                        session, anchor, action_label
                    )
                except AccessibilityUnavailable:
                    continue
                cards.append(card)
                snapshot = self._candidate_snapshot(
                    session, job_ref, card, source=source
                )
                found.setdefault(
                    snapshot.candidate_ref.candidate_key, snapshot
                )
                if len(found) >= target:
                    break
            if len(found) >= target:
                break
            if not cards:
                exhausted = True
                break
            signature = tuple(sorted(found))
            if signature == previous_signature:
                stalled += 1
            else:
                stalled = 0
            if stalled >= 2 or not self._scroll_once(cards[-1]):
                exhausted = True
                break
            previous_signature = signature
            time.sleep(0.35)
            session.refresh()
        all_items = tuple(found.values())
        return _offset_page(
            all_items, cursor, limit, exhausted=exhausted
        )

    def scan_recommendations(
        self,
        job_ref: JobRef,
        *,
        cursor: str | None,
        limit: int,
    ) -> CandidatePage:
        with self._connected() as session:
            self._navigate(
                session,
                selectors.NAV_RECOMMENDATIONS,
                label="推荐",
            )
            self._select_job(session, job_ref)
            if not session.wait_for(
                lambda: bool(
                    session.find_all_alternatives(
                        selectors.GREET, actionable_only=True
                    )
                ),
                timeout=session.wait_timeout,
            ):
                items: tuple[CandidateSnapshot, ...] = ()
                next_cursor = None
            else:
                items, next_cursor = self._collect_by_action(
                    session,
                    job_ref,
                    action_selectors=selectors.GREET,
                    action_label="打招呼",
                    source="recommendations",
                    cursor=cursor,
                    limit=limit,
                )
            return CandidatePage(
                job_ref=job_ref,
                channel="recommendations",
                items=items,
                next_cursor=next_cursor,
                context_evidence=(
                    f"当前岗位={job_ref.title}",
                    "推荐页岗位选择器已回读",
                ),
            )

    def scan_interactions(
        self,
        job_ref: JobRef,
        *,
        cursor: str | None,
        limit: int,
    ) -> CandidatePage:
        with self._connected() as session:
            self._navigate(session, selectors.NAV_MORE, label="更多")
            try:
                self._click_label(
                    session,
                    selectors.INTERACTION_COMMUNICATED,
                    label="沟通过",
                )
            except AccessibilityUnavailable:
                pass
            self._select_job(session, job_ref)
            items, next_cursor = self._collect_by_action(
                session,
                job_ref,
                action_selectors=selectors.CONTINUE_CHAT,
                action_label="继续沟通",
                source="interactions.communicated",
                cursor=cursor,
                limit=limit,
            )
            return CandidatePage(
                job_ref=job_ref,
                channel="interactions",
                items=items,
                next_cursor=next_cursor,
                context_evidence=(
                    f"当前岗位={job_ref.title}",
                    "互动页标签=沟通过",
                ),
            )

    def _message_rows(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        *,
        cursor: str | None,
        limit: int,
        source: str,
    ) -> tuple[tuple[CandidateSnapshot, ...], str | None]:
        offset = _cursor_offset(cursor)
        target = offset + max(1, limit) + 1
        found: dict[str, CandidateSnapshot] = {}
        previous_signature = None
        stalled = 0
        exhausted = False
        for _ in range(max(20, min(100, target))):
            matched_rows = []
            for row in self._candidate_message_rows(session):
                texts = _safe_visible_texts(
                    session.texts_within(row)
                )
                if not texts:
                    continue
                matched_rows.append(row)
                snapshot = self._candidate_snapshot(
                    session, job_ref, row, source=source
                )
                found.setdefault(
                    snapshot.candidate_ref.candidate_key, snapshot
                )
                if len(found) >= target:
                    break
            if len(found) >= target:
                break
            if not matched_rows:
                exhausted = True
                break
            signature = tuple(sorted(found))
            if signature == previous_signature:
                stalled += 1
            else:
                stalled = 0
            if (
                stalled >= 2
                or not self._scroll_once(matched_rows[-1])
            ):
                exhausted = True
                break
            previous_signature = signature
            time.sleep(0.35)
            session.refresh()
        all_items = tuple(found.values())
        return _offset_page(
            all_items, cursor, limit, exhausted=exhausted
        )

    def _candidate_message_rows(
        self, session: BossCandidateSession
    ) -> list[Any]:
        rows = []
        for row in session.find_all(
            {"control_type": "ListItem"}, actionable_only=True
        ):
            if normalize_text(
                getattr(row.element_info, "automation_id", "")
            ).startswith("mid-"):
                continue
            texts = _safe_visible_texts(session.texts_within(row))
            if not any(
                re.fullmatch(
                    r"(?:\d{1,2}:\d{2}|昨天|前天|"
                    r"星期[一二三四五六日天]|\d{1,2}月\d{1,2}日)",
                    text,
                )
                for text in texts
            ):
                continue
            rows.append(row)
        return rows

    def scan_new_greetings(
        self,
        job_ref: JobRef,
        *,
        cursor: str | None,
        limit: int,
    ) -> CandidatePage:
        with self._connected() as session:
            self._navigate(session, selectors.NAV_MESSAGES, label="消息")
            self._select_job(session, job_ref)
            self._click_message_header_tab(
                session,
                job_ref,
                selectors.MESSAGES_NEW_GREETINGS,
                label="新招呼",
            )
            session.wait_for(
                lambda: bool(self._candidate_message_rows(session)),
                timeout=min(2.0, session.wait_timeout),
            )
            session.refresh()
            items, next_cursor = self._message_rows(
                session,
                job_ref,
                cursor=cursor,
                limit=limit,
                source="messages.new_greetings",
            )
            return CandidatePage(
                job_ref=job_ref,
                channel="new_greetings",
                items=items,
                next_cursor=next_cursor,
                context_evidence=(
                    f"当前岗位={job_ref.title}",
                    "消息标签=新招呼",
                ),
            )

    def _message_row_on_current_page(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> Any | None:
        rows = self._candidate_message_rows(session)
        matches = []
        for row in rows:
            identity = _wrapper_identity(row)
            texts = _safe_visible_texts(session.texts_within(row))
            if (
                candidate_ref.conversation_id
                and identity == candidate_ref.conversation_id
            ):
                matches.append(row)
                continue
            if (
                not candidate_ref.conversation_id
                and candidate_ref.display_name
                and candidate_ref.display_name in texts
                and job_ref.title in texts
            ):
                matches.append(row)
        unique: dict[str, Any] = {}
        for row in matches:
            unique[_wrapper_identity(row) or stable_hash(
                session.texts_within(row)
            )] = row
        if len(unique) > 1:
            raise CandidateIdentityConflict(
                f"消息列表中候选人会话不唯一，实际为 {len(unique)}"
            )
        return next(iter(unique.values()), None)

    def _find_message_row(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> Any | None:
        previous_signature = None
        stalled = 0
        for _ in range(20):
            row = self._message_row_on_current_page(
                session, job_ref, candidate_ref
            )
            if row is not None:
                return row
            candidate_rows = self._candidate_message_rows(session)
            signature = tuple(
                _wrapper_identity(item) or stable_hash(
                    session.texts_within(item)
                )
                for item in candidate_rows
            )
            if signature == previous_signature:
                stalled += 1
            else:
                stalled = 0
            if (
                not candidate_rows
                or stalled >= 2
                or not self._scroll_once(candidate_rows[-1])
            ):
                return None
            previous_signature = signature
            time.sleep(0.35)
            session.refresh()
        return None

    def _open_message_candidate(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> tuple[Any, str | None, str]:
        current = self._current_conversation_context(session)
        if current is not None:
            scope, texts, name, _, anchor_id, anchor_text = current
            anchor_matches = (
                candidate_ref.conversation_id == anchor_id
            )
            name_matches = (
                not candidate_ref.display_name
                or candidate_ref.display_name == name
            )
            if (
                anchor_matches
                and name_matches
                and any(job_ref.title in value for value in texts)
            ):
                return scope, anchor_text, "已绑定会话"
        self._navigate(session, selectors.NAV_MESSAGES, label="消息")
        self._select_job(session, job_ref)
        for tab_selectors, label, is_header_tab in (
            (selectors.MESSAGES_NEW_GREETINGS, "新招呼", True),
            (selectors.MESSAGES_UNREAD, "未读", False),
            (selectors.MESSAGES_IN_PROGRESS, "沟通中", True),
            (selectors.MESSAGES_INTERVIEWED, "已约面", True),
            (selectors.MESSAGES_ALL, "全部", True),
        ):
            try:
                if is_header_tab:
                    self._click_message_header_tab(
                        session,
                        job_ref,
                        tab_selectors,
                        label=label,
                    )
                else:
                    self._click_label(
                        session, tab_selectors, label=label
                    )
            except AccessibilityUnavailable:
                continue
            time.sleep(0.35)
            row = self._find_message_row(
                session, job_ref, candidate_ref
            )
            if row is not None:
                queue_label = label
                break
        else:
            row = None
        if row is None:
            raise CandidateIdentityConflict(
                "在消息页当前岗位的固定队列中未找到唯一候选人会话"
            )
        row_texts = _safe_visible_texts(session.texts_within(row))
        preview = _message_preview(
            row_texts,
            candidate_name=candidate_ref.display_name,
            job_title=job_ref.title,
        )
        session.activate(row)
        session.refresh()
        if not session.wait_for(
            lambda: bool(
                session.find_all_alternatives(
                    selectors.CHAT_EDITOR, actionable_only=False
                )
            ),
            timeout=session.wait_timeout,
        ):
            raise AccessibilityUnavailable("候选人聊天编辑器未加载")
        chat_scope = self._chat_scope(session)
        chat_texts = _safe_visible_texts(
            session.texts_within(chat_scope)
        )
        if (
            candidate_ref.display_name
            and candidate_ref.display_name not in chat_texts
        ):
            raise ContextMismatch("打开会话后候选人标题回读失败")
        if not any(job_ref.title in value for value in chat_texts):
            raise ContextMismatch("打开会话后沟通职位回读失败")
        return row, preview, queue_label

    def _chat_editor(self, session: BossCandidateSession) -> Any:
        editors = session.find_all_alternatives(
            selectors.CHAT_EDITOR, actionable_only=False
        )
        unique: dict[str, Any] = {}
        for editor in editors:
            unique[_wrapper_identity(editor) or stable_hash(
                session.texts_within(editor)
            )] = editor
        if len(unique) != 1:
            raise AccessibilityUnavailable(
                f"聊天编辑器必须唯一，实际为 {len(unique)}"
            )
        return next(iter(unique.values()))

    def _chat_scope(self, session: BossCandidateSession) -> Any:
        current = self._chat_editor(session)
        for _ in range(10):
            try:
                current = current.parent()
            except Exception as exc:
                raise AccessibilityUnavailable(
                    "无法建立聊天面板语义作用域"
                ) from exc
            rows = session.find_all(
                {"control_type": "ListItem"},
                scope=current,
                actionable_only=False,
            )
            has_messages = any(
                normalize_text(
                    getattr(row.element_info, "automation_id", "")
                ).startswith("mid-")
                for row in rows
            )
            sends = session.find_all_alternatives(
                selectors.SEND,
                scope=current,
                actionable_only=True,
            )
            if has_messages and len(sends) == 1:
                return current
        raise AccessibilityUnavailable(
            "聊天面板必须同时包含 mid-* 消息和唯一发送控件"
        )

    def _visible_chat_text_entries(
        self,
        session: BossCandidateSession,
        *,
        scope: Any,
    ) -> list[tuple[Any, str, Any]]:
        """Return only on-screen Text controls inside the live chat scope.

        Electron can retain Text descendants from a closed resume-preview
        Document.  Those cached nodes are excluded by visibility, non-empty
        geometry, and intersection with both the chat scope and BOSS window.
        Tree order is retained because the profile parser uses nearby labels.
        """

        try:
            scope_rect = scope.rectangle()
            window_rect = session.window.rectangle()
        except Exception as exc:
            raise AccessibilityUnavailable(
                "无法回读聊天面板可见区域"
            ) from exc
        result: list[tuple[Any, str, Any]] = []
        for control in session.find_all(
            {"control_type": "Text"},
            scope=scope,
            actionable_only=False,
        ):
            text = normalize_text(
                getattr(control.element_info, "name", "")
            )
            if not text:
                continue
            try:
                if not control.is_visible():
                    continue
                rect = control.rectangle()
            except Exception:
                continue
            if rect.right <= rect.left or rect.bottom <= rect.top:
                continue
            intersects_scope = (
                rect.right > scope_rect.left
                and rect.left < scope_rect.right
                and rect.bottom > scope_rect.top
                and rect.top < scope_rect.bottom
            )
            intersects_window = (
                rect.right > window_rect.left
                and rect.left < window_rect.right
                and rect.bottom > window_rect.top
                and rect.top < window_rect.bottom
            )
            if intersects_scope and intersects_window:
                result.append((control, text, rect))
        return result

    def _visible_chat_header_name(
        self,
        session: BossCandidateSession,
        *,
        chat_scope: Any,
        entries: list[tuple[Any, str, Any]],
    ) -> str | None:
        """Resolve the candidate name from the visible name/age header row."""

        editor_rect = self._chat_editor(session).rectangle()
        scope_rect = chat_scope.rectangle()
        top_band_bottom = scope_rect.top + max(
            1,
            (editor_rect.top - scope_rect.top) * 0.45,
        )
        header_entries = [
            (text, rect)
            for _, text, rect in entries
            if rect.bottom <= editor_rect.top
            and rect.top <= top_band_bottom
        ]
        ages = [
            (text, rect)
            for text, rect in header_entries
            if re.fullmatch(r"\d{1,3}岁", text)
        ]
        names = [
            (text, rect)
            for text, rect in header_entries
            if _likely_name((text,)) == text
            and text not in {
                "刚刚活跃",
                "今日活跃",
                "在线",
                "牛人分析器",
                "附件简历",
            }
            and not text.endswith("活跃")
        ]
        matches: list[tuple[float, str]] = []
        for _, age_rect in ages:
            age_center_y = (age_rect.top + age_rect.bottom) / 2
            age_height = age_rect.bottom - age_rect.top
            for name, name_rect in names:
                name_center_y = (name_rect.top + name_rect.bottom) / 2
                name_height = name_rect.bottom - name_rect.top
                row_height = max(1, age_height, name_height)
                horizontal_gap = age_rect.left - name_rect.right
                if (
                    abs(name_center_y - age_center_y)
                    <= row_height * 1.5
                    and -row_height <= horizontal_gap
                    <= row_height * 12
                ):
                    matches.append(
                        (
                            abs(name_center_y - age_center_y)
                            + abs(horizontal_gap),
                            name,
                        )
                    )
        if not matches:
            return None
        best_score = min(item[0] for item in matches)
        best_names = {
            name
            for score, name in matches
            if score <= best_score + 1
        }
        if len(best_names) != 1:
            raise CandidateIdentityConflict(
                "当前聊天可见资料头候选人姓名不唯一"
            )
        return next(iter(best_names))

    def _chat_message_controls(
        self,
        session: BossCandidateSession,
        *,
        scope: Any | None = None,
    ) -> list[Any]:
        chat_scope = scope or self._chat_scope(session)
        result = []
        for row in session.find_all(
            {"control_type": "ListItem"},
            scope=chat_scope,
            actionable_only=False,
        ):
            automation_id = normalize_text(
                getattr(row.element_info, "automation_id", "")
            )
            if automation_id.startswith("mid-"):
                result.append(row)
        return result

    def _current_conversation_context(
        self,
        session: BossCandidateSession,
    ) -> tuple[Any, tuple[str, ...], str, dict[str, Any], str, str] | None:
        try:
            chat_scope = self._chat_scope(session)
        except AccessibilityUnavailable:
            return None
        visible_entries = self._visible_chat_text_entries(
            session,
            scope=chat_scope,
        )
        chat_texts = _safe_visible_texts(
            text for _, text, _ in visible_entries
        )
        header_name = self._visible_chat_header_name(
            session,
            chat_scope=chat_scope,
            entries=visible_entries,
        )
        name, profile = _candidate_name_and_profile_from_chat_texts(
            chat_texts,
            preferred_name=header_name,
        )
        message_candidates: list[tuple[int, str, str]] = []
        for row in self._chat_message_controls(
            session, scope=chat_scope
        ):
            message_id = normalize_text(
                getattr(row.element_info, "automation_id", "")
            )
            match = re.fullmatch(r"mid-(\d+)", message_id)
            texts = _safe_visible_texts(session.texts_within(row))
            message_text = max(texts, key=len) if texts else ""
            if (
                not match
                or not message_text
                or re.fullmatch(r"\d{1,2}:\d{2}", message_text)
            ):
                continue
            message_candidates.append(
                (int(match.group(1)), message_id, message_text)
            )
        if not message_candidates:
            raise CandidateIdentityConflict(
                "当前聊天没有可作为会话锚点的 mid-* 正文"
            )
        # Use the oldest loaded non-timestamp message as a stable conversation
        # anchor. New replies or recruiter messages must not change identity.
        _, anchor_id, anchor_text = min(message_candidates)
        message_profile = _profile_from_texts((anchor_text,))
        for key in (
            "education",
            "major",
            "availability",
            "desired_role",
            "experience_summary",
            "skills",
        ):
            incoming = message_profile.get(key)
            existing = profile.get(key)
            if incoming in (None, "", [], {}, ()):
                continue
            if (
                existing not in (None, "", [], {}, ())
                and existing != incoming
                and isinstance(existing, str)
                and isinstance(incoming, str)
            ):
                profile[key] = f"{existing}；{incoming}"
            elif isinstance(existing, list) and isinstance(incoming, list):
                profile[key] = list(dict.fromkeys([*existing, *incoming]))
            else:
                profile[key] = incoming
        profile["latest_message_preview"] = anchor_text
        profile["_conversation_anchor"] = anchor_id
        return (
            chat_scope,
            chat_texts,
            name,
            profile,
            anchor_id,
            anchor_text,
        )

    def bind_current_conversation(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef | None = None,
    ) -> CandidateSnapshot:
        with self._connected() as session:
            current = self._current_conversation_context(session)
            if current is None:
                raise CandidateIdentityConflict(
                    "当前没有已打开的唯一候选人会话"
                )
            _, texts, name, profile, anchor_id, _ = current
            if not any(job_ref.title in value for value in texts):
                raise ContextMismatch("当前聊天的沟通职位与绑定岗位不一致")
            if (
                candidate_ref
                and candidate_ref.display_name
                and candidate_ref.display_name != name
            ):
                raise CandidateIdentityConflict(
                    "当前聊天候选人与已有候选人记录不一致"
                )
            resolved_ref = CandidateRef(
                candidate_key=(
                    candidate_ref.candidate_key
                    if candidate_ref
                    else stable_hash(
                        "candidate",
                        job_ref.job_key,
                        anchor_id,
                    )
                ),
                job_key=job_ref.job_key,
                display_name=name,
                platform_candidate_id=(
                    candidate_ref.platform_candidate_id
                    if candidate_ref
                    else None
                ),
                conversation_id=anchor_id,
                identity_confidence=IdentityConfidence.STRONG,
            )
            return CandidateSnapshot.create(
                resolved_ref,
                source="messages.current_conversation",
                profile=profile,
                evidence_refs=(
                    f"conversation-anchor:{anchor_id}",
                    f"chat-context:{stable_hash(texts)}",
                ),
            )

    def _read_open_conversation(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        *,
        preview: str | None,
        queue_label: str,
        expected_inbound_message_id: str | None = None,
    ) -> ConversationSnapshot:
        chat_scope = self._chat_scope(session)
        messages = []
        inbound_candidates: list[tuple[str, str]] = []
        for row in self._chat_message_controls(
            session, scope=chat_scope
        ):
            automation_id = normalize_text(
                getattr(row.element_info, "automation_id", "")
            )
            texts = _safe_visible_texts(session.texts_within(row))
            message_text = max(texts, key=len) if texts else ""
            if not message_text:
                continue
            if re.fullmatch(r"\d{1,2}:\d{2}", message_text):
                continue
            if "沟通的职位" in message_text:
                direction = ConversationDirection.SYSTEM
            elif any(
                marker in text
                for text in texts
                for marker in (
                    "已读",
                    "未读",
                    "送达",
                    "发送中",
                    "发送失败",
                )
            ):
                direction = ConversationDirection.OUTBOUND
            elif (
                queue_label in {"新招呼", "未读"}
                and preview
                and normalize_text(message_text)
                == normalize_text(preview)
            ):
                direction = ConversationDirection.INBOUND
                inbound_candidates.append(
                    (automation_id, message_text)
                )
            elif (
                queue_label not in {"新招呼", "未读"}
                and expected_inbound_message_id
                and automation_id == expected_inbound_message_id
            ):
                direction = ConversationDirection.INBOUND
                inbound_candidates.append(
                    (automation_id, message_text)
                )
            elif queue_label == "已绑定会话":
                direction = ConversationDirection.INBOUND
                inbound_candidates.append(
                    (automation_id, message_text)
                )
            else:
                direction = ConversationDirection.UNKNOWN
            messages.append(
                ConversationMessage(
                    message_id=automation_id,
                    text=message_text,
                    direction=direction,
                )
            )
        numeric_candidates = []
        for message_id, message_text in inbound_candidates:
            match = re.fullmatch(r"mid-(\d+)", message_id)
            if match:
                numeric_candidates.append(
                    (int(match.group(1)), message_id, message_text)
                )
        if numeric_candidates:
            _, latest_inbound_id, latest_inbound_text = max(
                numeric_candidates
            )
        elif len(inbound_candidates) == 1:
            latest_inbound_id, latest_inbound_text = (
                inbound_candidates[0]
            )
        else:
            latest_inbound_id = None
            latest_inbound_text = None
        return ConversationSnapshot(
            job_key=job_ref.job_key,
            candidate_ref=candidate_ref,
            observed_at=utc_now(),
            messages=tuple(messages),
            latest_inbound_message_id=latest_inbound_id,
            latest_inbound_text=latest_inbound_text,
            evidence=(
                f"当前岗位={job_ref.title}",
                f"候选人={candidate_ref.candidate_key}",
                "聊天编辑器=boss-chat-editor-input",
                f"消息队列={queue_label}",
                f"语义消息数={len(messages)}",
            ),
        )

    def read_conversation(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        *,
        expected_inbound_message_id: str | None = None,
    ) -> ConversationSnapshot:
        with self._connected() as session:
            _, preview, queue_label = self._open_message_candidate(
                session, job_ref, candidate_ref
            )
            if (
                expected_inbound_message_id is None
                and candidate_ref.conversation_id
                and candidate_ref.conversation_id.startswith("mid-")
            ):
                expected_inbound_message_id = candidate_ref.conversation_id
            return self._read_open_conversation(
                session,
                job_ref,
                candidate_ref,
                preview=preview,
                queue_label=queue_label,
                expected_inbound_message_id=(
                    expected_inbound_message_id
                ),
            )

    def _find_candidate_card(
        self,
        session: BossCandidateSession,
        candidate_ref: CandidateRef,
    ) -> Any:
        if not candidate_ref.display_name:
            raise CandidateIdentityConflict(
                "候选人缺少可重新定位的显示名或平台 ID"
            )
        controls = session.find_all(
            {
                "title": candidate_ref.display_name,
                "control_type": "Text",
            },
            actionable_only=True,
        )
        if len(controls) != 1:
            raise CandidateIdentityConflict(
                f"候选人重新定位必须唯一，实际为 {len(controls)}"
            )
        control = controls[0]
        current = control
        for _ in range(8):
            try:
                current = current.parent()
            except Exception:
                break
            texts = _safe_visible_texts(session.texts_within(current))
            if candidate_ref.display_name in texts and len(texts) >= 3:
                return current
        return control

    def read_message_candidate_profile(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> CandidateSnapshot:
        """Open one exact Messages conversation and read its visible profile."""

        with self._connected() as session:
            _, _, queue_label = self._open_message_candidate(
                session, job_ref, candidate_ref
            )
            current = self._current_conversation_context(session)
            if current is None:
                raise CandidateIdentityConflict(
                    "打开消息会话后没有唯一候选人画像"
                )
            _, texts, name, profile, anchor_id, _ = current
            if not any(job_ref.title in value for value in texts):
                raise ContextMismatch("当前消息画像的沟通职位与绑定岗位不一致")
            if (
                candidate_ref.display_name
                and name != candidate_ref.display_name
            ):
                raise CandidateIdentityConflict(
                    "当前消息画像姓名与目标候选人不一致"
                )
            profile = dict(profile)
            profile["visible_job_facts"] = _visible_job_facts(
                texts,
                candidate_name=name,
                job_title=job_ref.title,
            )
            resolved_ref = CandidateRef(
                candidate_key=candidate_ref.candidate_key,
                job_key=job_ref.job_key,
                display_name=name,
                platform_candidate_id=(
                    candidate_ref.platform_candidate_id
                ),
                # Keep the message-row identity used to reopen this exact
                # conversation.  The mid-* anchor is recorded as evidence.
                conversation_id=candidate_ref.conversation_id,
                identity_confidence=candidate_ref.identity_confidence,
            )
            return CandidateSnapshot.create(
                resolved_ref,
                source="messages.current_profile",
                profile=profile,
                evidence_refs=(
                    f"当前岗位={job_ref.title}",
                    f"消息队列={queue_label}",
                    f"conversation-anchor:{anchor_id}",
                    f"chat-context:{stable_hash(texts)}",
                ),
            )

    def read_candidate_profile(
        self, candidate_ref: CandidateRef
    ) -> CandidateSnapshot:
        with self._connected() as session:
            current = self._current_conversation_context(session)
            if current is not None:
                _, _, name, profile, anchor_id, _ = current
                if (
                    candidate_ref.display_name == name
                    and candidate_ref.conversation_id == anchor_id
                ):
                    return CandidateSnapshot.create(
                        candidate_ref,
                        source="messages.current_profile",
                        profile=profile,
                        evidence_refs=(
                            f"conversation-anchor:{anchor_id}",
                        ),
                    )
            card = self._find_candidate_card(session, candidate_ref)
            session.activate(card)
            session.refresh()
            if not session.wait_for(
                lambda: bool(
                    session.find_all_alternatives(
                        selectors.ONLINE_RESUME,
                        actionable_only=False,
                    )
                ),
                timeout=session.wait_timeout,
            ):
                raise AccessibilityUnavailable("候选人在线简历没有加载")
            documents = session.find_all(
                {"control_type": "Document"}, actionable_only=False
            )
            if not documents:
                raise AccessibilityUnavailable("在线简历缺少 Document")
            # Prefer the document containing the candidate's exact display name.
            candidates = []
            for document in documents:
                texts = _safe_visible_texts(session.texts_within(document))
                if (
                    candidate_ref.display_name
                    and candidate_ref.display_name in texts
                ):
                    candidates.append((document, texts))
            if len(candidates) != 1:
                raise AccessibilityUnavailable(
                    f"在线简历 Document 必须唯一，实际为 {len(candidates)}"
                )
            _, texts = candidates[0]
            profile = _profile_from_texts(texts)
            profile["_ui_source"] = "online_profile"
            return CandidateSnapshot.create(
                candidate_ref,
                source="online_profile",
                profile=profile,
                evidence_refs=(f"online-profile:{stable_hash(texts)}",),
            )

    def prepare_action_context(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        kind: ActionKind,
    ) -> tuple[str, ...]:
        if candidate_ref.identity_confidence not in {
            IdentityConfidence.EXACT,
            IdentityConfidence.STRONG,
        }:
            raise CandidateIdentityConflict(
                "POSSIBLE/UNRESOLVED 候选人不能自动触达"
            )
        evidence = self.verify_job_context(job_ref)
        with self._connected() as session:
            if kind in {ActionKind.REPLY, ActionKind.RESUME_REQUEST}:
                card, preview, _ = self._open_message_candidate(
                    session, job_ref, candidate_ref
                )
            else:
                card = self._find_candidate_card(session, candidate_ref)
                preview = None
            texts = _safe_visible_texts(session.texts_within(card))
            if (
                candidate_ref.display_name
                and candidate_ref.display_name not in texts
            ):
                raise ContextMismatch("候选人上下文回读失败")
            return (
                *evidence,
                f"candidate_key={candidate_ref.candidate_key}",
                f"action_kind={kind.value}",
                f"candidate_context_hash={stable_hash(texts)}",
                (
                    f"latest_inbound_hash={stable_hash(preview)}"
                    if preview
                    else "latest_inbound_hash=<none>"
                ),
            )

    def _open_action_candidate(
        self,
        session: BossCandidateSession,
        action: PreparedAction,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> tuple[Any, str | None, str | None]:
        if action.kind is ActionKind.GREETING:
            self._navigate(
                session, selectors.NAV_RECOMMENDATIONS, label="推荐"
            )
            self._select_job(session, job_ref)
            card = self._find_candidate_card(session, candidate_ref)
            preview = None
            queue_label = None
        else:
            card, preview, queue_label = self._open_message_candidate(
                session, job_ref, candidate_ref
            )
        texts = _safe_visible_texts(session.texts_within(card))
        if (
            candidate_ref.display_name
            and candidate_ref.display_name not in texts
        ):
            raise ContextMismatch("提交前候选人回读不一致")
        return card, preview, queue_label

    def _set_chat_editor_text(
        self, session: BossCandidateSession, payload: str
    ) -> None:
        editor = self._chat_editor(session)
        edit_controls = session.find_all(
            {"control_type": "Edit"},
            scope=editor,
            actionable_only=False,
        )
        candidates = [*edit_controls, editor]
        for control in candidates:
            try:
                control.set_edit_text(payload)
            except Exception:
                pass
            else:
                if self._chat_editor_contains(
                    session, payload
                ):
                    return
                raise AccessibilityUnavailable(
                    "聊天编辑器写入后无法精确回读正文"
                )
            try:
                value_pattern = control.iface_value
            except Exception:
                value_pattern = None
            if value_pattern is None:
                continue
            try:
                value_pattern.SetValue(payload)
            except Exception:
                continue
            if self._chat_editor_contains(session, payload):
                return
            raise AccessibilityUnavailable(
                "聊天编辑器写入后无法精确回读正文"
            )
        existing = _safe_visible_texts(
            session.texts_within(editor)
        )
        if existing and normalize_text(payload) not in existing:
            raise ContextMismatch(
                "聊天编辑器存在其他未发送草稿，拒绝覆盖"
            )
        from pywinauto.keyboard import send_keys

        editor.click_input()
        send_keys("^a{BACKSPACE}", pause=0.02)
        send_keys(
            payload,
            with_spaces=True,
            pause=0.01,
            vk_packet=True,
        )
        time.sleep(0.2)
        session.refresh()
        if self._chat_editor_contains(session, payload):
            return
        # Only our own just-written draft may be cleared on failed readback.
        editor = self._chat_editor(session)
        editor.click_input()
        send_keys("^a{BACKSPACE}", pause=0.02)
        raise AccessibilityUnavailable(
            "聊天编辑器键盘写入后无法精确回读正文"
        )

    def _chat_editor_contains(
        self, session: BossCandidateSession, payload: str
    ) -> bool:
        editor = self._chat_editor(session)
        observed: list[str] = []
        try:
            observed.append(editor.get_value())
        except Exception:
            pass
        try:
            observed.append(editor.window_text())
        except Exception:
            pass
        descendants = session.texts_within(editor)
        observed.extend(descendants)
        if descendants:
            observed.append(" ".join(descendants))
        expected = normalize_text(payload)
        return expected in {
            normalize_text(value) for value in observed if value
        }

    def _reply_row_matches(
        self,
        session: BossCandidateSession,
        row: Any,
        payload: str,
    ) -> bool:
        return normalize_text(payload) in _safe_visible_texts(
            session.texts_within(row)
        )

    def _reply_row_is_confirmed_outbound(
        self,
        session: BossCandidateSession,
        row: Any,
        payload: str,
    ) -> bool:
        texts = _safe_visible_texts(session.texts_within(row))
        if normalize_text(payload) not in texts:
            return False
        if any(
            marker in text
            for text in texts
            for marker in ("发送失败", "发送中")
        ):
            return False
        return any(
            marker in text
            for text in texts
            for marker in ("已读", "未读", "送达")
        )

    def _reply_rows_after_trigger(
        self,
        session: BossCandidateSession,
        action: PreparedAction,
    ) -> list[Any]:
        rows = self._chat_message_controls(session)
        if not action.triggering_event_id:
            return [
                row
                for row in rows
                if self._reply_row_is_confirmed_outbound(
                    session, row, action.payload
                )
            ]
        trigger_match = re.fullmatch(
            r"mid-(\d+)", action.triggering_event_id
        )
        if trigger_match:
            trigger_number = int(trigger_match.group(1))
            candidates = []
            for row in rows:
                message_id = normalize_text(
                    getattr(row.element_info, "automation_id", "")
                )
                current_match = re.fullmatch(r"mid-(\d+)", message_id)
                if (
                    current_match
                    and int(current_match.group(1)) > trigger_number
                    and self._reply_row_is_confirmed_outbound(
                        session, row, action.payload
                    )
                ):
                    candidates.append(row)
            return candidates
        ids = [
            normalize_text(
                getattr(row.element_info, "automation_id", "")
            )
            for row in rows
        ]
        if ids.count(action.triggering_event_id) != 1:
            return []
        index = ids.index(action.triggering_event_id)
        return [
            row
            for row in rows[index + 1 :]
            if self._reply_row_is_confirmed_outbound(
                session, row, action.payload
            )
        ]

    def _request_resume_confirmation_control(
        self,
        session: BossCandidateSession,
    ) -> Any | None:
        """Return the unique exact modal confirmation, if the modal exists.

        The prompt is the modal scope anchor. We walk to the smallest
        ancestor that contains one exact actionable ``确定`` control, so an
        unrelated control elsewhere in the application can never be invoked.
        """

        prompts = session.find_all_alternatives(
            selectors.REQUEST_RESUME_CONFIRM_PROMPT,
            actionable_only=True,
        )
        if not prompts:
            return None
        if len(prompts) != 1:
            raise CommitUnknown(
                "索取简历确认提示不唯一，禁止继续提交"
            )
        current = prompts[0]
        maximum = 0
        for _ in range(10):
            try:
                current = current.parent()
            except Exception:
                break
            for selector in selectors.REQUEST_RESUME_CONFIRM:
                controls = session.find_all(
                    selector,
                    scope=current,
                    actionable_only=True,
                )
                maximum = max(maximum, len(controls))
                if len(controls) == 1:
                    return controls[0]
        raise CommitUnknown(
            "索取简历确认弹窗未暴露唯一精确“确定”控件",
            context=ErrorContext(
                step="resume_request_confirmation",
                details={"max_exact_confirm_count": maximum},
            ),
        )

    def _resume_attachment_evidence(
        self,
        session: BossCandidateSession,
        *,
        scope: Any | None = None,
    ) -> tuple[str, ...]:
        """Read deterministic received-attachment evidence without clicking."""

        chat_scope = scope or self._chat_scope(session)
        previews = session.find_all_alternatives(
            selectors.ATTACHMENT_RESUME_PREVIEW,
            scope=chat_scope,
            actionable_only=True,
        )
        visible_file_names: list[str] = []
        for control in session.find_all(
            {"control_type": "Text"},
            scope=chat_scope,
            actionable_only=True,
        ):
            values = [
                normalize_text(
                    getattr(control.element_info, "name", "")
                )
            ]
            try:
                values.append(normalize_text(control.window_text()))
            except Exception:
                pass
            visible_file_names.extend(
                value
                for value in values
                if value
                and Path(value).suffix.casefold() in {".pdf", ".docx"}
            )
        file_names = tuple(dict.fromkeys(visible_file_names))
        evidence: list[str] = []
        if previews:
            evidence.append("附件简历预览=点击预览附件简历")
        evidence.extend(f"附件文件名={file_name}" for file_name in file_names)
        return tuple(evidence)

    @staticmethod
    def _visible(control: Any) -> bool:
        try:
            return bool(control.is_visible())
        except Exception:
            return False

    @staticmethod
    def _same_control(left: Any, right: Any) -> bool:
        left_identity = _wrapper_identity(left)
        right_identity = _wrapper_identity(right)
        if left_identity and right_identity:
            return left_identity == right_identity
        return left is right

    def _direct_visible_text(
        self,
        session: BossCandidateSession,
        scope: Any,
        title: str,
    ) -> list[Any]:
        result: list[Any] = []
        for control in session.find_all(
            {"title": title, "control_type": "Text"},
            scope=scope,
            actionable_only=False,
        ):
            if not self._visible(control):
                continue
            try:
                parent = control.parent()
            except Exception:
                continue
            if self._same_control(parent, scope):
                result.append(control)
        return result

    @staticmethod
    def _message_row_ancestor(control: Any) -> Any | None:
        current = control
        for _ in range(12):
            try:
                current = current.parent()
            except Exception:
                return None
            info = getattr(current, "element_info", None)
            if (
                getattr(info, "control_type", "") == "ListItem"
                and normalize_text(
                    getattr(info, "automation_id", "")
                ).startswith("mid-")
            ):
                return current
        return None

    @staticmethod
    def _supported_preview_title(
        control: Any,
        *,
        extension: str,
    ) -> str | None:
        values = [
            normalize_text(
                getattr(control.element_info, "name", "")
            ),
        ]
        try:
            values.append(normalize_text(control.window_text()))
        except Exception:
            pass
        accepted = (
            {
                "pdf预览",
                "pdf preview",
            }
            if extension == ".pdf"
            else {
                "docx预览",
                "doc预览",
                "word预览",
                "文档预览",
                "docx preview",
                "doc preview",
                "word preview",
                "document preview",
            }
        )
        for value in values:
            if value.casefold() in accepted:
                return value
        return None

    def _semantic_preview_documents(
        self,
        session: BossCandidateSession,
        *,
        extension: str,
    ) -> list[tuple[Any, str]]:
        result: list[tuple[Any, str]] = []
        for document in session.find_all(
            {"control_type": "Document"},
            actionable_only=False,
        ):
            if not self._visible(document):
                continue
            title = self._supported_preview_title(
                document,
                extension=extension,
            )
            if title:
                result.append((document, title))
        return result

    def _verified_current_attachment_context(
        self,
        session: BossCandidateSession,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> tuple[Any, Any, str, tuple[str, ...]]:
        """Verify the underlying chat without reading preview body text."""

        if candidate_ref.job_key != job_ref.job_key:
            raise ContextMismatch("候选人与当前岗位不一致")
        chat_scope = self._chat_scope(session)

        job_controls = self._message_job_selector_controls(
            session,
            job_ref,
        )
        if len(job_controls) != 1:
            raise ContextMismatch(
                "当前聊天必须回读唯一绑定岗位语义选择器"
            )
        job_values: list[str] = []
        for control in job_controls:
            values = [
                normalize_text(
                    getattr(control.element_info, "name", "")
                )
            ]
            try:
                values.append(normalize_text(control.window_text()))
            except Exception:
                pass
            try:
                values.append(normalize_text(control.get_value()))
            except Exception:
                pass
            job_values.extend(value for value in values if value)
        matching_jobs = tuple(dict.fromkeys(job_values))

        if not candidate_ref.conversation_id:
            raise CandidateIdentityConflict(
                "UIA 简历预览需要已有稳定会话锚点"
            )
        anchor_rows = [
            row
            for row in session.find_all(
                {"control_type": "ListItem"},
                scope=chat_scope,
                actionable_only=False,
            )
            if normalize_text(
                getattr(row.element_info, "automation_id", "")
            )
            == candidate_ref.conversation_id
        ]
        if len(anchor_rows) != 1:
            raise CandidateIdentityConflict(
                "当前聊天必须回读唯一稳定会话锚点"
            )

        if candidate_ref.display_name:
            header_names = self._direct_visible_text(
                session,
                chat_scope,
                candidate_ref.display_name,
            )
            if len(header_names) != 1:
                raise CandidateIdentityConflict(
                    "当前聊天资料头必须回读唯一候选人姓名"
                )

        preview_links = [
            control
            for control in session.find_all_alternatives(
                selectors.ATTACHMENT_RESUME_PREVIEW,
                scope=chat_scope,
                actionable_only=False,
            )
            if self._visible(control)
        ]
        unique_links: dict[str, Any] = {}
        for control in preview_links:
            unique_links[
                _wrapper_identity(control) or f"object:{id(control)}"
            ] = control
        if len(unique_links) != 1:
            raise AccessibilityUnavailable(
                "当前聊天必须暴露唯一“点击预览附件简历”语义控件"
            )
        preview_link = next(iter(unique_links.values()))
        attachment_row = self._message_row_ancestor(preview_link)
        if attachment_row is None:
            raise AccessibilityUnavailable(
                "附件简历预览控件未归属于唯一 mid-* 消息"
            )
        file_names = tuple(
            dict.fromkeys(
                normalize_text(
                    getattr(control.element_info, "name", "")
                )
                for control in session.find_all(
                    {"control_type": "Text"},
                    scope=attachment_row,
                    actionable_only=False,
                )
                if self._visible(control)
                and Path(
                    normalize_text(
                        getattr(control.element_info, "name", "")
                    )
                ).suffix.casefold()
                in {".pdf", ".docx"}
            )
        )
        if len(file_names) != 1:
            raise AccessibilityUnavailable(
                "当前附件消息必须回读唯一 PDF/DOCX 文件名"
            )
        return (
            chat_scope,
            preview_link,
            file_names[0],
            matching_jobs,
        )

    def read_current_resume_preview(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> ResumePreviewContent:
        """Read one current resume through BOSS's semantic preview only."""

        with self._connected() as session:
            (
                _,
                preview_link,
                file_name,
                matching_jobs,
            ) = self._verified_current_attachment_context(
                session,
                job_ref,
                candidate_ref,
            )
            extension = Path(file_name).suffix.casefold()
            documents = self._semantic_preview_documents(
                session,
                extension=extension,
            )
            if len(documents) > 1:
                raise AccessibilityUnavailable(
                    "必须只有一个可见的 PDF/DOCX 语义预览 Document"
                )
            opened_now = False
            if not documents:
                try:
                    session.invoke(preview_link)
                    opened_now = True
                    session.refresh()
                except Exception as exc:
                    raise AccessibilityUnavailable(
                        "附件简历语义预览控件调用失败，未尝试视觉或坐标回退"
                    ) from exc
                if not session.wait_for(
                    lambda: len(
                        self._semantic_preview_documents(
                            session,
                            extension=extension,
                        )
                    )
                    == 1,
                    timeout=session.wait_timeout,
                ):
                    raise AccessibilityUnavailable(
                        "附件简历语义预览 Document 未唯一加载"
                    )
                documents = self._semantic_preview_documents(
                    session,
                    extension=extension,
                )
            if len(documents) != 1:
                raise AccessibilityUnavailable(
                    "附件简历语义预览 Document 必须唯一"
                )
            document, preview_title = documents[0]
            exposed_texts = tuple(
                normalize_text(value)
                for value in session.texts_within(
                    document,
                    limit=5_000,
                )
                if normalize_text(value)
            )
            normalized = normalize_uia_preview_text(
                "\n".join(exposed_texts)
            )
            if not normalized:
                raise AccessibilityUnavailable(
                    "附件简历预览未暴露文本，禁止 OCR 或截图回退"
                )
            payload = normalized.encode("utf-8")
            if len(payload) > self.config.max_resume_bytes:
                raise AccessibilityUnavailable(
                    "附件简历预览文本超过安全大小上限"
                )
            text_hash = hashlib.sha256(payload).hexdigest()
            attachment_row = self._message_row_ancestor(preview_link)
            row_identity = (
                _wrapper_identity(attachment_row)
                if attachment_row is not None
                else None
            )
            return ResumePreviewContent(
                candidate_ref=candidate_ref,
                file_name=file_name,
                preview_title=preview_title,
                text=normalized,
                text_hash=text_hash,
                size_bytes=len(payload),
                observed_at=utc_now(),
                evidence=(
                    f"conversation-anchor:{candidate_ref.conversation_id}",
                    f"job-context:{stable_hash(matching_jobs)}",
                    f"attachment-row:{row_identity or '<semantic>'}",
                    f"attachment-file-hash:{stable_hash(file_name)}",
                    f"preview-document:{preview_title}",
                    f"preview-opened-now:{str(opened_now).lower()}",
                    f"preview-text-sha256:{text_hash}",
                ),
            )

    def _resume_request_success_evidence(
        self,
        session: BossCandidateSession,
    ) -> tuple[str, ...]:
        """Return only evidence that deterministically closes the action.

        A still-visible confirmation prompt means the initial click has not
        been committed. In particular, a modal must not be mistaken for a
        disabled/hidden ``求简历`` control.
        """

        prompts = session.find_all_alternatives(
            selectors.REQUEST_RESUME_CONFIRM_PROMPT,
            actionable_only=True,
        )
        if prompts:
            return ()
        chat_scope = self._chat_scope(session)
        attachment = self._resume_attachment_evidence(
            session, scope=chat_scope
        )
        return attachment

    def commit_action(
        self,
        action: PreparedAction,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> ActionReceipt:
        with self._connected() as session:
            card, preview, queue_label = self._open_action_candidate(
                session, action, job_ref, candidate_ref
            )
            if action.kind is ActionKind.GREETING:
                button = self._unique_preferred(
                    session,
                    selectors.GREET,
                    label="打招呼",
                    scope=card,
                )
                try:
                    session.invoke(button)
                    session.refresh()
                except Exception as exc:
                    raise CommitUnknown(
                        "打招呼控件可能已调用，回读前发生异常"
                    ) from exc
                if session.wait_for(
                    lambda: bool(
                        session.find_all_alternatives(
                            selectors.CONTINUE_CHAT,
                            scope=card,
                            actionable_only=False,
                        )
                    ),
                    timeout=8,
                ):
                    return ActionReceipt(
                        action_id=action.action_id,
                        state=ActionState.SUCCEEDED,
                        evidence=("候选卡动作变为继续沟通",),
                    )
                raise CommitUnknown("打招呼已调用，但无法回读成功状态")
            if action.kind is ActionKind.RESUME_REQUEST:
                chat_scope = self._chat_scope(session)
                if session.find_all_alternatives(
                    selectors.REQUEST_RESUME_CONFIRM_PROMPT,
                    actionable_only=True,
                ):
                    raise CommitUnknown(
                        "提交前已存在索取简历确认弹窗，禁止再次调用求简历"
                    )
                button = self._unique_preferred(
                    session,
                    selectors.REQUEST_RESUME,
                    label="求简历",
                    scope=chat_scope,
                )
                try:
                    session.invoke(button)
                    session.refresh()
                except Exception as exc:
                    raise CommitUnknown(
                        "求简历控件可能已调用，回读前发生异常"
                    ) from exc
                session.wait_for(
                    lambda: bool(
                        session.find_all_alternatives(
                            selectors.REQUEST_RESUME_CONFIRM_PROMPT,
                            actionable_only=True,
                        )
                    )
                    or bool(
                        self._resume_request_success_evidence(session)
                    ),
                    timeout=8,
                )
                confirmation = (
                    self._request_resume_confirmation_control(session)
                )
                if confirmation is not None:
                    try:
                        # This is the sole continuation of the already
                        # prepared RESUME_REQUEST action. It is invoked once.
                        session.invoke(confirmation)
                        session.refresh()
                    except Exception as exc:
                        raise CommitUnknown(
                            "索取简历确认控件可能已调用，回读前发生异常"
                        ) from exc
                if session.wait_for(
                    lambda: bool(
                        self._resume_request_success_evidence(session)
                    ),
                    timeout=8,
                ):
                    evidence = self._resume_request_success_evidence(
                        session
                    )
                    return ActionReceipt(
                        action_id=action.action_id,
                        state=ActionState.SUCCEEDED,
                        evidence=evidence,
                    )
                raise CommitUnknown(
                    "求简历已调用并处理确认弹窗，但状态无法确定"
                )
            if action.kind is ActionKind.REPLY:
                conversation = self._read_open_conversation(
                    session,
                    job_ref,
                    candidate_ref,
                    preview=preview,
                    queue_label=queue_label or "",
                    expected_inbound_message_id=(
                        action.triggering_event_id
                    ),
                )
                if (
                    action.triggering_event_id
                    and conversation.latest_inbound_message_id
                    != action.triggering_event_id
                ):
                    raise ContextMismatch(
                        "最新入站消息已变化，旧回复草稿和确认失效"
                    )
                chat_scope = self._chat_scope(session)
                before_ids = {
                    normalize_text(
                        getattr(row.element_info, "automation_id", "")
                    )
                    for row in self._chat_message_controls(
                        session, scope=chat_scope
                    )
                }
                self._set_chat_editor_text(session, action.payload)
                send = self._unique_preferred(
                    session,
                    selectors.SEND,
                    label="发送",
                    scope=chat_scope,
                )
                try:
                    session.invoke(send)
                    session.refresh()
                except Exception as exc:
                    raise CommitUnknown(
                        "发送控件可能已调用，回读前发生异常"
                    ) from exc
                if session.wait_for(
                    lambda: any(
                        normalize_text(
                            getattr(
                                row.element_info, "automation_id", ""
                            )
                        )
                        not in before_ids
                        and self._reply_row_is_confirmed_outbound(
                            session, row, action.payload
                        )
                        for row in self._chat_message_controls(session)
                    ),
                    timeout=8,
                ):
                    return ActionReceipt(
                        action_id=action.action_id,
                        state=ActionState.SUCCEEDED,
                        evidence=(f"己方消息哈希={stable_hash(action.payload)}",),
                    )
                raise CommitUnknown("回复已发送，但消息气泡回读失败")
        raise AccessibilityUnavailable(f"不支持的动作：{action.kind}")

    def reconcile_action(
        self,
        action: PreparedAction,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> ActionReceipt:
        with self._connected() as session:
            card, _, _ = self._open_action_candidate(
                session, action, job_ref, candidate_ref
            )
            if action.kind is ActionKind.REPLY:
                matches = self._reply_rows_after_trigger(
                    session, action
                )
                if len(matches) == 1:
                    return ActionReceipt(
                        action_id=action.action_id,
                        state=ActionState.SUCCEEDED,
                        evidence=(f"消息气泡哈希={stable_hash(action.payload)}",),
                    )
            if action.kind is ActionKind.GREETING:
                if session.find_all_alternatives(
                    selectors.CONTINUE_CHAT,
                    scope=card,
                    actionable_only=False,
                ):
                    return ActionReceipt(
                        action_id=action.action_id,
                        state=ActionState.SUCCEEDED,
                        evidence=("候选卡显示继续沟通",),
                    )
            if action.kind is ActionKind.RESUME_REQUEST:
                evidence = self._resume_request_success_evidence(
                    session
                )
                if evidence:
                    return ActionReceipt(
                        action_id=action.action_id,
                        state=ActionState.SUCCEEDED,
                        evidence=evidence,
                    )
            return ActionReceipt(
                action_id=action.action_id,
                state=ActionState.COMMIT_UNKNOWN,
                message="仍缺少确定性证据，禁止重发",
            )

    def scan_received_resumes(
        self,
        job_ref: JobRef,
        *,
        cursor: str | None,
        limit: int,
    ) -> tuple[tuple[ResumeReceipt, ...], str | None]:
        with self._connected() as session:
            self._navigate(session, selectors.NAV_MESSAGES, label="消息")
            self._select_job(session, job_ref)
            self._click_message_header_more(session, job_ref)
            self._click_label(
                session,
                selectors.MESSAGES_RECEIVED_RESUME,
                label="已获取简历",
            )
            time.sleep(0.5)
            offset = _cursor_offset(cursor)
            target = offset + max(1, limit) + 1
            receipts_by_id: dict[str, ResumeReceipt] = {}
            previous_signature = None
            stalled = 0
            exhausted = False
            for _ in range(max(20, min(100, target))):
                attachment_rows = []
                for row in self._candidate_message_rows(session):
                    texts = _safe_visible_texts(
                        session.texts_within(row)
                    )
                    file_names = tuple(
                        dict.fromkeys(
                            text
                            for text in texts
                            if Path(text).suffix.casefold()
                            in {".pdf", ".docx"}
                        )
                    )
                    if not file_names:
                        continue
                    attachment_rows.append(row)
                    snapshot = self._candidate_snapshot(
                        session,
                        job_ref,
                        row,
                        source="messages.received_resumes",
                    )
                    ref = snapshot.candidate_ref
                    for file_name in file_names:
                        receipt_id = stable_hash(
                            ref.candidate_key, file_name, texts
                        )
                        receipts_by_id.setdefault(
                            receipt_id,
                            ResumeReceipt(
                                receipt_id=receipt_id,
                                candidate_ref=ref,
                                file_name=file_name,
                                attachment_id=None,
                                received_at=None,
                                evidence=(
                                    "消息筛选=已获取简历",
                                    f"附件卡文件名={file_name}",
                                    (
                                        "候选人会话键="
                                        f"{ref.conversation_id or '<none>'}"
                                    ),
                                ),
                            ),
                        )
                        if len(receipts_by_id) >= target:
                            break
                    if len(receipts_by_id) >= target:
                        break
                if len(receipts_by_id) >= target:
                    break
                if not attachment_rows:
                    exhausted = True
                    break
                signature = tuple(sorted(receipts_by_id))
                if signature == previous_signature:
                    stalled += 1
                else:
                    stalled = 0
                if (
                    stalled >= 2
                    or not self._scroll_once(attachment_rows[-1])
                ):
                    exhausted = True
                    break
                previous_signature = signature
                time.sleep(0.35)
                session.refresh()
            all_receipts = tuple(receipts_by_id.values())
            receipts, next_cursor = _offset_page(
                all_receipts,
                cursor,
                limit,
                exhausted=exhausted,
            )
            return receipts, next_cursor

    def _download_candidates(
        self, receipt: ResumeReceipt, download_dir: Path
    ) -> list[Path]:
        expected = Path(receipt.file_name).name
        expected_path = Path(expected)

        def matches_expected(path: Path) -> bool:
            if path.suffix.casefold() != expected_path.suffix.casefold():
                return False
            if path.name.casefold() == expected.casefold():
                return True
            pattern = re.compile(
                rf"^{re.escape(expected_path.stem)} \(\d+\)"
                rf"{re.escape(expected_path.suffix)}$",
                re.IGNORECASE,
            )
            return bool(pattern.fullmatch(path.name))

        roots = [
            download_dir,
            Path(os.environ.get("USERPROFILE", "")) / "Downloads",
        ]
        result: list[Path] = []
        for root in roots:
            if root.is_dir():
                result.extend(
                    path
                    for path in root.glob("*")
                    if path.is_file()
                    and path.suffix.casefold() in {".pdf", ".docx"}
                    and matches_expected(path)
                )
        return result

    def download_resume(
        self,
        receipt: ResumeReceipt,
        *,
        download_dir: Path,
    ) -> Path:
        download_dir.mkdir(parents=True, exist_ok=True)
        before = {
            (path.resolve(), path.stat().st_mtime_ns, path.stat().st_size)
            for path in self._download_candidates(receipt, download_dir)
        }
        job_ref = self._last_job
        if (
            job_ref is None
            or job_ref.job_key != receipt.candidate_ref.job_key
        ):
            raise ContextMismatch(
                "下载简历前缺少当前进程已核验的岗位上下文"
            )
        with self._connected() as session:
            self._navigate(session, selectors.NAV_MESSAGES, label="消息")
            self._select_job(session, job_ref)
            self._click_message_header_more(session, job_ref)
            self._click_label(
                session,
                selectors.MESSAGES_RECEIVED_RESUME,
                label="已获取简历",
            )
            time.sleep(0.35)
            row = self._find_message_row(
                session, job_ref, receipt.candidate_ref
            )
            if row is None:
                raise CandidateIdentityConflict(
                    "已获取简历队列中无法重新定位唯一候选人会话"
                )
            row_texts = _safe_visible_texts(
                session.texts_within(row)
            )
            if receipt.file_name not in row_texts:
                raise ContextMismatch(
                    "候选人附件卡文件名与待下载回执不一致"
                )
            session.activate(row)
            session.refresh()
            if not session.wait_for(
                lambda: bool(
                    session.find_all_alternatives(
                        selectors.ATTACHMENT_RESUME_PREVIEW,
                        scope=self._chat_scope(session),
                        actionable_only=True,
                    )
                ),
                timeout=session.wait_timeout,
            ):
                raise AccessibilityUnavailable("附件简历入口未加载")
            chat_scope = self._chat_scope(session)
            self._click_label(
                session,
                selectors.ATTACHMENT_RESUME_PREVIEW,
                label="点击预览附件简历",
                scope=chat_scope,
            )
            if not session.wait_for(
                lambda: bool(
                    session.find_all(
                        {"control_type": "Document"}
                    )
                ),
                timeout=session.wait_timeout,
            ):
                raise AccessibilityUnavailable("附件简历预览未加载")
            documents = session.find_all(
                {"control_type": "Document"},
                actionable_only=False,
            )
            matching_documents = [
                document
                for document in documents
                if receipt.file_name
                in _safe_visible_texts(
                    session.texts_within(document)
                )
            ]
            if len(matching_documents) != 1:
                raise AccessibilityUnavailable(
                    "附件简历预览必须按文件名唯一回读"
                )
            preview = matching_documents[0]
            download_controls = []
            for control_type in ("Button", "Hyperlink"):
                for control in session.find_all(
                    {"control_type": control_type},
                    scope=preview,
                    actionable_only=True,
                ):
                    title = normalize_text(control.window_text()).casefold()
                    automation_id = normalize_text(
                        getattr(control.element_info, "automation_id", "")
                    ).casefold()
                    if title == "下载" or "download" in automation_id:
                        download_controls.append(control)
            if len(download_controls) != 1:
                raise AccessibilityUnavailable(
                    "附件下载必须暴露唯一“下载”语义控件；"
                    f"实际为 {len(download_controls)}，不使用视觉或坐标回退"
                )
            session.invoke(download_controls[0])
            deadline = time.monotonic() + session.wait_timeout
            while time.monotonic() < deadline:
                current = self._download_candidates(receipt, download_dir)
                for path in current:
                    signature = (
                        path.resolve(),
                        path.stat().st_mtime_ns,
                        path.stat().st_size,
                    )
                    if signature not in before and path.stat().st_size > 0:
                        return path
                time.sleep(0.25)
        raise AccessibilityUnavailable("调用下载后未发现新的 PDF/DOCX 文件")
