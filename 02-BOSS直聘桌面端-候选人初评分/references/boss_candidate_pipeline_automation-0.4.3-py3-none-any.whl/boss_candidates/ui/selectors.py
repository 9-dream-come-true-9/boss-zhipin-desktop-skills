"""Version-pinned semantic UIA selectors for BOSS desktop 1.7.4.963.

Selectors are exact property conditions. The adapter may try several verified
control types for the same visible label because Electron exposes navigation
labels as ``Hyperlink`` on some pages and ``Text`` on others. No selector uses
screen coordinates, OCR, screenshots, or a list position.
"""

from __future__ import annotations

from typing import Any, Final


SELECTOR_PROFILE: Final = "boss-1.7.4.963-candidate-pipeline-v6"
VERIFIED_BOSS_VERSION: Final = "1.7.4.963"


def text_selector(title: str) -> tuple[dict[str, Any], ...]:
    return (
        {"title": title, "control_type": "Text"},
        {"title": title, "control_type": "Hyperlink"},
        {"title": title, "control_type": "Button"},
        {"title": title, "control_type": "TabItem"},
        {"title": title, "control_type": "ListItem"},
    )


NAV_JOBS: Final = text_selector("职位")
NAV_MESSAGES: Final = text_selector("消息")
NAV_RECOMMENDATIONS: Final = text_selector("推荐")
NAV_MORE: Final = text_selector("更多")

JOBS_OPEN_TAB: Final = text_selector("开放中")
OPEN_STATUS: Final = text_selector("开放中")
JOB_EDIT: Final = text_selector("编辑")
JOB_CLOSE: Final = text_selector("关闭")
JOB_FORM_TITLE_LABEL: Final = text_selector("职位名称")
JOB_FORM_DESCRIPTION_LABEL: Final = text_selector("职位描述")
JOB_FORM_EDUCATION_LABEL: Final = text_selector("学历")
JOB_FORM_INTERNSHIP_LABEL: Final = text_selector("实习要求")

INTERACTION_COMMUNICATED: Final = text_selector("沟通过")
INTERACTION_VIEWED_ME: Final = text_selector("看过我")
INTERACTION_INTERESTED_IN_ME: Final = text_selector("对我感兴趣")
INTERACTION_I_VIEWED: Final = text_selector("我看过")
INTERACTION_COLLEAGUE: Final = text_selector("同事推荐")
CONTINUE_CHAT: Final = text_selector("继续沟通")

RECOMMEND_TAB: Final = text_selector("推荐")
RECOMMEND_FEATURED_TAB: Final = text_selector("精选")
RECOMMEND_LATEST_TAB: Final = text_selector("最新")
GREET: Final = text_selector("打招呼")

MESSAGES_ALL: Final = text_selector("全部")
MESSAGES_NEW_GREETINGS: Final = text_selector("新招呼")
MESSAGES_IN_PROGRESS: Final = text_selector("沟通中")
MESSAGES_INTERVIEWED: Final = text_selector("已约面")
MESSAGES_MORE: Final = text_selector("更多")
MESSAGES_RECEIVED_RESUME: Final = text_selector("已获取简历")
MESSAGES_UNREAD: Final = text_selector("未读")

# BOSS 1.7.4.963 paints several Messages header tabs without exposing a UIA
# control.  The exact ``新招呼`` Text remains exposed and is the fixed semantic
# anchor.  Values below are target X positions expressed in *anchor widths*
# from the anchor's left edge.  They were verified on the supported build at
# maximized scale and deliberately contain no absolute screen coordinate.
#
#   全部:   anchor.left - 2/3 * anchor.width
#   沟通中: anchor.right + 11/6 * anchor.width
#   已约面: anchor.right + 45/14 * anchor.width
MESSAGE_HEADER_TAB_X_RATIOS: Final = {
    "全部": -2 / 3,
    "沟通中": 17 / 6,
    "已约面": 59 / 14,
}

ONLINE_RESUME: Final = text_selector("在线简历")
ATTACHMENT_RESUME: Final = text_selector("附件简历")
ATTACHMENT_RESUME_PREVIEW: Final = text_selector("点击预览附件简历")
RESUME_PREVIEW_DOCUMENTS: Final = (
    {"title": "PDF预览", "control_type": "Document"},
    {"title": "DOCX预览", "control_type": "Document"},
    {"title": "DOC预览", "control_type": "Document"},
    {"title": "Word预览", "control_type": "Document"},
    {"title": "文档预览", "control_type": "Document"},
    {"title": "PDF Preview", "control_type": "Document"},
    {"title": "DOCX Preview", "control_type": "Document"},
    {"title": "DOC Preview", "control_type": "Document"},
    {"title": "Word Preview", "control_type": "Document"},
    {"title": "Document Preview", "control_type": "Document"},
)
REQUEST_RESUME: Final = text_selector("求简历")
REQUEST_RESUME_CONFIRM_PROMPT: Final = text_selector(
    "确定向牛人索取简历吗？"
)
REQUEST_RESUME_CONFIRM: Final = (
    {"title": "确定", "control_type": "Button"},
    {"title": "确定", "control_type": "Hyperlink"},
    {"title": "确定", "control_type": "Text"},
)
SEND: Final = (
    {"title": "发送", "control_type": "Button"},
    {"title": "发送", "control_type": "Text"},
    {"title": "发送", "control_type": "Hyperlink"},
)
NOT_SUITABLE: Final = text_selector("不合适")
CHAT_EDITOR: Final = (
    {"auto_id": "boss-chat-editor-input", "control_type": "Group"},
    {"auto_id": "boss-chat-editor-input", "control_type": "Edit"},
    {"auto_id": "boss-chat-editor-input", "control_type": "Document"},
    {"auto_id": "boss-chat-editor-input", "control_type": "Pane"},
)

LOGIN_PROBES: Final = (
    *text_selector("扫码登录"),
    *text_selector("手机号登录"),
    *text_selector("登录 BOSS直聘"),
)

ACCESSIBILITY_PROBES: Final = (
    *NAV_JOBS,
    *NAV_MESSAGES,
    *NAV_RECOMMENDATIONS,
    *RESUME_PREVIEW_DOCUMENTS,
)
