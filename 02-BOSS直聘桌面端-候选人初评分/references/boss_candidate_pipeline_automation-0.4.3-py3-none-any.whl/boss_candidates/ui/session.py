from __future__ import annotations

import importlib.util
import os
import re
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from ..config import CandidatePipelineConfig, DEFAULT_CONFIG
from ..errors import (
    AccessibilityUnavailable,
    AmbiguousWindow,
    AppNotInstalled,
    AppNotRunning,
    ErrorContext,
    LoginRequired,
    UnsupportedVersion,
)
from .selectors import ACCESSIBILITY_PROBES, LOGIN_PROBES, SELECTOR_PROFILE


def _runtime() -> tuple[Any, Any]:
    missing = [
        name
        for name in ("pywinauto", "psutil", "win32api")
        if importlib.util.find_spec(name) is None
    ]
    if missing:
        raise AppNotInstalled(
            "缺少 BOSS 候选人自动化运行依赖",
            context=ErrorContext(details={"missing_modules": missing}),
        )
    import psutil
    import win32api

    return psutil, win32api


def _file_version(executable: Path) -> str | None:
    _, win32api = _runtime()
    try:
        info = win32api.GetFileVersionInfo(str(executable), "\\")
        ms = info["FileVersionMS"]
        ls = info["FileVersionLS"]
        return ".".join(
            str(value)
            for value in (
                win32api.HIWORD(ms),
                win32api.LOWORD(ms),
                win32api.HIWORD(ls),
                win32api.LOWORD(ls),
            )
        )
    except Exception:
        return None


def _processes(process_name: str) -> list[Any]:
    psutil, _ = _runtime()
    try:
        current_user = (psutil.Process().username() or "").casefold()
    except Exception:
        current_user = ""
    result: list[Any] = []
    for process in psutil.process_iter(["pid", "name", "exe", "username"]):
        try:
            if (process.info.get("name") or "").casefold() != process_name.casefold():
                continue
            owner = (process.info.get("username") or "").casefold()
            if current_user and owner and owner != current_user:
                continue
            result.append(process)
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            continue
    return result


def _terminate_exact_app_processes(
    process_name: str,
    executable: Path,
    *,
    timeout: float,
) -> None:
    """Stop only this user's exact BOSS executable after a graceful close."""

    psutil, _ = _runtime()
    expected = str(executable.resolve()).casefold()
    deadline = time.monotonic() + max(1.0, timeout)
    while time.monotonic() < deadline:
        matches: list[Any] = []
        for process in _processes(process_name):
            try:
                actual = str(Path(process.exe()).resolve()).casefold()
            except (psutil.AccessDenied, psutil.NoSuchProcess, OSError):
                actual = expected
            if actual == expected:
                matches.append(process)
        if not matches:
            return
        for process in matches:
            try:
                process.terminate()
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                continue
        remaining = max(0.1, deadline - time.monotonic())
        _, alive = psutil.wait_procs(
            matches,
            timeout=min(2.0, remaining),
        )
        for process in alive:
            try:
                process.kill()
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                continue
        if alive:
            psutil.wait_procs(
                alive,
                timeout=min(2.0, max(0.1, deadline - time.monotonic())),
            )
        time.sleep(0.1)
    remaining_pids = [
        process.pid
        for process in _processes(process_name)
        if process.is_running()
    ]
    if remaining_pids:
        raise AccessibilityUnavailable(
            "BOSS 后台进程未能安全退出",
            context=ErrorContext(
                step="restart_accessibility",
                details={"remaining_pids": remaining_pids},
            ),
        )


def locate_executable(
    config: CandidatePipelineConfig = DEFAULT_CONFIG,
) -> Path:
    for process in _processes(config.process_name):
        try:
            executable = process.exe()
        except Exception:
            executable = None
        resolved = _official_executable(executable, config.process_name)
        if resolved is not None:
            return resolved

    configured = _official_executable(
        os.environ.get("BOSS_ZHIPIN_EXE"), config.process_name
    )
    if configured is not None:
        return configured

    for path in _environment_install_candidates(config.process_name):
        resolved = _official_executable(path, config.process_name)
        if resolved is not None:
            return resolved

    for path in _registry_install_candidates(config.process_name):
        resolved = _official_executable(path, config.process_name)
        if resolved is not None:
            return resolved
    raise AppNotInstalled("未找到 BOSS 直聘桌面客户端")


def _official_executable(
    value: str | os.PathLike[str] | None,
    process_name: str,
) -> Path | None:
    if value is None or not str(value).strip():
        return None
    path = Path(os.path.expandvars(str(value).strip().strip('"'))).expanduser()
    if path.name.casefold() != process_name.casefold() or not path.is_file():
        return None
    try:
        return path.resolve()
    except OSError:
        return path


def _environment_install_candidates(
    process_name: str,
) -> tuple[Path, ...]:
    roots: list[Path] = []
    seen_roots: set[str] = set()
    for name in (
        "LOCALAPPDATA",
        "PROGRAMFILES",
        "PROGRAMFILES(X86)",
        "PROGRAMW6432",
    ):
        value = os.environ.get(name)
        if not value:
            continue
        root = Path(value).expanduser()
        key = str(root).casefold()
        if key not in seen_roots:
            seen_roots.add(key)
            roots.append(root)
    relatives = (
        ("boss-zhipin", process_name),
        ("BOSS直聘", process_name),
        ("Programs", "boss-zhipin", process_name),
        ("Programs", "BOSS直聘", process_name),
    )
    return tuple(root.joinpath(*relative) for root in roots for relative in relatives)


def _registry_value(key: Any, name: str) -> str:
    try:
        value, _ = __import__("winreg").QueryValueEx(key, name)
    except (OSError, TypeError, ValueError):
        return ""
    return str(value or "").strip()


def _display_icon_path(value: str) -> str:
    match = re.match(r'^"([^"]+)"', value)
    if match:
        return match.group(1)
    return value.split(",", 1)[0].strip().strip('"')


def _registry_install_candidates(
    process_name: str,
) -> tuple[Path, ...]:
    try:
        import winreg
    except ImportError:
        return ()

    uninstall_paths = (
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
    )
    views = [0]
    for name in ("KEY_WOW64_64KEY", "KEY_WOW64_32KEY"):
        value = getattr(winreg, name, 0)
        if value and value not in views:
            views.append(value)
    candidates: list[Path] = []
    seen: set[str] = set()
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for uninstall_path in uninstall_paths:
            for view in views:
                try:
                    root = winreg.OpenKey(
                        hive,
                        uninstall_path,
                        0,
                        winreg.KEY_READ | view,
                    )
                except OSError:
                    continue
                with root:
                    try:
                        subkey_count = winreg.QueryInfoKey(root)[0]
                    except OSError:
                        continue
                    for index in range(subkey_count):
                        try:
                            subkey_name = winreg.EnumKey(root, index)
                            subkey = winreg.OpenKey(root, subkey_name)
                        except OSError:
                            continue
                        with subkey:
                            display_name = _registry_value(
                                subkey, "DisplayName"
                            )
                            folded = display_name.casefold()
                            if "boss" not in folded and "直聘" not in display_name:
                                continue
                            install_location = _registry_value(
                                subkey, "InstallLocation"
                            )
                            display_icon = _display_icon_path(
                                _registry_value(subkey, "DisplayIcon")
                            )
                            uninstall_string = _display_icon_path(
                                _registry_value(subkey, "UninstallString")
                            )
                            raw_candidates: list[Path] = []
                            if install_location:
                                location = Path(
                                    os.path.expandvars(install_location)
                                )
                                raw_candidates.extend(
                                    [location, location / process_name]
                                )
                            if display_icon:
                                raw_candidates.append(
                                    Path(os.path.expandvars(display_icon))
                                )
                            if uninstall_string:
                                uninstall_path_value = Path(
                                    os.path.expandvars(uninstall_string)
                                )
                                raw_candidates.append(
                                    uninstall_path_value.parent / process_name
                                )
                            for candidate in raw_candidates:
                                if candidate.name.casefold() != process_name.casefold():
                                    continue
                                identity = str(candidate).casefold()
                                if identity not in seen:
                                    seen.add(identity)
                                    candidates.append(candidate)
    return tuple(candidates)


def _fixed_element_infos(root: Any, selector: dict[str, Any]) -> list[Any]:
    criteria = dict(selector)
    auto_id = criteria.pop("auto_id", None)
    framework_id = criteria.pop("framework_id", None)
    allowed = {"title", "control_type", "class_name", "content_only"}
    unknown = set(criteria) - allowed
    if unknown:
        raise ValueError(f"unsupported fixed selector keys: {sorted(unknown)}")
    wrapper = root.wrapper_object() if hasattr(root, "wrapper_object") else root
    infos = list(
        wrapper.element_info.descendants(cache_enable=False, **criteria)
    )
    if auto_id is not None:
        infos = [item for item in infos if item.automation_id == auto_id]
    if framework_id is not None:
        infos = [item for item in infos if item.framework_id == framework_id]
    return infos


def _wrap(infos: Iterable[Any]) -> list[Any]:
    from pywinauto.controls.uiawrapper import UIAWrapper

    return [UIAWrapper(info) for info in infos]


def _is_actionable(control: Any) -> bool:
    try:
        return control.is_visible() and control.is_enabled()
    except Exception:
        return False


def _window_title(window: Any) -> str:
    try:
        return str(window.window_text() or "").strip()
    except Exception:
        return ""


def _window_handle(window: Any) -> int | None:
    try:
        return int(window.handle)
    except Exception:
        return None


def _select_main_window(
    windows: Iterable[Any],
    *,
    process_ids: set[int],
    preferred_title: str,
) -> Any:
    pid_windows: list[Any] = []
    for window in windows:
        try:
            if window.process_id() in process_ids:
                pid_windows.append(window)
        except Exception:
            continue
    title_token = preferred_title.casefold()
    titled = [
        window
        for window in pid_windows
        if title_token in _window_title(window).casefold()
    ]
    if len(titled) == 1:
        return titled[0]
    if not titled and len(pid_windows) == 1:
        return pid_windows[0]
    raise AmbiguousWindow(
        "无法从 BOSS 进程窗口中确定唯一主窗口",
        context=ErrorContext(
            step="select_main_window",
            details={
                "pid_window_count": len(pid_windows),
                "preferred_title_count": len(titled),
                "windows": [
                    {
                        "handle": _window_handle(window),
                        "title": _window_title(window),
                    }
                    for window in pid_windows
                ],
            },
        ),
    )


@dataclass
class BossCandidateSession:
    config: CandidatePipelineConfig = DEFAULT_CONFIG
    timeout: float | None = None
    maximize: bool = True
    restart_for_accessibility: bool = False
    executable: Path | None = None
    version: str | None = None
    handle: int | None = None
    window: Any | None = None

    @property
    def wait_timeout(self) -> float:
        return self.timeout or self.config.default_timeout_seconds

    def connect(self) -> "BossCandidateSession":
        self.executable = locate_executable(self.config)
        self.version = _file_version(self.executable)
        if self.version is None:
            raise UnsupportedVersion(
                "无法读取 BOSS 客户端文件版本，拒绝绕过版本安全门"
            )
        if self.version not in self.config.supported_versions:
            raise UnsupportedVersion(
                f"仅验证过 BOSS {self.config.supported_versions}，检测到 {self.version}"
            )
        if not _processes(self.config.process_name):
            raise AppNotRunning("BOSS 直聘未运行")
        self._attach_unique_window()
        if self.maximize:
            try:
                self.window.maximize()
            except Exception:
                pass
        self.focus()
        ready = self.wait_for(
            lambda: self.has_semantic_accessibility()
            or self.has_login_probe(),
            timeout=8.0,
        )
        if self.has_login_probe():
            raise LoginRequired(
                "BOSS 直聘需要登录后才能执行候选人操作",
                context=ErrorContext(step="login_probe"),
            )
        if not ready or not self.has_semantic_accessibility():
            if self.restart_for_accessibility:
                self._restart_accessible()
            else:
                raise AccessibilityUnavailable(
                    "BOSS 未暴露固定业务控件；请在无未保存草稿时启用 accessibility 重启",
                    context=ErrorContext(
                        step="accessibility_probe",
                        details={"version": self.version},
                    ),
                )
        return self

    def _attach_unique_window(self) -> None:
        from pywinauto import Desktop

        pids = {process.pid for process in _processes(self.config.process_name)}
        windows = Desktop(backend="win32").windows(
            visible_only=True,
            enabled_only=False,
        )
        selected = _select_main_window(
            windows,
            process_ids=pids,
            preferred_title=self.config.app_title,
        )
        self.handle = selected.handle
        self.window = Desktop(backend="uia").window(handle=self.handle)

    def _wait_for_unique_window(self, *, timeout: float) -> None:
        def attach_if_ready() -> bool:
            try:
                self._attach_unique_window()
            except AmbiguousWindow:
                return False
            return self.window is not None

        if self.wait_for(attach_if_ready, timeout=timeout):
            return
        # Raise the precise final ambiguity instead of replacing it with a
        # generic process-start error.
        self._attach_unique_window()

    def _restart_accessible(self) -> None:
        if self.window is None or self.executable is None:
            raise AccessibilityUnavailable("没有可重启的 BOSS 窗口")
        self.window.close()
        if not self.wait_for(
            lambda: not _processes(self.config.process_name),
            timeout=min(3.0, self.wait_timeout),
        ):
            # Electron may keep tray/helper processes alive after the only
            # visible window closes. The caller explicitly opted into an
            # accessibility restart and has already verified there is no
            # unsaved draft, so terminate only this user's exact BOSS binary.
            _terminate_exact_app_processes(
                self.config.process_name,
                self.executable,
                timeout=min(10.0, self.wait_timeout),
            )
        subprocess.Popen(
            [str(self.executable), "--force-renderer-accessibility"],
            cwd=str(self.executable.parent),
            close_fds=True,
        )
        if not self.wait_for(
            lambda: bool(_processes(self.config.process_name)),
            timeout=self.wait_timeout,
        ):
            raise AccessibilityUnavailable("BOSS accessibility 重启失败")
        self._wait_for_unique_window(timeout=self.wait_timeout)
        self.focus()
        ready = self.wait_for(
            lambda: self.has_semantic_accessibility()
            or self.has_login_probe(),
            timeout=self.wait_timeout,
        )
        if self.has_login_probe():
            raise LoginRequired(
                "BOSS 重启后需要重新登录",
                context=ErrorContext(step="login_probe_after_restart"),
            )
        if not ready or not self.has_semantic_accessibility():
            raise AccessibilityUnavailable("BOSS 重启后仍未暴露固定业务控件")

    def focus(self) -> None:
        if self.window is None:
            raise AppNotRunning("BOSS 会话尚未连接")
        try:
            self.window.set_focus()
        except Exception:
            self.window.restore()
            self.window.set_focus()

    def refresh(self) -> None:
        if self.handle is None:
            raise AppNotRunning("BOSS 会话尚未连接")
        from pywinauto import Desktop

        self.window = Desktop(backend="uia").window(handle=self.handle)

    def wait_for(
        self,
        predicate,
        *,
        timeout: float | None = None,
        interval: float = 0.15,
    ) -> bool:
        deadline = time.monotonic() + (timeout or self.wait_timeout)
        while time.monotonic() < deadline:
            try:
                if predicate():
                    return True
            except Exception:
                pass
            time.sleep(interval)
        return False

    def find_all(
        self,
        selector: dict[str, Any],
        *,
        scope: Any | None = None,
        actionable_only: bool = False,
    ) -> list[Any]:
        if self.window is None:
            raise AppNotRunning("BOSS 会话尚未连接")
        controls = _wrap(_fixed_element_infos(scope or self.window, selector))
        if actionable_only:
            controls = [item for item in controls if _is_actionable(item)]
        return controls

    def find_all_alternatives(
        self,
        selectors: Iterable[dict[str, Any]],
        *,
        scope: Any | None = None,
        actionable_only: bool = False,
    ) -> list[Any]:
        seen: set[tuple[Any, ...]] = set()
        result: list[Any] = []
        for selector in selectors:
            for control in self.find_all(
                selector,
                scope=scope,
                actionable_only=actionable_only,
            ):
                try:
                    key = tuple(control.element_info.runtime_id)
                except Exception:
                    key = (control.handle,)
                if key not in seen:
                    seen.add(key)
                    result.append(control)
        return result

    def find_unique(
        self,
        selectors: Iterable[dict[str, Any]],
        *,
        label: str,
        scope: Any | None = None,
        actionable_only: bool = True,
    ) -> Any:
        controls = self.find_all_alternatives(
            selectors,
            scope=scope,
            actionable_only=actionable_only,
        )
        if len(controls) != 1:
            raise AccessibilityUnavailable(
                f"{label} 需要唯一语义控件，实际为 {len(controls)}",
                context=ErrorContext(
                    step="find_unique",
                    details={"label": label, "count": len(controls)},
                ),
            )
        return controls[0]

    def has_semantic_accessibility(self) -> bool:
        try:
            return any(
                self.find_all(selector) for selector in ACCESSIBILITY_PROBES
            )
        except Exception:
            return False

    def has_login_probe(self) -> bool:
        try:
            return any(self.find_all(selector) for selector in LOGIN_PROBES)
        except Exception:
            return False

    def invoke(self, control: Any) -> None:
        """Invoke one already-verified semantic control.

        Electron navigation labels do not all expose InvokePattern. In that
        case click_input is allowed only on the exact, unique semantic wrapper.
        Once a supported pattern has been invoked, an exception is propagated
        instead of trying another mechanism, so a side effect can occur at
        most once.
        """

        self.focus()
        try:
            invoke_pattern = control.iface_invoke
        except Exception:
            invoke_pattern = None
        if invoke_pattern is not None:
            invoke_pattern.Invoke()
            return
        try:
            selection_pattern = control.iface_selection_item
        except Exception:
            selection_pattern = None
        if selection_pattern is not None:
            selection_pattern.Select()
            return
        control.click_input()

    def activate(self, control: Any) -> None:
        """Open one exact semantic item without using SelectionItem alone."""

        self.focus()
        if (
            getattr(control.element_info, "control_type", None)
            == "ListItem"
        ):
            # In BOSS 1.7.4.963 conversation/profile ListItems expose Invoke
            # and SelectionItem patterns, but neither opens the detail pane.
            # A single click_input on the already-verified semantic row does.
            control.click_input()
            return
        try:
            invoke_pattern = control.iface_invoke
        except Exception:
            invoke_pattern = None
        if invoke_pattern is not None:
            invoke_pattern.Invoke()
            return
        # Electron conversation/profile rows expose SelectionItem, but Select
        # only highlights them and does not open their content pane.
        control.click_input()

    def click_relative_to_semantic_anchor(
        self,
        anchor: Any,
        *,
        x_ratio: float,
        y_ratio: float = 0.5,
    ) -> tuple[int, int]:
        """Click once at a point derived entirely from a semantic UIA anchor.

        ``x_ratio`` and ``y_ratio`` are measured in the anchor rectangle's
        width and height from its top-left corner.  The point is rejected
        unless the anchor and target are both within the attached BOSS window.
        This is the version-pinned escape hatch for Electron-painted controls;
        it is not a general coordinate click or a retry mechanism.
        """

        if self.window is None:
            raise AppNotRunning("BOSS 会话尚未连接")
        anchor_rect = anchor.rectangle()
        window_rect = self.window.rectangle()
        width = anchor_rect.right - anchor_rect.left
        height = anchor_rect.bottom - anchor_rect.top
        if width <= 0 or height <= 0:
            raise AccessibilityUnavailable("消息页签语义锚点矩形无效")
        if not (
            window_rect.left <= anchor_rect.left < anchor_rect.right
            <= window_rect.right
            and window_rect.top <= anchor_rect.top < anchor_rect.bottom
            <= window_rect.bottom
        ):
            raise AccessibilityUnavailable(
                "消息页签语义锚点不在 BOSS 主窗口内"
            )
        target = (
            int(round(anchor_rect.left + width * x_ratio)),
            int(round(anchor_rect.top + height * y_ratio)),
        )
        if not (
            window_rect.left <= target[0] < window_rect.right
            and window_rect.top <= target[1] < window_rect.bottom
        ):
            raise AccessibilityUnavailable(
                "语义锚点相对点击目标不在 BOSS 主窗口内"
            )
        self.focus()
        from pywinauto import mouse

        mouse.click(button="left", coords=target)
        return target

    def texts_within(self, control: Any, *, limit: int = 120) -> tuple[str, ...]:
        texts: list[str] = []
        infos = _fixed_element_infos(
            control,
            {"control_type": "Text"},
        )
        for item in infos[:limit]:
            value = (item.name or "").strip()
            if value:
                texts.append(value)
        return tuple(texts)

    def inspect_environment(self) -> dict[str, Any]:
        executable: Path | None
        try:
            executable = locate_executable(self.config)
        except AppNotInstalled:
            executable = None
        processes = _processes(self.config.process_name) if executable else []
        return {
            "installed": executable is not None,
            "running": bool(processes),
            "executable": str(executable) if executable else None,
            "version": _file_version(executable) if executable else None,
            "process_ids": [process.pid for process in processes],
            "selector_profile": SELECTOR_PROFILE,
            "diagnostics_include_screenshots": False,
            "diagnostics_include_candidate_text": False,
        }
