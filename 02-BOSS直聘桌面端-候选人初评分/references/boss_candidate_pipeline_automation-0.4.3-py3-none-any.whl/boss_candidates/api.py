from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Iterable, Protocol

from .config import CandidatePipelineConfig, DEFAULT_CONFIG
from .conversation import (
    RecruitingConversationPolicy,
    compose_recruiter_message,
)
from .errors import CommitUnknown, ConfirmationRequired, ContextMismatch
from .ledger import CandidateLedger
from .models import (
    ActionKind,
    ActionReceipt,
    ActionState,
    Assessment,
    CandidatePage,
    CandidateRecord,
    CandidateRef,
    CandidateSnapshot,
    ConversationPlan,
    ConversationSnapshot,
    JobBindingHint,
    JobRef,
    PreparedAction,
    ReportReceipt,
    ResumeArtifact,
    ResumeParseResult,
    ResumePreviewContent,
    ResumeReceipt,
    stable_hash,
    utc_now,
)
from .reporting import build_candidate_list
from .resume import (
    parse_resume,
    profile_from_resume_text,
    store_uia_preview_resume,
    validate_and_store_resume,
)
from .scoring import Rubric, evaluate_candidate


class BossCandidateAdapter(Protocol):
    def inspect_environment(self) -> dict[str, Any]: ...

    def bind_published_job(self, hint: JobBindingHint) -> JobRef: ...

    def read_job_scoring_context(
        self, job_ref: JobRef
    ) -> dict[str, Any]: ...

    def bind_current_conversation(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef | None = None,
    ) -> CandidateSnapshot: ...

    def verify_job_context(self, job_ref: JobRef) -> tuple[str, ...]: ...

    def scan_new_greetings(
        self, job_ref: JobRef, *, cursor: str | None, limit: int
    ) -> CandidatePage: ...

    def scan_recommendations(
        self, job_ref: JobRef, *, cursor: str | None, limit: int
    ) -> CandidatePage: ...

    def scan_interactions(
        self, job_ref: JobRef, *, cursor: str | None, limit: int
    ) -> CandidatePage: ...

    def read_candidate_profile(
        self, candidate_ref: CandidateRef
    ) -> CandidateSnapshot: ...

    def read_message_candidate_profile(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> CandidateSnapshot: ...

    def read_conversation(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        *,
        expected_inbound_message_id: str | None = None,
    ) -> ConversationSnapshot: ...

    def prepare_action_context(
        self, job_ref: JobRef, candidate_ref: CandidateRef, kind: ActionKind
    ) -> tuple[str, ...]: ...

    def commit_action(
        self,
        action: PreparedAction,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> ActionReceipt: ...

    def reconcile_action(
        self,
        action: PreparedAction,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> ActionReceipt: ...

    def scan_received_resumes(
        self, job_ref: JobRef, *, cursor: str | None, limit: int
    ) -> tuple[tuple[ResumeReceipt, ...], str | None]: ...

    def download_resume(
        self, receipt: ResumeReceipt, *, download_dir: Path
    ) -> Path: ...

    def read_current_resume_preview(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> ResumePreviewContent: ...


class BossCandidatePipeline:
    def __init__(
        self,
        adapter: BossCandidateAdapter | None = None,
        *,
        ledger: CandidateLedger | None = None,
        config: CandidatePipelineConfig = DEFAULT_CONFIG,
    ):
        self.config = config
        self.config.ensure_directories()
        self.ledger = ledger or CandidateLedger(config=config)
        if adapter is None:
            from .ui.adapter import LiveBossAdapter

            adapter = LiveBossAdapter(config=config)
        self.adapter = adapter

    def inspect_environment(self) -> dict[str, Any]:
        return self.adapter.inspect_environment()

    def bind_published_job(
        self, hint: JobBindingHint | dict[str, Any]
    ) -> JobRef:
        if isinstance(hint, dict):
            hint = JobBindingHint(**hint)
        normalized = hint.normalized()
        job = self.adapter.bind_published_job(normalized)
        if not job.binding_evidence:
            raise ValueError("adapter returned a job without binding evidence")
        self.ledger.upsert_job(job)
        return job

    def bind_current_conversation(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef | None = None,
    ) -> CandidateSnapshot:
        self.verify_job_context(job_ref)
        snapshot = self.adapter.bind_current_conversation(
            job_ref,
            candidate_ref,
        )
        if snapshot.candidate_ref.job_key != job_ref.job_key:
            raise ContextMismatch("当前会话候选人与绑定岗位不一致")
        self.ledger.upsert_snapshot(snapshot)
        return snapshot

    def read_job_scoring_context(
        self, job_ref: JobRef
    ) -> dict[str, Any]:
        """Read the bound job's scoring fields from its edit form.

        This is a read-only UI operation.  The adapter must not save or
        publish the form and must return evidence plus a stable source hash.
        """

        context = self.adapter.read_job_scoring_context(job_ref)
        if not isinstance(context, dict):
            raise ContextMismatch("岗位评分上下文必须是结构化对象")
        if context.get("job_key") != job_ref.job_key:
            raise ContextMismatch("岗位评分上下文与绑定岗位不一致")
        if context.get("title") != job_ref.title:
            raise ContextMismatch("岗位评分上下文标题与绑定岗位不一致")
        source_hash = context.get("source_hash")
        if (
            not isinstance(source_hash, str)
            or len(source_hash) != 64
            or any(
                character not in "0123456789abcdef"
                for character in source_hash
            )
        ):
            raise ContextMismatch("岗位评分上下文缺少有效 source_hash")
        evidence = context.get("evidence")
        if (
            not isinstance(evidence, (list, tuple))
            or not evidence
            or not all(isinstance(item, str) for item in evidence)
        ):
            raise ContextMismatch("岗位评分上下文缺少语义回读证据")
        return context

    def verify_job_context(self, job_ref: JobRef) -> tuple[str, ...]:
        evidence = self.adapter.verify_job_context(job_ref)
        if not evidence:
            raise ValueError("job context verification returned no evidence")
        return evidence

    def _scan(
        self,
        method_name: str,
        channel: str,
        job_ref: JobRef,
        *,
        cursor: str | None,
        limit: int,
    ) -> CandidatePage:
        self.verify_job_context(job_ref)
        resolved_cursor = (
            cursor
            if cursor is not None
            else self.ledger.get_cursor(job_ref.job_key, channel)
        )
        method = getattr(self.adapter, method_name)
        page: CandidatePage = method(
            job_ref, cursor=resolved_cursor, limit=limit
        )
        if page.job_ref.job_key != job_ref.job_key:
            raise ValueError("adapter returned candidates for a different job")
        for snapshot in page.items:
            if snapshot.candidate_ref.job_key != job_ref.job_key:
                raise ValueError("candidate snapshot job context mismatch")
            self.ledger.upsert_snapshot(snapshot)
        # Advance only after all snapshots are safely persisted.
        self.ledger.set_cursor(job_ref.job_key, channel, page.next_cursor)
        return page

    def scan_new_greetings(
        self,
        job_ref: JobRef,
        *,
        cursor: str | None = None,
        limit: int = 50,
    ) -> CandidatePage:
        return self._scan(
            "scan_new_greetings",
            "new_greetings",
            job_ref,
            cursor=cursor,
            limit=limit,
        )

    def scan_recommendations(
        self,
        job_ref: JobRef,
        *,
        cursor: str | None = None,
        limit: int = 50,
    ) -> CandidatePage:
        return self._scan(
            "scan_recommendations",
            "recommendations",
            job_ref,
            cursor=cursor,
            limit=limit,
        )

    def scan_interactions(
        self,
        job_ref: JobRef,
        *,
        cursor: str | None = None,
        limit: int = 50,
    ) -> CandidatePage:
        return self._scan(
            "scan_interactions",
            "interactions",
            job_ref,
            cursor=cursor,
            limit=limit,
        )

    def read_candidate_profile(
        self, candidate_ref: CandidateRef
    ) -> CandidateSnapshot:
        snapshot = self.adapter.read_candidate_profile(candidate_ref)
        if snapshot.candidate_ref.candidate_key != candidate_ref.candidate_key:
            raise ValueError("adapter opened a different candidate profile")
        self.ledger.upsert_snapshot(snapshot)
        return snapshot

    def read_message_candidate_profile(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
    ) -> CandidateSnapshot:
        """Open one candidate from Messages and capture a scoring snapshot."""

        snapshot = self.adapter.read_message_candidate_profile(
            job_ref, candidate_ref
        )
        if snapshot.source != "messages.current_profile":
            raise ContextMismatch("候选人评分画像不是从消息入口采集")
        if snapshot.candidate_ref.job_key != job_ref.job_key:
            raise ContextMismatch("候选人评分画像岗位不一致")
        if (
            snapshot.candidate_ref.candidate_key
            != candidate_ref.candidate_key
        ):
            raise ContextMismatch("候选人评分画像身份不一致")
        if (
            candidate_ref.display_name
            and snapshot.candidate_ref.display_name
            != candidate_ref.display_name
        ):
            raise ContextMismatch("候选人评分画像姓名回读不一致")
        if not snapshot.candidate_ref.display_name:
            raise ContextMismatch("候选人评分画像缺少姓名")
        if not snapshot.evidence_refs:
            raise ContextMismatch("候选人评分画像缺少语义证据")
        self.ledger.upsert_snapshot(snapshot)
        return snapshot

    def read_candidate_conversation(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        *,
        expected_inbound_message_id: str | None = None,
    ) -> ConversationSnapshot:
        snapshot = self.adapter.read_conversation(
            job_ref,
            candidate_ref,
            expected_inbound_message_id=(
                expected_inbound_message_id
            ),
        )
        if snapshot.job_key != job_ref.job_key:
            raise ContextMismatch("会话回读岗位与绑定岗位不一致")
        if (
            snapshot.candidate_ref.candidate_key
            != candidate_ref.candidate_key
        ):
            raise ContextMismatch("会话回读候选人与目标候选人不一致")
        if not snapshot.evidence:
            raise ContextMismatch("会话回读缺少语义证据")
        return snapshot

    def plan_candidate_reply(
        self,
        policy: RecruitingConversationPolicy | dict[str, Any],
        *,
        answered_screening_question_ids: tuple[str, ...] = (),
        pending_screening_question_ids: tuple[str, ...] = (),
        candidate_question_ids: tuple[str, ...] = (),
        question_ids_to_ask: tuple[str, ...] | None = None,
    ) -> ConversationPlan:
        return compose_recruiter_message(
            policy,
            answered_screening_question_ids=(
                answered_screening_question_ids
            ),
            pending_screening_question_ids=(
                pending_screening_question_ids
            ),
            candidate_question_ids=candidate_question_ids,
            question_ids_to_ask=question_ids_to_ask,
        )

    def prepare_planned_reply(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        policy: RecruitingConversationPolicy | dict[str, Any],
        *,
        answered_screening_question_ids: tuple[str, ...] = (),
        pending_screening_question_ids: tuple[str, ...] = (),
        candidate_question_ids: tuple[str, ...] = (),
        question_ids_to_ask: tuple[str, ...] | None = None,
        expected_inbound_message_id: str | None = None,
    ) -> tuple[
        ConversationSnapshot,
        ConversationPlan,
        PreparedAction | None,
    ]:
        conversation = self.read_candidate_conversation(
            job_ref,
            candidate_ref,
            expected_inbound_message_id=(
                expected_inbound_message_id
            ),
        )
        if (
            expected_inbound_message_id
            and conversation.latest_inbound_message_id
            != expected_inbound_message_id
        ):
            raise ContextMismatch(
                "最新入站消息已变化，必须重新读取并重新规划回复"
            )
        if (
            not conversation.latest_inbound_message_id
            or not conversation.latest_inbound_text
        ):
            raise ContextMismatch(
                "无法把回复绑定到当前唯一的最新入站消息，停止准备发送"
            )
        plan = self.plan_candidate_reply(
            policy,
            answered_screening_question_ids=(
                answered_screening_question_ids
            ),
            pending_screening_question_ids=(
                pending_screening_question_ids
            ),
            candidate_question_ids=candidate_question_ids,
            question_ids_to_ask=question_ids_to_ask,
        )
        if not plan.rendered_text:
            return conversation, plan, None
        action = self.prepare_candidate_action(
            job_ref,
            candidate_ref,
            kind=ActionKind.REPLY,
            payload=plan.rendered_text,
            triggering_event_id=conversation.latest_inbound_message_id,
        )
        return conversation, plan, action

    def score_candidate(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        rubric: Rubric | dict[str, Any],
    ) -> Assessment:
        snapshot = self.ledger.latest_snapshot(
            job_ref.job_key, candidate_ref.candidate_key
        )
        if snapshot is None:
            snapshot = self.read_candidate_profile(candidate_ref)
        assessment = evaluate_candidate(snapshot, rubric)
        self.ledger.save_assessment(
            job_ref.job_key, candidate_ref.candidate_key, assessment
        )
        return assessment

    def prepare_candidate_action(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        *,
        kind: ActionKind | str,
        payload: str = "",
        triggering_event_id: str | None = None,
    ) -> PreparedAction:
        kind = ActionKind(kind)
        normalized_payload = "\n".join(
            normalize
            for line in payload.splitlines()
            if (normalize := " ".join(line.split()))
        )
        if kind is ActionKind.REPLY and not normalized_payload:
            raise ValueError("reply payload must not be empty")
        if kind is not ActionKind.REPLY and normalized_payload:
            # A greeting may use platform text, but a supplied payload changes
            # what will be transmitted and therefore participates in the key.
            normalized_payload = payload.strip()
        context_evidence = self.adapter.prepare_action_context(
            job_ref, candidate_ref, kind
        )
        if not context_evidence:
            raise ValueError("candidate action context was not verified")
        now = datetime.now(UTC)
        expires = now + timedelta(
            seconds=self.config.action_confirmation_ttl_seconds
        )
        action_id = stable_hash(
            job_ref.job_key,
            candidate_ref.candidate_key,
            kind.value,
            normalized_payload,
            triggering_event_id,
        )
        action = PreparedAction(
            action_id=action_id,
            job_key=job_ref.job_key,
            candidate_key=candidate_ref.candidate_key,
            kind=kind,
            payload=normalized_payload,
            payload_hash=stable_hash(normalized_payload),
            triggering_event_id=triggering_event_id,
            state=ActionState.AWAITING_CONFIRMATION,
            prepared_at=now.isoformat(),
            confirmation_expires_at=expires.isoformat(),
        )
        saved = self.ledger.save_prepared_action(action)
        if saved.state is ActionState.AWAITING_CONFIRMATION:
            self.ledger.mark_action_prepared(saved)
        return saved

    def execute_prepared_action(
        self,
        action_id: str,
        *,
        confirmed_action_id: str | None,
    ) -> ActionReceipt:
        """Execute one authorized action with an unchanged idempotency token.

        The caller decides whether the current task authorizes outbound
        communication. Once authorized, it passes the prepared ``action_id``
        back unchanged; this token check is not a prompt for another user
        confirmation.
        """

        action = self.ledger.get_action(action_id)
        if confirmed_action_id != action.action_id:
            raise ConfirmationRequired(
                "提交令牌必须与已准备动作的 action_id 完全一致"
            )
        expires = datetime.fromisoformat(action.confirmation_expires_at)
        if datetime.now(UTC) > expires:
            raise ConfirmationRequired("动作提交令牌已过期，请重新准备动作")
        if action.state not in {
            ActionState.AWAITING_CONFIRMATION,
            ActionState.PREPARED,
        }:
            raise ConfirmationRequired(
                f"动作当前状态为 {action.state.value}，不能再次提交"
            )
        job_ref = self.ledger.get_job(action.job_key)
        if job_ref is None:
            raise KeyError(f"unknown job: {action.job_key}")
        candidate_ref = self.ledger.get_candidate_record(
            action.job_key, action.candidate_key
        ).candidate_ref
        self.ledger.transition_action(
            action.action_id,
            expected={action.state},
            target=ActionState.SUBMITTING,
        )
        submitting = self.ledger.get_action(action.action_id)
        try:
            receipt = self.adapter.commit_action(
                submitting, job_ref, candidate_ref
            )
        except CommitUnknown:
            self.ledger.transition_action(
                action.action_id,
                expected={ActionState.SUBMITTING},
                target=ActionState.COMMIT_UNKNOWN,
            )
            self.ledger.mark_action_result(
                action, ActionState.COMMIT_UNKNOWN
            )
            raise
        except Exception:
            self.ledger.transition_action(
                action.action_id,
                expected={ActionState.SUBMITTING},
                target=ActionState.FAILED_SAFE,
            )
            raise
        if receipt.state is not ActionState.SUCCEEDED:
            self.ledger.transition_action(
                action.action_id,
                expected={ActionState.SUBMITTING},
                target=ActionState.COMMIT_UNKNOWN,
                evidence=receipt.evidence,
            )
            self.ledger.mark_action_result(
                action, ActionState.COMMIT_UNKNOWN
            )
            raise CommitUnknown(
                "动作已调用，但缺少确定性成功证据；禁止重发，只能 reconcile"
            )
        self.ledger.transition_action(
            action.action_id,
            expected={ActionState.SUBMITTING},
            target=ActionState.SUCCEEDED,
            evidence=receipt.evidence,
        )
        self.ledger.mark_action_result(action, ActionState.SUCCEEDED)
        return receipt

    def reconcile_candidate_action(self, action_id: str) -> ActionReceipt:
        action = self.ledger.get_action(action_id)
        if action.state is not ActionState.COMMIT_UNKNOWN:
            return ActionReceipt(
                action_id=action.action_id,
                state=action.state,
                message="动作无需核对",
            )
        job_ref = self.ledger.get_job(action.job_key)
        if job_ref is None:
            raise KeyError(f"unknown job: {action.job_key}")
        candidate_ref = self.ledger.get_candidate_record(
            action.job_key, action.candidate_key
        ).candidate_ref
        receipt = self.adapter.reconcile_action(
            action, job_ref, candidate_ref
        )
        if receipt.state is ActionState.SUCCEEDED:
            self.ledger.transition_action(
                action_id,
                expected={ActionState.COMMIT_UNKNOWN},
                target=ActionState.SUCCEEDED,
                evidence=receipt.evidence,
            )
            self.ledger.mark_action_result(action, ActionState.SUCCEEDED)
        return receipt

    def _record_resume_receipt(
        self, job_ref: JobRef, receipt: ResumeReceipt
    ) -> None:
        if receipt.candidate_ref.job_key != job_ref.job_key:
            raise ContextMismatch("简历回执候选人与当前岗位不一致")
        snapshot = CandidateSnapshot.create(
            receipt.candidate_ref,
            source="received_resumes",
            profile={
                "attachment_file_name": receipt.file_name,
                "attachment_received_at": receipt.received_at,
            },
            evidence_refs=receipt.evidence,
        )
        self.ledger.upsert_snapshot(snapshot)
        self.ledger.mark_resume_received(
            job_ref.job_key, receipt.candidate_ref.candidate_key
        )

    def scan_received_resumes(
        self,
        job_ref: JobRef,
        *,
        cursor: str | None = None,
        limit: int = 50,
    ) -> tuple[tuple[ResumeReceipt, ...], str | None]:
        self.verify_job_context(job_ref)
        channel = "received_resumes"
        resolved_cursor = (
            cursor
            if cursor is not None
            else self.ledger.get_cursor(job_ref.job_key, channel)
        )
        receipts, next_cursor = self.adapter.scan_received_resumes(
            job_ref, cursor=resolved_cursor, limit=limit
        )
        for receipt in receipts:
            self._record_resume_receipt(job_ref, receipt)
        self.ledger.set_cursor(job_ref.job_key, channel, next_cursor)
        return receipts, next_cursor

    def collect_resume(
        self,
        receipt: ResumeReceipt,
        *,
        output_dir: str | Path | None = None,
    ) -> ResumeArtifact:
        job_ref = self.ledger.get_job(receipt.candidate_ref.job_key)
        if job_ref is None:
            raise KeyError(f"unknown job: {receipt.candidate_ref.job_key}")
        self._record_resume_receipt(job_ref, receipt)
        download_dir = self.config.state_dir / "downloads"
        download_dir.mkdir(parents=True, exist_ok=True)
        downloaded = self.adapter.download_resume(
            receipt, download_dir=download_dir
        )
        artifact = validate_and_store_resume(
            downloaded,
            job_key=receipt.candidate_ref.job_key,
            candidate_key=receipt.candidate_ref.candidate_key,
            target_dir=output_dir or self.config.resume_dir,
            config=self.config,
        )
        return self.ledger.save_resume_artifact(artifact)

    def parse_resume(self, artifact: ResumeArtifact):
        parsed = parse_resume(artifact)
        return self._persist_parsed_resume(parsed)

    def _persist_parsed_resume(
        self,
        parsed: ResumeParseResult,
    ) -> ResumeParseResult:
        self.ledger.save_resume_artifact(parsed.artifact)
        record = self.ledger.get_candidate_record(
            parsed.artifact.job_key,
            parsed.artifact.candidate_key,
        )
        profile = profile_from_resume_text(
            parsed.text,
            text_hash=parsed.artifact.text_hash,
            parse_quality=parsed.parse_quality,
        )
        self.ledger.upsert_snapshot(
            CandidateSnapshot.create(
                record.candidate_ref,
                source="parsed_resume",
                profile=profile,
                evidence_refs=(f"resume:{parsed.artifact.sha256}",),
            )
        )
        return parsed

    def collect_current_resume_preview(
        self,
        job_ref: JobRef,
        candidate_ref: CandidateRef,
        *,
        output_dir: str | Path | None = None,
    ) -> ResumeParseResult:
        """Collect the current attachment through its semantic preview.

        The adapter verifies the already-bound underlying conversation before
        opening or reading the preview. Only inert UTF-8 text is persisted.
        """

        stored_job = self.ledger.get_job(job_ref.job_key)
        if stored_job is None:
            raise KeyError(f"unknown job: {job_ref.job_key}")
        record = self.ledger.get_candidate_record(
            job_ref.job_key,
            candidate_ref.candidate_key,
        )
        if record.candidate_ref.job_key != job_ref.job_key:
            raise ContextMismatch("候选人与当前岗位不一致")
        preview = self.adapter.read_current_resume_preview(
            job_ref,
            record.candidate_ref,
        )
        if (
            preview.candidate_ref.job_key != job_ref.job_key
            or preview.candidate_ref.candidate_key
            != candidate_ref.candidate_key
        ):
            raise ContextMismatch("UIA 简历预览回执与所选岗位或候选人不一致")
        receipt = ResumeReceipt(
            receipt_id=stable_hash(
                "uia-preview",
                preview.candidate_ref.candidate_key,
                preview.file_name,
                preview.text_hash,
            ),
            candidate_ref=preview.candidate_ref,
            file_name=preview.file_name,
            attachment_id=f"uia-preview:{preview.text_hash}",
            received_at=preview.observed_at,
            evidence=preview.evidence,
        )
        self._record_resume_receipt(job_ref, receipt)
        parsed = store_uia_preview_resume(
            preview,
            target_dir=output_dir or self.config.resume_dir,
            config=self.config,
        )
        return self._persist_parsed_resume(parsed)

    def list_candidates(
        self,
        job_ref: JobRef,
        *,
        candidate_keys: Iterable[str] | None = None,
    ) -> list[CandidateRecord]:
        return self.ledger.list_candidate_records(
            job_ref.job_key,
            candidate_keys=candidate_keys,
        )

    def build_candidate_list(
        self,
        job_ref: JobRef,
        *,
        output_dir: str | Path | None = None,
        formats: tuple[str, ...] = ("json", "md"),
        privacy_mode: str = "masked",
        candidate_keys: Iterable[str] | None = None,
    ) -> ReportReceipt:
        records = self.list_candidates(
            job_ref,
            candidate_keys=candidate_keys,
        )
        return build_candidate_list(
            job_ref,
            records,
            output_dir=output_dir or self.config.report_dir,
            formats=formats,
            privacy_mode=privacy_mode,
        )
