from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ErrorContext:
    step: str | None = None
    selector: dict[str, Any] | None = None
    details: dict[str, Any] = field(default_factory=dict)


class CandidatePipelineError(RuntimeError):
    code = "CANDIDATE_PIPELINE_ERROR"

    def __init__(self, message: str, *, context: ErrorContext | None = None):
        super().__init__(message)
        self.context = context or ErrorContext()

    def as_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": str(self),
            "context": {
                "step": self.context.step,
                "selector": self.context.selector,
                "details": self.context.details,
            },
        }


class AppNotInstalled(CandidatePipelineError):
    code = "APP_NOT_INSTALLED"


class AppNotRunning(CandidatePipelineError):
    code = "APP_NOT_RUNNING"


class LoginRequired(CandidatePipelineError):
    code = "LOGIN_REQUIRED"


class UnsupportedVersion(CandidatePipelineError):
    code = "UNSUPPORTED_VERSION"


class AmbiguousWindow(CandidatePipelineError):
    code = "AMBIGUOUS_WINDOW"


class AccessibilityUnavailable(CandidatePipelineError):
    code = "ACCESSIBILITY_UNAVAILABLE"


class ContextMismatch(CandidatePipelineError):
    code = "CONTEXT_MISMATCH"


class AmbiguousJob(CandidatePipelineError):
    code = "AMBIGUOUS_JOB"


class CandidateIdentityConflict(CandidatePipelineError):
    code = "CANDIDATE_IDENTITY_CONFLICT"


class UnsafeScoringCriterion(CandidatePipelineError):
    code = "UNSAFE_SCORING_CRITERION"


class InvalidStateTransition(CandidatePipelineError):
    code = "INVALID_STATE_TRANSITION"


class ConfirmationRequired(CandidatePipelineError):
    code = "ACTION_TIME_CONFIRMATION_REQUIRED"


class CommitUnknown(CandidatePipelineError):
    code = "COMMIT_UNKNOWN"


class UnsafeResume(CandidatePipelineError):
    code = "UNSAFE_RESUME"


class ResumeParseError(CandidatePipelineError):
    code = "RESUME_PARSE_ERROR"
