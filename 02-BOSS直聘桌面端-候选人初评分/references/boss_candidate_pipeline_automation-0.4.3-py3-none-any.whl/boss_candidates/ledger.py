from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable, Iterator

from .config import CandidatePipelineConfig, DEFAULT_CONFIG
from .errors import InvalidStateTransition
from .models import (
    ActionKind,
    ActionState,
    Assessment,
    BindingStrength,
    CandidateRecord,
    CandidateRef,
    CandidateSnapshot,
    CommunicationState,
    DiscoveryState,
    DispositionState,
    EvaluationState,
    IdentityConfidence,
    JobRef,
    PreparedAction,
    ResumeArtifact,
    ResumeState,
    canonical_json,
    stable_hash,
    utc_now,
)


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS jobs (
    job_key TEXT PRIMARY KEY,
    payload_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS candidates (
    candidate_key TEXT PRIMARY KEY,
    platform_candidate_id TEXT,
    conversation_id TEXT,
    identity_confidence TEXT NOT NULL,
    display_name TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS job_candidates (
    job_key TEXT NOT NULL,
    candidate_key TEXT NOT NULL,
    sources_json TEXT NOT NULL,
    discovery_state TEXT NOT NULL,
    communication_state TEXT NOT NULL,
    resume_state TEXT NOT NULL,
    evaluation_state TEXT NOT NULL,
    disposition_state TEXT NOT NULL,
    assessment_json TEXT,
    first_seen_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL,
    PRIMARY KEY (job_key, candidate_key),
    FOREIGN KEY (job_key) REFERENCES jobs(job_key)
);

CREATE TABLE IF NOT EXISTS candidate_snapshots (
    content_hash TEXT PRIMARY KEY,
    job_key TEXT NOT NULL,
    candidate_key TEXT NOT NULL,
    source TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    payload_json TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS candidate_snapshots_job_candidate
ON candidate_snapshots(job_key, candidate_key, observed_at DESC);

CREATE TABLE IF NOT EXISTS scan_cursors (
    job_key TEXT NOT NULL,
    channel TEXT NOT NULL,
    cursor TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (job_key, channel)
);

CREATE TABLE IF NOT EXISTS actions (
    action_id TEXT PRIMARY KEY,
    job_key TEXT NOT NULL,
    candidate_key TEXT NOT NULL,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    triggering_event_id TEXT,
    state TEXT NOT NULL,
    prepared_at TEXT NOT NULL,
    confirmation_expires_at TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '[]',
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS resume_artifacts (
    artifact_id TEXT PRIMARY KEY,
    job_key TEXT NOT NULL,
    candidate_key TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(job_key, candidate_key, sha256),
    FOREIGN KEY (job_key) REFERENCES jobs(job_key)
);

CREATE TABLE IF NOT EXISTS report_runs (
    report_id TEXT PRIMARY KEY,
    job_key TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    generated_at TEXT NOT NULL
);
"""


def _dump(value: Any) -> str:
    if hasattr(value, "as_dict"):
        value = value.as_dict()
    return canonical_json(value)


def _load(value: str | None, default: Any) -> Any:
    if value is None:
        return default
    return json.loads(value)


class CandidateLedger:
    def __init__(
        self,
        path: Path | None = None,
        *,
        config: CandidatePipelineConfig = DEFAULT_CONFIG,
    ):
        self.config = config
        self.path = Path(path or config.database_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as connection:
            connection.executescript(SCHEMA)

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=15)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def upsert_job(self, job: JobRef) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT INTO jobs(job_key, payload_json, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(job_key) DO UPDATE SET
                    payload_json=excluded.payload_json,
                    updated_at=excluded.updated_at
                """,
                (job.job_key, _dump(job), utc_now()),
            )

    def get_job(self, job_key: str) -> JobRef | None:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT payload_json FROM jobs WHERE job_key=?", (job_key,)
            ).fetchone()
        if row is None:
            return None
        payload = _load(row["payload_json"], {})
        payload["binding_strength"] = BindingStrength(payload["binding_strength"])
        payload["binding_evidence"] = tuple(payload.get("binding_evidence", []))
        return JobRef(**payload)

    def upsert_snapshot(self, snapshot: CandidateSnapshot) -> bool:
        """Persist a snapshot and merge its source into the job-candidate row.

        Returns ``True`` only when the immutable content hash was new. Callers
        can avoid unnecessary rescoring when this returns ``False``.
        """

        now = snapshot.observed_at
        ref = snapshot.candidate_ref
        with self.connection() as connection:
            inserted = (
                connection.execute(
                    """
                    INSERT OR IGNORE INTO candidate_snapshots(
                        content_hash, job_key, candidate_key, source,
                        observed_at, payload_json
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        snapshot.content_hash,
                        ref.job_key,
                        ref.candidate_key,
                        snapshot.source,
                        snapshot.observed_at,
                        _dump(snapshot),
                    ),
                ).rowcount
                == 1
            )
            connection.execute(
                """
                INSERT INTO candidates(
                    candidate_key, platform_candidate_id, conversation_id,
                    identity_confidence, display_name, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(candidate_key) DO UPDATE SET
                    platform_candidate_id=COALESCE(
                        excluded.platform_candidate_id,
                        candidates.platform_candidate_id
                    ),
                    conversation_id=COALESCE(
                        excluded.conversation_id,
                        candidates.conversation_id
                    ),
                    identity_confidence=CASE
                        WHEN candidates.identity_confidence='EXACT'
                            THEN candidates.identity_confidence
                        ELSE excluded.identity_confidence
                    END,
                    display_name=COALESCE(excluded.display_name, candidates.display_name),
                    updated_at=excluded.updated_at
                """,
                (
                    ref.candidate_key,
                    ref.platform_candidate_id,
                    ref.conversation_id,
                    ref.identity_confidence.value,
                    ref.display_name,
                    now,
                ),
            )
            existing = connection.execute(
                """
                SELECT sources_json, first_seen_at
                FROM job_candidates
                WHERE job_key=? AND candidate_key=?
                """,
                (ref.job_key, ref.candidate_key),
            ).fetchone()
            sources = set(_load(existing["sources_json"], [])) if existing else set()
            sources.add(snapshot.source)
            first_seen = existing["first_seen_at"] if existing else now
            connection.execute(
                """
                INSERT INTO job_candidates(
                    job_key, candidate_key, sources_json, discovery_state,
                    communication_state, resume_state, evaluation_state,
                    disposition_state, assessment_json, first_seen_at, last_seen_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
                ON CONFLICT(job_key, candidate_key) DO UPDATE SET
                    sources_json=excluded.sources_json,
                    discovery_state=CASE
                        WHEN job_candidates.discovery_state='ASSESSED'
                            THEN job_candidates.discovery_state
                        ELSE 'PROFILE_READ'
                    END,
                    evaluation_state=CASE
                        WHEN ? THEN 'STALE'
                        ELSE job_candidates.evaluation_state
                    END,
                    last_seen_at=excluded.last_seen_at
                """,
                (
                    ref.job_key,
                    ref.candidate_key,
                    _dump(sorted(sources)),
                    DiscoveryState.PROFILE_READ.value,
                    CommunicationState.NONE.value,
                    ResumeState.NONE.value,
                    EvaluationState.NOT_EVALUATED.value,
                    DispositionState.ACTIVE.value,
                    first_seen,
                    now,
                    1 if inserted and existing else 0,
                ),
            )
            if snapshot.source in {
                "new_greetings",
                "messages.new_greetings",
            }:
                connection.execute(
                    """
                    UPDATE job_candidates
                    SET communication_state=?, last_seen_at=?
                    WHERE job_key=? AND candidate_key=?
                      AND communication_state=?
                    """,
                    (
                        CommunicationState.INBOUND_RECEIVED.value,
                        now,
                        ref.job_key,
                        ref.candidate_key,
                        CommunicationState.NONE.value,
                    ),
                )
        return inserted

    def latest_snapshot(
        self, job_key: str, candidate_key: str
    ) -> CandidateSnapshot | None:
        with self.connection() as connection:
            rows = connection.execute(
                """
                SELECT payload_json FROM candidate_snapshots
                WHERE job_key=? AND candidate_key=?
                ORDER BY observed_at ASC, rowid ASC
                """,
                (job_key, candidate_key),
            ).fetchall()
        if not rows:
            return None
        merged_profile: dict[str, Any] = {}
        evidence_refs: list[str] = []
        sources: list[str] = []
        latest_payload: dict[str, Any] | None = None
        for row in rows:
            payload = _load(row["payload_json"], {})
            latest_payload = payload
            sources.append(payload["source"])
            for key, value in payload.get("profile", {}).items():
                if value not in (None, "", [], {}, ()):
                    merged_profile[key] = value
            for evidence in payload.get("evidence_refs", []):
                if evidence not in evidence_refs:
                    evidence_refs.append(evidence)
        assert latest_payload is not None
        ref_data = dict(latest_payload["candidate_ref"])
        ref_data["identity_confidence"] = IdentityConfidence(
            ref_data["identity_confidence"]
        )
        candidate_ref = CandidateRef(**ref_data)
        observed_at = latest_payload["observed_at"]
        return CandidateSnapshot(
            candidate_ref=candidate_ref,
            source="merged:" + ",".join(dict.fromkeys(sources)),
            observed_at=observed_at,
            profile=merged_profile,
            content_hash=stable_hash(
                candidate_ref.candidate_key, merged_profile
            ),
            evidence_refs=tuple(evidence_refs),
        )

    def save_assessment(
        self, job_key: str, candidate_key: str, assessment: Assessment
    ) -> None:
        with self.connection() as connection:
            updated = connection.execute(
                """
                UPDATE job_candidates
                SET discovery_state=?, evaluation_state=?, assessment_json=?,
                    last_seen_at=?
                WHERE job_key=? AND candidate_key=?
                """,
                (
                    DiscoveryState.ASSESSED.value,
                    EvaluationState.EVALUATED.value,
                    _dump(assessment),
                    utc_now(),
                    job_key,
                    candidate_key,
                ),
            ).rowcount
        if updated != 1:
            raise KeyError(f"unknown job candidate: {job_key}/{candidate_key}")

    def list_candidate_records(
        self,
        job_key: str,
        *,
        candidate_keys: Iterable[str] | None = None,
    ) -> list[CandidateRecord]:
        requested_keys: tuple[str, ...] | None = None
        if candidate_keys is not None:
            if isinstance(candidate_keys, (str, bytes)):
                raise TypeError("candidate_keys must be an iterable of candidate keys")
            unique_keys: list[str] = []
            seen_keys: set[str] = set()
            for candidate_key in candidate_keys:
                if not isinstance(candidate_key, str) or not candidate_key:
                    raise ValueError(
                        "candidate_keys must contain non-empty strings"
                    )
                if candidate_key not in seen_keys:
                    unique_keys.append(candidate_key)
                    seen_keys.add(candidate_key)
            requested_keys = tuple(unique_keys)
            if not requested_keys:
                return []
        query = """
                SELECT jc.*, c.platform_candidate_id, c.conversation_id,
                       c.identity_confidence, c.display_name
                FROM job_candidates jc
                JOIN candidates c ON c.candidate_key=jc.candidate_key
                WHERE jc.job_key=?
                """
        parameters: list[str] = [job_key]
        if requested_keys is not None:
            placeholders = ", ".join("?" for _ in requested_keys)
            query += f" AND jc.candidate_key IN ({placeholders})"
            parameters.extend(requested_keys)
        query += " ORDER BY jc.last_seen_at DESC"
        with self.connection() as connection:
            rows = connection.execute(
                query,
                parameters,
            ).fetchall()
        result: list[CandidateRecord] = []
        for row in rows:
            ref = CandidateRef(
                candidate_key=row["candidate_key"],
                job_key=row["job_key"],
                display_name=row["display_name"],
                platform_candidate_id=row["platform_candidate_id"],
                conversation_id=row["conversation_id"],
                identity_confidence=IdentityConfidence(row["identity_confidence"]),
            )
            assessment_payload = _load(row["assessment_json"], None)
            assessment = (
                _assessment_from_dict(assessment_payload)
                if assessment_payload is not None
                else None
            )
            result.append(
                CandidateRecord(
                    candidate_ref=ref,
                    sources=tuple(_load(row["sources_json"], [])),
                    discovery_state=DiscoveryState(row["discovery_state"]),
                    communication_state=CommunicationState(
                        row["communication_state"]
                    ),
                    resume_state=ResumeState(row["resume_state"]),
                    evaluation_state=EvaluationState(row["evaluation_state"]),
                    disposition_state=DispositionState(row["disposition_state"]),
                    latest_snapshot=self.latest_snapshot(
                        row["job_key"], row["candidate_key"]
                    ),
                    assessment=assessment,
                    first_seen_at=row["first_seen_at"],
                    last_seen_at=row["last_seen_at"],
                )
            )
        if requested_keys is None:
            return result

        records_by_key = {
            record.candidate_ref.candidate_key: record for record in result
        }
        missing_keys = [
            candidate_key
            for candidate_key in requested_keys
            if candidate_key not in records_by_key
        ]
        if missing_keys:
            raise KeyError(
                "unknown candidate in requested job scope: "
                + ", ".join(missing_keys)
            )
        requested_key_set = set(requested_keys)
        return [
            record
            for record in result
            if record.candidate_ref.candidate_key in requested_key_set
        ]

    def get_candidate_record(
        self, job_key: str, candidate_key: str
    ) -> CandidateRecord:
        for record in self.list_candidate_records(job_key):
            if record.candidate_ref.candidate_key == candidate_key:
                return record
        raise KeyError(f"unknown job candidate: {job_key}/{candidate_key}")

    def set_cursor(self, job_key: str, channel: str, cursor: str | None) -> None:
        with self.connection() as connection:
            connection.execute(
                """
                INSERT INTO scan_cursors(job_key, channel, cursor, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(job_key, channel) DO UPDATE SET
                    cursor=excluded.cursor,
                    updated_at=excluded.updated_at
                """,
                (job_key, channel, cursor, utc_now()),
            )

    def get_cursor(self, job_key: str, channel: str) -> str | None:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT cursor FROM scan_cursors WHERE job_key=? AND channel=?",
                (job_key, channel),
            ).fetchone()
        return None if row is None else row["cursor"]

    def save_prepared_action(self, action: PreparedAction) -> PreparedAction:
        with self.connection() as connection:
            # Serialize the event-level read/supersede/insert sequence so two
            # planners cannot leave two simultaneously executable drafts.
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT * FROM actions WHERE action_id=?", (action.action_id,)
            ).fetchone()
            if row is not None:
                state = ActionState(row["state"])
                expires = datetime.fromisoformat(
                    row["confirmation_expires_at"]
                )
                if state is ActionState.FAILED_SAFE:
                    connection.execute(
                        """
                        UPDATE actions
                        SET state=?, prepared_at=?, confirmation_expires_at=?,
                            evidence_json='[]', updated_at=?
                        WHERE action_id=? AND state=?
                        """,
                        (
                            ActionState.AWAITING_CONFIRMATION.value,
                            action.prepared_at,
                            action.confirmation_expires_at,
                            utc_now(),
                            action.action_id,
                            ActionState.FAILED_SAFE.value,
                        ),
                    )
                    return action
                if (
                    state
                    in {
                        ActionState.PREPARED,
                        ActionState.AWAITING_CONFIRMATION,
                    }
                    and datetime.now(UTC) > expires
                ):
                    connection.execute(
                        """
                        UPDATE actions
                        SET prepared_at=?, confirmation_expires_at=?,
                            evidence_json='[]', updated_at=?
                        WHERE action_id=?
                        """,
                        (
                            action.prepared_at,
                            action.confirmation_expires_at,
                            utc_now(),
                            action.action_id,
                        ),
                    )
                    return action
                return PreparedAction(
                    action_id=row["action_id"],
                    job_key=row["job_key"],
                    candidate_key=row["candidate_key"],
                    kind=ActionKind(row["kind"]),
                    payload=row["payload"],
                    payload_hash=row["payload_hash"],
                    triggering_event_id=row["triggering_event_id"],
                    state=state,
                    prepared_at=row["prepared_at"],
                    confirmation_expires_at=(
                        row["confirmation_expires_at"]
                    ),
                )

            event_is_deduplicated = not (
                action.kind is ActionKind.REPLY
                and action.triggering_event_id is None
            )
            if event_is_deduplicated:
                related = connection.execute(
                    """
                    SELECT action_id, state FROM actions
                    WHERE job_key=? AND candidate_key=? AND kind=?
                      AND triggering_event_id IS ? AND action_id<>?
                    """,
                    (
                        action.job_key,
                        action.candidate_key,
                        action.kind.value,
                        action.triggering_event_id,
                        action.action_id,
                    ),
                ).fetchall()
                terminal = [
                    item
                    for item in related
                    if ActionState(item["state"])
                    in {
                        ActionState.SUBMITTING,
                        ActionState.SUCCEEDED,
                        ActionState.COMMIT_UNKNOWN,
                    }
                ]
                if terminal:
                    raise InvalidStateTransition(
                        "该入站事件已有提交中、成功或结果未知的动作，"
                        "禁止准备第二条回复"
                    )
                superseded = [
                    item["action_id"]
                    for item in related
                    if ActionState(item["state"])
                    in {
                        ActionState.PREPARED,
                        ActionState.AWAITING_CONFIRMATION,
                    }
                ]
                if superseded:
                    placeholders = ",".join("?" for _ in superseded)
                    connection.execute(
                        f"""
                        UPDATE actions
                        SET state=?, evidence_json=?, updated_at=?
                        WHERE action_id IN ({placeholders})
                        """,
                        (
                            ActionState.FAILED_SAFE.value,
                            _dump([f"superseded_by={action.action_id}"]),
                            utc_now(),
                            *superseded,
                        ),
                    )
            connection.execute(
                """
                INSERT INTO actions(
                    action_id, job_key, candidate_key, kind, payload,
                    payload_hash, triggering_event_id, state, prepared_at,
                    confirmation_expires_at, evidence_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', ?)
                """,
                (
                    action.action_id,
                    action.job_key,
                    action.candidate_key,
                    action.kind.value,
                    action.payload,
                    action.payload_hash,
                    action.triggering_event_id,
                    action.state.value,
                    action.prepared_at,
                    action.confirmation_expires_at,
                    utc_now(),
                ),
            )
            return action

    def get_action(self, action_id: str) -> PreparedAction:
        with self.connection() as connection:
            row = connection.execute(
                "SELECT * FROM actions WHERE action_id=?", (action_id,)
            ).fetchone()
        if row is None:
            raise KeyError(f"unknown action: {action_id}")
        return PreparedAction(
            action_id=row["action_id"],
            job_key=row["job_key"],
            candidate_key=row["candidate_key"],
            kind=ActionKind(row["kind"]),
            payload=row["payload"],
            payload_hash=row["payload_hash"],
            triggering_event_id=row["triggering_event_id"],
            state=ActionState(row["state"]),
            prepared_at=row["prepared_at"],
            confirmation_expires_at=row["confirmation_expires_at"],
        )

    def transition_action(
        self,
        action_id: str,
        *,
        expected: set[ActionState],
        target: ActionState,
        evidence: list[str] | tuple[str, ...] = (),
    ) -> PreparedAction:
        action = self.get_action(action_id)
        if action.state not in expected:
            raise InvalidStateTransition(
                f"action {action_id} is {action.state}; expected "
                + ", ".join(sorted(item.value for item in expected))
            )
        with self.connection() as connection:
            changed = connection.execute(
                """
                UPDATE actions
                SET state=?, evidence_json=?, updated_at=?
                WHERE action_id=? AND state=?
                """,
                (
                    target.value,
                    _dump(list(evidence)),
                    utc_now(),
                    action_id,
                    action.state.value,
                ),
            ).rowcount
            if changed != 1:
                raise InvalidStateTransition(
                    f"action {action_id} changed concurrently; reload before retry"
                )
        return replace(action, state=target)

    def mark_action_prepared(self, action: PreparedAction) -> None:
        with self.connection() as connection:
            if action.kind is ActionKind.RESUME_REQUEST:
                changed = connection.execute(
                    """
                    UPDATE job_candidates
                    SET resume_state=?, last_seen_at=?
                    WHERE job_key=? AND candidate_key=?
                    """,
                    (
                        ResumeState.REQUEST_PREPARED.value,
                        utc_now(),
                        action.job_key,
                        action.candidate_key,
                    ),
                ).rowcount
            else:
                state = (
                    CommunicationState.OUTREACH_PREPARED
                    if action.kind is ActionKind.GREETING
                    else CommunicationState.REPLY_PREPARED
                )
                changed = connection.execute(
                    """
                    UPDATE job_candidates
                    SET communication_state=?, last_seen_at=?
                    WHERE job_key=? AND candidate_key=?
                    """,
                    (
                        state.value,
                        utc_now(),
                        action.job_key,
                        action.candidate_key,
                    ),
                ).rowcount
        if changed != 1:
            raise KeyError(
                f"unknown job candidate: {action.job_key}/{action.candidate_key}"
            )

    def mark_action_result(
        self, action: PreparedAction, state: ActionState
    ) -> None:
        if state not in {
            ActionState.SUCCEEDED,
            ActionState.COMMIT_UNKNOWN,
        }:
            return
        with self.connection() as connection:
            if action.kind is ActionKind.RESUME_REQUEST:
                resume_state = (
                    ResumeState.REQUESTED
                    if state is ActionState.SUCCEEDED
                    else ResumeState.COMMIT_UNKNOWN
                )
                changed = connection.execute(
                    """
                    UPDATE job_candidates
                    SET resume_state=?, last_seen_at=?
                    WHERE job_key=? AND candidate_key=?
                    """,
                    (
                        resume_state.value,
                        utc_now(),
                        action.job_key,
                        action.candidate_key,
                    ),
                ).rowcount
            else:
                communication_state = (
                    CommunicationState.SENT
                    if state is ActionState.SUCCEEDED
                    else CommunicationState.COMMIT_UNKNOWN
                )
                changed = connection.execute(
                    """
                    UPDATE job_candidates
                    SET communication_state=?, last_seen_at=?
                    WHERE job_key=? AND candidate_key=?
                    """,
                    (
                        communication_state.value,
                        utc_now(),
                        action.job_key,
                        action.candidate_key,
                    ),
                ).rowcount
        if changed != 1:
            raise KeyError(
                f"unknown job candidate: {action.job_key}/{action.candidate_key}"
            )

    def mark_resume_received(self, job_key: str, candidate_key: str) -> None:
        with self.connection() as connection:
            changed = connection.execute(
                """
                UPDATE job_candidates
                SET resume_state=CASE
                        WHEN resume_state IN (
                            'DOWNLOADED', 'VALIDATED', 'PARSED', 'REVIEWED'
                        ) THEN resume_state
                        ELSE ?
                    END,
                    last_seen_at=?
                WHERE job_key=? AND candidate_key=?
                """,
                (
                    ResumeState.RECEIVED.value,
                    utc_now(),
                    job_key,
                    candidate_key,
                ),
            ).rowcount
        if changed != 1:
            raise KeyError(f"unknown job candidate: {job_key}/{candidate_key}")

    def save_resume_artifact(self, artifact: ResumeArtifact) -> ResumeArtifact:
        rank = {
            ResumeState.NONE: 0,
            ResumeState.REQUEST_PREPARED: 1,
            ResumeState.REQUESTED: 2,
            ResumeState.RECEIVED: 3,
            ResumeState.DOWNLOADED: 4,
            ResumeState.VALIDATED: 5,
            ResumeState.PARSED: 6,
            ResumeState.REVIEWED: 7,
            ResumeState.UNREADABLE: 7,
            ResumeState.COMMIT_UNKNOWN: 2,
        }
        with self.connection() as connection:
            existing = connection.execute(
                "SELECT payload_json FROM resume_artifacts WHERE artifact_id=?",
                (artifact.artifact_id,),
            ).fetchone()
            if existing:
                payload = _load(existing["payload_json"], {})
                payload["state"] = ResumeState(payload["state"])
                stored = ResumeArtifact(**payload)
                if rank[stored.state] > rank[artifact.state]:
                    artifact = stored
            connection.execute(
                """
                INSERT INTO resume_artifacts(
                    artifact_id, job_key, candidate_key, sha256,
                    payload_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(artifact_id) DO UPDATE SET
                    payload_json=excluded.payload_json,
                    updated_at=excluded.updated_at
                """,
                (
                    artifact.artifact_id,
                    artifact.job_key,
                    artifact.candidate_key,
                    artifact.sha256,
                    _dump(artifact),
                    utc_now(),
                ),
            )
            changed = connection.execute(
                """
                UPDATE job_candidates
                SET resume_state=?, last_seen_at=?
                WHERE job_key=? AND candidate_key=?
                """,
                (
                    artifact.state.value,
                    utc_now(),
                    artifact.job_key,
                    artifact.candidate_key,
                ),
            ).rowcount
            if changed != 1:
                raise KeyError(
                    "unknown job candidate: "
                    f"{artifact.job_key}/{artifact.candidate_key}"
                )
        return artifact


def _assessment_from_dict(payload: dict[str, Any]) -> Assessment:
    from .models import (
        CriterionEvidence,
        EvidenceKind,
        EvidenceOutcome,
        HardGate,
        RecommendationBand,
    )

    evidence = []
    for item in payload.get("evidence", []):
        item = dict(item)
        item["kind"] = EvidenceKind(item["kind"])
        item["outcome"] = EvidenceOutcome(item["outcome"])
        item["evidence_refs"] = tuple(item.get("evidence_refs", []))
        evidence.append(CriterionEvidence(**item))
    return Assessment(
        rubric_version=payload["rubric_version"],
        hard_gate=HardGate(payload["hard_gate"]),
        score=int(payload["score"]),
        coverage=float(payload["coverage"]),
        band=RecommendationBand(payload["band"]),
        evidence=tuple(evidence),
        reason_codes=tuple(payload.get("reason_codes", [])),
        gaps=tuple(payload.get("gaps", [])),
        conflicts=tuple(payload.get("conflicts", [])),
        assessed_at=payload.get("assessed_at") or utc_now(),
    )
