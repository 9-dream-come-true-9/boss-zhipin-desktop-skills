from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from .models import ConversationPlan, normalize_text


@dataclass(frozen=True)
class ScreeningQuestion:
    question_id: str
    text: str

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "ScreeningQuestion":
        question_id = normalize_text(value.get("id"))
        text = normalize_text(value.get("text"))
        if not question_id or not text:
            raise ValueError("screening question requires non-empty id and text")
        return cls(question_id=question_id, text=text)


@dataclass(frozen=True)
class ApprovedAnswer:
    answer_id: str
    text: str

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "ApprovedAnswer":
        answer_id = normalize_text(value.get("id"))
        text = normalize_text(value.get("text"))
        if not answer_id or not text:
            raise ValueError("approved answer requires non-empty id and text")
        return cls(answer_id=answer_id, text=text)


@dataclass(frozen=True)
class RecruitingConversationPolicy:
    version: str
    opening: str
    followup_opening: str
    screening_questions: tuple[ScreeningQuestion, ...]
    approved_answers: tuple[ApprovedAnswer, ...]
    max_questions_per_message: int = 4

    @classmethod
    def from_dict(
        cls, value: dict[str, Any]
    ) -> "RecruitingConversationPolicy":
        version = normalize_text(value.get("version")) or "1"
        questions = tuple(
            ScreeningQuestion.from_dict(item)
            for item in value.get("screening_questions", [])
        )
        answers = tuple(
            ApprovedAnswer.from_dict(item)
            for item in value.get("approved_answers", [])
        )
        question_ids = [item.question_id for item in questions]
        answer_ids = [item.answer_id for item in answers]
        if len(question_ids) != len(set(question_ids)):
            raise ValueError("screening question ids must be unique")
        if len(answer_ids) != len(set(answer_ids)):
            raise ValueError("approved answer ids must be unique")
        maximum = int(value.get("max_questions_per_message", 4))
        if maximum < 1 or maximum > 10:
            raise ValueError("max_questions_per_message must be between 1 and 10")
        return cls(
            version=version,
            opening=normalize_text(value.get("opening")),
            followup_opening=normalize_text(value.get("followup_opening")),
            screening_questions=questions,
            approved_answers=answers,
            max_questions_per_message=maximum,
        )


def _unique(values: Iterable[str]) -> tuple[str, ...]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        item = normalize_text(value)
        if item and item not in seen:
            seen.add(item)
            result.append(item)
    return tuple(result)


def _join_opening_and_question(opening: str, question: str) -> str:
    if not opening:
        return question
    if opening.endswith(("，", "。", "：", "；", "？", "！", ",", ".", ":", ";", "?", "!")):
        return f"{opening}{question}"
    return f"{opening} {question}"


def compose_recruiter_message(
    policy: RecruitingConversationPolicy | dict[str, Any],
    *,
    answered_screening_question_ids: Iterable[str] = (),
    pending_screening_question_ids: Iterable[str] = (),
    candidate_question_ids: Iterable[str] = (),
    question_ids_to_ask: Iterable[str] | None = None,
) -> ConversationPlan:
    """Compose only approved answers and explicitly selected screening questions.

    The caller must map conversation evidence to stable IDs. This function
    deliberately performs no semantic guessing from candidate text.
    """

    if isinstance(policy, dict):
        policy = RecruitingConversationPolicy.from_dict(policy)
    answered = _unique(answered_screening_question_ids)
    pending = _unique(pending_screening_question_ids)
    candidate_questions = _unique(candidate_question_ids)
    question_map = {
        item.question_id: item for item in policy.screening_questions
    }
    answer_map = {item.answer_id: item for item in policy.approved_answers}
    unknown_answered = sorted(set(answered) - set(question_map))
    unknown_pending = sorted(set(pending) - set(question_map))
    unknown_candidate_questions = sorted(
        set(candidate_questions) - set(answer_map)
    )
    if unknown_answered:
        raise ValueError(
            "unknown answered screening question ids: "
            + ", ".join(unknown_answered)
        )
    if unknown_pending:
        raise ValueError(
            "unknown pending screening question ids: "
            + ", ".join(unknown_pending)
        )
    overlap = sorted(set(answered) & set(pending))
    if overlap:
        raise ValueError(
            "screening questions cannot be both answered and pending: "
            + ", ".join(overlap)
        )
    if unknown_candidate_questions:
        raise ValueError(
            "candidate questions lack approved answers: "
            + ", ".join(unknown_candidate_questions)
        )

    unanswered = [
        item.question_id
        for item in policy.screening_questions
        if item.question_id not in set(answered)
        and item.question_id not in set(pending)
    ]
    if question_ids_to_ask is None:
        selected_questions = unanswered[: policy.max_questions_per_message]
    else:
        selected_questions = list(_unique(question_ids_to_ask))
        invalid = sorted(
            set(selected_questions) - set(unanswered)
        )
        if invalid:
            raise ValueError(
                "questions_to_ask must be unanswered screening questions: "
                + ", ".join(invalid)
            )
        selected_questions = selected_questions[
            : policy.max_questions_per_message
        ]

    answer_lines = [
        answer_map[answer_id].text
        for answer_id in candidate_questions
    ]
    question_lines = [
        question_map[question_id].text
        for question_id in selected_questions
    ]
    body_lines = [*answer_lines, *question_lines]
    if not body_lines:
        rendered = ""
    elif answer_lines and not question_lines:
        rendered = "\n".join(answer_lines)
    elif len(question_lines) == 1 and not answer_lines:
        prefix = policy.followup_opening or policy.opening
        rendered = _join_opening_and_question(prefix, question_lines[0])
    else:
        prefix = policy.opening or policy.followup_opening
        numbered_questions = [
            f"{index}.{text}"
            for index, text in enumerate(question_lines, start=1)
        ]
        rendered = "\n".join(
            item
            for item in (
                prefix,
                *answer_lines,
                *numbered_questions,
            )
            if item
        )
    return ConversationPlan(
        policy_version=policy.version,
        candidate_question_ids=candidate_questions,
        answered_screening_question_ids=answered,
        pending_screening_question_ids=pending,
        answer_entry_ids=candidate_questions,
        question_ids_to_ask=tuple(selected_questions),
        rendered_text=rendered,
        requires_confirmation=bool(rendered),
    )
