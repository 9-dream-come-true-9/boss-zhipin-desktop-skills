from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _default_state_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA")
    if base:
        return Path(base) / "Codex" / "boss-candidate-pipeline"
    return Path.cwd() / ".boss-candidate-pipeline"


@dataclass(frozen=True)
class CandidatePipelineConfig:
    state_dir: Path = _default_state_dir()
    supported_versions: tuple[str, ...] = ("1.7.4.963",)
    process_name: str = "boss-zhipin.exe"
    app_title: str = "BOSS直聘"
    default_timeout_seconds: float = 30.0
    action_confirmation_ttl_seconds: int = 300
    max_resume_bytes: int = 20 * 1024 * 1024
    diagnostics_include_screenshots: bool = False
    diagnostics_include_candidate_text: bool = False

    @property
    def database_path(self) -> Path:
        return self.state_dir / "candidate-ledger.sqlite3"

    @property
    def resume_dir(self) -> Path:
        return self.state_dir / "resumes"

    @property
    def report_dir(self) -> Path:
        return self.state_dir / "reports"

    def ensure_directories(self) -> None:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.resume_dir.mkdir(parents=True, exist_ok=True)
        self.report_dir.mkdir(parents=True, exist_ok=True)


DEFAULT_CONFIG = CandidatePipelineConfig()

