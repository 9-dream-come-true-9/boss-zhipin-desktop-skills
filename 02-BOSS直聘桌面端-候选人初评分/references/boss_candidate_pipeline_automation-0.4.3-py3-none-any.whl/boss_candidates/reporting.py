from __future__ import annotations

import csv
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

from .models import (
    CandidateRecord,
    JobRef,
    RecommendationBand,
    ReportReceipt,
    stable_hash,
    utc_now,
)


BAND_ORDER = {
    RecommendationBand.PRIORITY_REVIEW: 0,
    RecommendationBand.PROMISING_WITH_GAPS: 1,
    RecommendationBand.INSUFFICIENT_EVIDENCE: 2,
    RecommendationBand.NOT_RECOMMENDED: 3,
}

BAND_TITLES = {
    RecommendationBand.PRIORITY_REVIEW: "优先人工复核",
    RecommendationBand.PROMISING_WITH_GAPS: "有潜力但需补证",
    RecommendationBand.INSUFFICIENT_EVIDENCE: "信息覆盖不足",
    RecommendationBand.NOT_RECOMMENDED: "暂不建议推进",
}

SAFE_PROFILE_FIELDS = (
    "education",
    "major",
    "graduation",
    "availability",
    "desired_role",
    "experience_summary",
    "skills",
)

PROFILE_MARKERS = {
    "education": ("大专", "本科", "硕士", "博士"),
    "major": ("大学", "学院", "专业"),
    "graduation": ("毕业", "应届", "届"),
    "availability": ("每周", "到岗", "实习时长", "可实习", "个月", "出勤"),
    "desired_role": ("求职意向", "期望", "目标岗位"),
    "experience_summary": (
        "工作",
        "实习",
        "项目",
        "产品",
        "运营",
        "文案",
        "策划",
        "内容",
    ),
}

PROFILE_SEGMENT_LIMITS = {
    "availability": 1,
    "experience_summary": 2,
}


def mask_display_name(value: str | None, fallback: str) -> str:
    name = (value or "").strip()
    if not name or name == "求职者":
        return fallback
    if len(name) == 1:
        return name
    if len(name) == 2:
        return name[0] + "*"
    return name[0] + "*" * (len(name) - 2) + name[-1]


def _bounded_profile_value(key: str, value: Any) -> Any:
    if isinstance(value, (list, tuple, set)):
        items = []
        for item in value:
            normalized = re.sub(r"\s+", " ", str(item)).strip()
            if normalized and normalized not in items:
                items.append(normalized[:48])
        return items[:12]
    if not isinstance(value, str):
        return value
    normalized = re.sub(r"\s+", " ", value).strip()
    normalized = re.sub(
        r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b",
        "[邮箱已省略]",
        normalized,
    )
    normalized = re.sub(
        r"(?<!\d)1[3-9]\d{9}(?!\d)",
        "[手机号已省略]",
        normalized,
    )
    normalized = re.sub(
        r"(?<!\d)\d{17}[\dXx](?!\d)",
        "[证件号已省略]",
        normalized,
    )
    segments = [
        item.strip(" ，,。；;：:")
        for item in re.split(r"[\r\n。！？；;]+", normalized)
        if item.strip(" ，,。；;：:")
    ]
    markers = PROFILE_MARKERS.get(key, ())
    relevant = [
        segment
        for segment in segments
        if not markers or any(marker in segment for marker in markers)
    ]
    limit = PROFILE_SEGMENT_LIMITS.get(key, 3)
    chosen = relevant[:limit] or segments[:1]
    bounded = "；".join(item[:120] for item in chosen)
    return bounded[:240]


def _profile_summary(record: CandidateRecord) -> dict[str, Any]:
    if record.latest_snapshot is None:
        return {}
    profile = record.latest_snapshot.profile
    return {
        key: _bounded_profile_value(key, profile[key])
        for key in SAFE_PROFILE_FIELDS
        if key in profile and profile[key] not in (None, "", [], {})
    }


def _next_action(record: CandidateRecord) -> dict[str, Any]:
    assessment = record.assessment
    if assessment is None:
        return {
            "type": "READ_PROFILE",
            "reason": "尚未形成证据化评估",
            "requires_confirmation": False,
        }
    if assessment.band is RecommendationBand.PRIORITY_REVIEW:
        action = (
            "READ_INBOUND_AND_PREPARE_REPLY"
            if record.communication_state.value
            in {"INBOUND_RECEIVED", "REPLIED"}
            else "REVIEW_PROFILE_AND_PREPARE_OUTREACH"
        )
        return {
            "type": action,
            "reason": "岗位相关证据较强，先人工复核再决定外发",
            "requires_confirmation": False,
        }
    if assessment.band is RecommendationBand.PROMISING_WITH_GAPS:
        return {
            "type": "COLLECT_MISSING_EVIDENCE",
            "reason": "存在匹配证据，但仍有关键未知项",
            "requires_confirmation": False,
        }
    if assessment.band is RecommendationBand.INSUFFICIENT_EVIDENCE:
        return {
            "type": "WAIT_OR_COLLECT_EVIDENCE",
            "reason": "当前证据覆盖不足",
            "requires_confirmation": False,
        }
    return {
        "type": "HUMAN_REVIEW_BEFORE_HOLD",
        "reason": "有明确岗位相关冲突；不自动改变平台候选人状态",
        "requires_confirmation": False,
    }


def candidate_report_payload(
    job: JobRef,
    records: Iterable[CandidateRecord],
    *,
    privacy_mode: str = "masked",
) -> dict[str, Any]:
    rows = list(records)
    rows.sort(
        key=lambda record: (
            BAND_ORDER.get(
                record.assessment.band
                if record.assessment
                else RecommendationBand.INSUFFICIENT_EVIDENCE,
                9,
            ),
            -(record.assessment.score if record.assessment else -1),
            record.candidate_ref.candidate_key,
        )
    )
    candidates: list[dict[str, Any]] = []
    for index, record in enumerate(rows, start=1):
        assessment = record.assessment
        fallback = f"候选人-{index:02d}"
        candidate_label = (
            mask_display_name(record.candidate_ref.display_name, fallback)
            if privacy_mode == "masked"
            else (record.candidate_ref.display_name or fallback)
        )
        candidates.append(
            {
                "candidate_job_id": stable_hash(
                    job.job_key, record.candidate_ref.candidate_key
                ),
                "candidate_label": candidate_label,
                "candidate_key": record.candidate_ref.candidate_key,
                "identity_confidence": record.candidate_ref.identity_confidence.value,
                "sources": list(record.sources),
                "pipeline": {
                    "discovery": record.discovery_state.value,
                    "communication": record.communication_state.value,
                    "resume": record.resume_state.value,
                    "evaluation": record.evaluation_state.value,
                    "disposition": record.disposition_state.value,
                },
                "profile_summary": _profile_summary(record),
                "evaluation": (
                    {
                        "band": assessment.band.value,
                        "score": assessment.score,
                        "coverage": assessment.coverage,
                        "hard_gate": assessment.hard_gate.value,
                        "evidence": [
                            item.as_dict() for item in assessment.evidence
                        ],
                        "gaps": list(assessment.gaps),
                        "conflicts": list(assessment.conflicts),
                        "reason_codes": list(assessment.reason_codes),
                        "rubric_version": assessment.rubric_version,
                    }
                    if assessment
                    else None
                ),
                "next_action": _next_action(record),
                "updated_at": record.last_seen_at,
            }
        )
    bands = Counter(
        (
            record.assessment.band.value
            if record.assessment
            else RecommendationBand.INSUFFICIENT_EVIDENCE.value
        )
        for record in rows
    )
    resume_states = Counter(record.resume_state.value for record in rows)
    return {
        "schema_version": "1.0",
        "generated_at": utc_now(),
        "job": job.as_dict(),
        "scope": {"through_phase": "P4"},
        "summary": {
            "total": len(rows),
            "by_band": dict(sorted(bands.items())),
            "by_resume_state": dict(sorted(resume_states.items())),
        },
        "candidates": candidates,
        "privacy": {
            "mode": privacy_mode,
            "pii_fields_omitted": [
                "photo",
                "gender",
                "age",
                "phone",
                "wechat",
                "email",
                "precise_address",
                "full_chat_text",
                "resume_full_text",
            ],
        },
    }


def _summary_text(value: Any) -> str:
    if isinstance(value, dict):
        return "；".join(f"{key}: {_summary_text(item)}" for key, item in value.items())
    if isinstance(value, list):
        return "、".join(_summary_text(item) for item in value)
    return str(value or "")


def render_markdown(payload: dict[str, Any]) -> str:
    job = payload["job"]
    lines = [
        f"# {job['title']}候选人清单",
        "",
        f"- 生成时间：{payload['generated_at']}",
        f"- 去重后候选人：{payload['summary']['total']} 人",
        f"- 隐私模式：{payload['privacy']['mode']}",
        "",
        "> 该清单仅用于岗位相关证据的优先级复核，不是自动录用或淘汰结论。未知信息不会按不匹配处理。",
        "",
    ]
    grouped: dict[str, list[dict[str, Any]]] = {}
    for candidate in payload["candidates"]:
        evaluation = candidate.get("evaluation") or {}
        band = evaluation.get(
            "band", RecommendationBand.INSUFFICIENT_EVIDENCE.value
        )
        grouped.setdefault(band, []).append(candidate)
    for band in RecommendationBand:
        items = grouped.get(band.value, [])
        if not items:
            continue
        lines.extend(
            [
                f"## {BAND_TITLES[band]}",
                "",
                "| 候选人 | 来源 / 阶段 | 画像摘要 | 匹配证据 | 缺口或冲突 | 评分 / 覆盖率 | 建议下一步 |",
                "|---|---|---|---|---|---|---|",
            ]
        )
        for candidate in items:
            evaluation = candidate.get("evaluation") or {}
            evidence = evaluation.get("evidence", [])
            evidence_text = "；".join(
                item.get("observed_summary", "")
                for item in evidence[:3]
                if item.get("observed_summary")
            )
            issues = evaluation.get("conflicts") or evaluation.get("gaps") or []
            score = evaluation.get("score", "-")
            coverage = evaluation.get("coverage")
            coverage_text = (
                f"{round(float(coverage) * 100)}%" if coverage is not None else "-"
            )
            pipeline = candidate["pipeline"]
            stage = f"{pipeline['communication']} / {pipeline['resume']}"
            lines.append(
                "| "
                + " | ".join(
                    [
                        str(candidate["candidate_label"]),
                        f"{','.join(candidate['sources'])} / {stage}",
                        _summary_text(candidate["profile_summary"]).replace("|", "/"),
                        evidence_text.replace("|", "/"),
                        "；".join(str(item) for item in issues).replace("|", "/"),
                        f"{score} / {coverage_text}",
                        candidate["next_action"]["type"],
                    ]
                )
                + " |"
            )
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def build_candidate_list(
    job: JobRef,
    records: Iterable[CandidateRecord],
    *,
    output_dir: str | Path,
    formats: tuple[str, ...] = ("json", "md"),
    privacy_mode: str = "masked",
) -> ReportReceipt:
    output = Path(output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    payload = candidate_report_payload(
        job, records, privacy_mode=privacy_mode
    )
    stem = f"candidate-list-{job.job_key[:16]}"
    written: list[str] = []
    if "json" in formats:
        path = output / f"{stem}.json"
        path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        written.append(str(path))
    if "md" in formats:
        path = output / f"{stem}.md"
        path.write_text(render_markdown(payload), encoding="utf-8")
        written.append(str(path))
    if "csv" in formats:
        path = output / f"{stem}.csv"
        with path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=[
                    "candidate_label",
                    "sources",
                    "communication_state",
                    "resume_state",
                    "recommendation_band",
                    "score",
                    "coverage",
                    "profile_summary",
                    "gaps",
                    "conflicts",
                    "next_action",
                ],
            )
            writer.writeheader()
            for candidate in payload["candidates"]:
                evaluation = candidate.get("evaluation") or {}
                writer.writerow(
                    {
                        "candidate_label": candidate["candidate_label"],
                        "sources": ",".join(candidate["sources"]),
                        "communication_state": candidate["pipeline"][
                            "communication"
                        ],
                        "resume_state": candidate["pipeline"]["resume"],
                        "recommendation_band": evaluation.get("band", ""),
                        "score": evaluation.get("score", ""),
                        "coverage": evaluation.get("coverage", ""),
                        "profile_summary": _summary_text(
                            candidate["profile_summary"]
                        ),
                        "gaps": "；".join(evaluation.get("gaps", [])),
                        "conflicts": "；".join(
                            evaluation.get("conflicts", [])
                        ),
                        "next_action": candidate["next_action"]["type"],
                    }
                )
        written.append(str(path))
    return ReportReceipt(
        job_key=job.job_key,
        total_candidates=payload["summary"]["total"],
        output_files=tuple(written),
        generated_at=payload["generated_at"],
    )
