from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from .errors import UnsafeScoringCriterion
from .models import (
    Assessment,
    CandidateSnapshot,
    CriterionEvidence,
    EvidenceKind,
    EvidenceOutcome,
    HardGate,
    RecommendationBand,
    normalize_text,
)


PROTECTED_OR_IRRELEVANT_FIELDS = {
    "age",
    "birth_date",
    "birthday",
    "disability",
    "ethnicity",
    "face",
    "family_status",
    "gender",
    "health",
    "marital_status",
    "medical",
    "name",
    "nationality",
    "photo",
    "pregnancy",
    "race",
    "religion",
    "sex",
}


@dataclass(frozen=True)
class RubricCriterion:
    criterion_id: str
    field: str
    expected: str
    kind: EvidenceKind = EvidenceKind.WEIGHTED
    weight: float = 1.0
    any_terms: tuple[str, ...] = ()
    all_terms: tuple[str, ...] = ()
    mismatch_terms: tuple[str, ...] = ()
    allow_partial: bool = True

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "RubricCriterion":
        return cls(
            criterion_id=str(value["criterion_id"]),
            field=str(value["field"]),
            expected=str(value.get("expected", "")),
            kind=EvidenceKind(value.get("kind", EvidenceKind.WEIGHTED.value)),
            weight=float(value.get("weight", 1.0)),
            any_terms=tuple(str(item) for item in value.get("any_terms", [])),
            all_terms=tuple(str(item) for item in value.get("all_terms", [])),
            mismatch_terms=tuple(
                str(item) for item in value.get("mismatch_terms", [])
            ),
            allow_partial=bool(value.get("allow_partial", True)),
        )


@dataclass(frozen=True)
class Rubric:
    version: str
    criteria: tuple[RubricCriterion, ...]
    priority_threshold: int = 80
    promising_threshold: int = 55
    minimum_coverage: float = 0.45

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "Rubric":
        criteria = tuple(
            RubricCriterion.from_dict(item) for item in value.get("criteria", [])
        )
        rubric = cls(
            version=str(value.get("version", "1")),
            criteria=criteria,
            priority_threshold=int(value.get("priority_threshold", 80)),
            promising_threshold=int(value.get("promising_threshold", 55)),
            minimum_coverage=float(value.get("minimum_coverage", 0.45)),
        )
        validate_rubric(rubric)
        return rubric


def validate_rubric(rubric: Rubric) -> None:
    if not rubric.criteria:
        raise ValueError("rubric must contain at least one criterion")
    for criterion in rubric.criteria:
        path_parts = {part.casefold() for part in criterion.field.split(".")}
        blocked = sorted(path_parts & PROTECTED_OR_IRRELEVANT_FIELDS)
        if blocked:
            raise UnsafeScoringCriterion(
                f"criterion {criterion.criterion_id} uses prohibited field(s): "
                + ", ".join(blocked)
            )
        if criterion.weight < 0:
            raise ValueError(
                f"criterion {criterion.criterion_id} has a negative weight"
            )


def _resolve_field(profile: dict[str, Any], path: str) -> Any:
    value: Any = profile
    for part in path.split("."):
        if not isinstance(value, dict):
            return None
        value = value.get(part)
    return value


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, dict):
        return " ".join(_as_text(item) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return " ".join(_as_text(item) for item in value)
    return normalize_text(str(value))


def _contains(text: str, term: str) -> bool:
    return normalize_text(term).casefold() in text.casefold()


def evaluate_criterion(
    snapshot: CandidateSnapshot, criterion: RubricCriterion
) -> CriterionEvidence:
    raw = _resolve_field(snapshot.profile, criterion.field)
    observed = _as_text(raw)
    if not observed:
        outcome = EvidenceOutcome.UNKNOWN
        summary = "当前页面没有可核验信息"
        confidence = 0.0
    elif mismatch_hits := [
        term
        for term in criterion.mismatch_terms
        if _contains(observed, term)
    ]:
        outcome = EvidenceOutcome.MISMATCH
        summary = "命中排除关键词：" + "、".join(mismatch_hits)
        confidence = 1.0
    else:
        any_hits = [
            term for term in criterion.any_terms if _contains(observed, term)
        ]
        all_hits = [
            term for term in criterion.all_terms if _contains(observed, term)
        ]
        all_ok = not criterion.all_terms or len(all_hits) == len(
            criterion.all_terms
        )
        any_ok = not criterion.any_terms or bool(any_hits)
        if all_ok and any_ok:
            outcome = EvidenceOutcome.MATCH
            confidence = 1.0
            matched_terms = tuple(dict.fromkeys((*any_hits, *all_hits)))
            summary = (
                "命中规则关键词：" + "、".join(matched_terms)
                if matched_terms
                else "字段存在可核验信息"
            )
        elif criterion.allow_partial and (any_hits or all_hits):
            outcome = EvidenceOutcome.PARTIAL
            confidence = 0.65
            matched_terms = tuple(dict.fromkeys((*any_hits, *all_hits)))
            summary = "部分命中规则关键词：" + "、".join(matched_terms)
        else:
            # Absence of a required term in a populated field is not always
            # proof of mismatch. It remains UNKNOWN unless the rubric supplied
            # an explicit mismatch term.
            outcome = EvidenceOutcome.UNKNOWN
            confidence = 0.35
            summary = "字段已有信息，但未命中已配置的规则关键词"
    return CriterionEvidence(
        criterion_id=criterion.criterion_id,
        kind=criterion.kind,
        expected=criterion.expected,
        outcome=outcome,
        observed_summary=summary,
        evidence_refs=tuple(snapshot.evidence_refs),
        confidence=confidence,
        weight=criterion.weight,
    )


def evaluate_candidate(
    snapshot: CandidateSnapshot,
    rubric: Rubric | dict[str, Any],
    *,
    supplemental_evidence: Iterable[CriterionEvidence] = (),
) -> Assessment:
    if isinstance(rubric, dict):
        rubric = Rubric.from_dict(rubric)
    validate_rubric(rubric)
    evidence = [evaluate_criterion(snapshot, item) for item in rubric.criteria]
    supplemental = {item.criterion_id: item for item in supplemental_evidence}
    evidence = [supplemental.get(item.criterion_id, item) for item in evidence]

    gate_evidence = [item for item in evidence if item.kind is EvidenceKind.GATE]
    if any(
        item.outcome in {EvidenceOutcome.MISMATCH, EvidenceOutcome.CONFLICT}
        for item in gate_evidence
    ):
        hard_gate = HardGate.FAIL
    elif gate_evidence and all(
        item.outcome is EvidenceOutcome.MATCH for item in gate_evidence
    ):
        hard_gate = HardGate.PASS
    else:
        hard_gate = HardGate.UNKNOWN

    weighted = [
        item
        for item in evidence
        if item.kind in {EvidenceKind.WEIGHTED, EvidenceKind.RISK}
    ]
    available_weight = sum(
        item.weight
        for item in weighted
        if item.outcome is not EvidenceOutcome.UNKNOWN
    )
    total_weight = sum(item.weight for item in weighted)
    points = 0.0
    for item in weighted:
        multiplier = {
            EvidenceOutcome.MATCH: 1.0,
            EvidenceOutcome.PARTIAL: 0.55,
            EvidenceOutcome.MISMATCH: 0.0,
            EvidenceOutcome.CONFLICT: 0.0,
            EvidenceOutcome.UNKNOWN: 0.0,
        }[item.outcome]
        if item.kind is EvidenceKind.RISK:
            multiplier = 1.0 - multiplier
        points += item.weight * multiplier
    score = round(100 * points / total_weight) if total_weight else 0
    known_count = sum(
        item.outcome is not EvidenceOutcome.UNKNOWN for item in evidence
    )
    coverage = round(known_count / len(evidence), 4) if evidence else 0.0

    gaps = tuple(
        item.expected
        for item in evidence
        if item.outcome is EvidenceOutcome.UNKNOWN
    )
    conflicts = tuple(
        item.observed_summary
        for item in evidence
        if item.outcome
        in {
            EvidenceOutcome.MISMATCH,
            EvidenceOutcome.CONFLICT,
        }
    )
    reason_codes: list[str] = []
    if hard_gate is HardGate.FAIL:
        band = RecommendationBand.NOT_RECOMMENDED
        reason_codes.append("HARD_GATE_FAILED")
    elif coverage < rubric.minimum_coverage:
        band = RecommendationBand.INSUFFICIENT_EVIDENCE
        reason_codes.append("LOW_EVIDENCE_COVERAGE")
    elif score >= rubric.priority_threshold:
        band = RecommendationBand.PRIORITY_REVIEW
    elif score >= rubric.promising_threshold:
        band = RecommendationBand.PROMISING_WITH_GAPS
    else:
        band = RecommendationBand.NOT_RECOMMENDED
        reason_codes.append("LOW_JOB_RELATED_SCORE")
    if hard_gate is HardGate.UNKNOWN:
        reason_codes.append("HARD_GATE_NEEDS_EVIDENCE")
    if available_weight < total_weight:
        reason_codes.append("WEIGHTED_EVIDENCE_INCOMPLETE")

    return Assessment(
        rubric_version=rubric.version,
        hard_gate=hard_gate,
        score=max(0, min(100, score)),
        coverage=coverage,
        band=band,
        evidence=tuple(evidence),
        reason_codes=tuple(reason_codes),
        gaps=gaps,
        conflicts=conflicts,
    )
