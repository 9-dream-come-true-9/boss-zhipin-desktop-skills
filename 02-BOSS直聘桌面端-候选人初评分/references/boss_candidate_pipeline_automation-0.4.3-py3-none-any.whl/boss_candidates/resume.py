from __future__ import annotations

import hashlib
import os
import re
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

from .config import CandidatePipelineConfig, DEFAULT_CONFIG
from .errors import ResumeParseError, UnsafeResume
from .models import (
    ResumeArtifact,
    ResumeParseResult,
    ResumePreviewContent,
    ResumeState,
    stable_hash,
)


PDF_MAGIC = b"%PDF-"
ZIP_MAGIC = b"PK\x03\x04"
ALLOWED_EXTENSIONS = {".pdf", ".docx"}
WORD_NAMESPACE = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
MAX_DOCX_ENTRIES = 2_000
MAX_DOCX_UNCOMPRESSED_BYTES = 100 * 1024 * 1024
MAX_DOCX_COMPRESSION_RATIO = 500
MAX_UIA_PREVIEW_TEXT_CHARS = 200_000
RESUME_SKILL_TERMS = (
    "Python",
    "Java",
    "JavaScript",
    "TypeScript",
    "SQL",
    "Excel",
    "PowerPoint",
    "Photoshop",
    "Premiere",
    "Figma",
    "Axure",
    "AIGC",
    "大模型",
    "智能体",
    "数据分析",
    "内容策划",
    "文案",
    "运营",
    "视频剪辑",
    "小红书",
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _media_type(path: Path, prefix: bytes) -> str:
    extension = path.suffix.casefold()
    if extension == ".pdf" and prefix.startswith(PDF_MAGIC):
        return "application/pdf"
    if extension == ".docx" and prefix.startswith(ZIP_MAGIC):
        return (
            "application/vnd.openxmlformats-officedocument."
            "wordprocessingml.document"
        )
    raise UnsafeResume(
        f"附件扩展名与文件头不一致，或文件类型不受支持：{extension or '<none>'}"
    )


def _validate_docx_container(path: Path) -> None:
    try:
        with zipfile.ZipFile(path) as archive:
            infos = archive.infolist()
            if len(infos) > MAX_DOCX_ENTRIES:
                raise UnsafeResume("DOCX 文件条目异常过多，拒绝自动解析")
            total_uncompressed = sum(item.file_size for item in infos)
            if total_uncompressed > MAX_DOCX_UNCOMPRESSED_BYTES:
                raise UnsafeResume("DOCX 解压后体积异常，拒绝自动解析")
            for item in infos:
                if (
                    item.compress_size > 0
                    and item.file_size / item.compress_size
                    > MAX_DOCX_COMPRESSION_RATIO
                ):
                    raise UnsafeResume("DOCX 压缩比异常，拒绝自动解析")
            names = {item.filename.casefold() for item in infos}
            required = {"[content_types].xml", "word/document.xml"}
            missing = required - names
            if missing:
                raise UnsafeResume(
                    "DOCX 缺少必要结构：" + ", ".join(sorted(missing))
                )
            blocked_fragments = (
                "vbaproject.bin",
                "word/embeddings/",
                "word/activeX/".casefold(),
                "customui/",
                "externalLinks/".casefold(),
            )
            blocked = sorted(
                name
                for name in names
                if any(fragment.casefold() in name for fragment in blocked_fragments)
            )
            if blocked:
                raise UnsafeResume(
                    "DOCX 含宏、嵌入对象或外部链接结构，拒绝自动解析"
                )
            content_types = archive.read("[Content_Types].xml")
            if b"macroEnabled" in content_types:
                raise UnsafeResume("DOCX 声明了宏内容类型，拒绝自动解析")
            relation_files = [
                item.filename
                for item in infos
                if item.filename.casefold().endswith(".rels")
            ]
            for relation_file in relation_files:
                try:
                    root = ElementTree.fromstring(
                        archive.read(relation_file)
                    )
                except ElementTree.ParseError as exc:
                    raise UnsafeResume(
                        f"DOCX 关系文件损坏：{relation_file}"
                    ) from exc
                if any(
                    node.attrib.get("TargetMode", "").casefold()
                    == "external"
                    for node in root.iter()
                ):
                    raise UnsafeResume(
                        "DOCX 含外部关系链接，拒绝自动解析"
                    )
    except zipfile.BadZipFile as exc:
        raise UnsafeResume("DOCX 容器损坏") from exc


def validate_and_store_resume(
    source_path: str | Path,
    *,
    job_key: str,
    candidate_key: str,
    target_dir: str | Path,
    config: CandidatePipelineConfig = DEFAULT_CONFIG,
) -> ResumeArtifact:
    source = Path(source_path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    extension = source.suffix.casefold()
    if extension not in ALLOWED_EXTENSIONS:
        raise UnsafeResume(f"仅允许 PDF 或 DOCX 简历，实际为：{extension}")
    size = source.stat().st_size
    if size <= 0 or size > config.max_resume_bytes:
        raise UnsafeResume(
            f"简历大小不在安全范围内：{size} bytes"
        )
    with source.open("rb") as handle:
        prefix = handle.read(8)
    media_type = _media_type(source, prefix)
    if extension == ".docx":
        _validate_docx_container(source)
    sha256 = file_sha256(source)
    artifact_id = stable_hash(job_key, candidate_key, sha256)
    destination_dir = Path(target_dir).expanduser().resolve()
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / (
        f"{candidate_key[:20]}_{artifact_id[:12]}{extension}"
    )
    if not destination.exists():
        shutil.copy2(source, destination)
    elif file_sha256(destination) != sha256:
        raise UnsafeResume("目标位置存在同名但哈希不同的文件，拒绝覆盖")
    return ResumeArtifact(
        artifact_id=artifact_id,
        job_key=job_key,
        candidate_key=candidate_key,
        source_file_name=source.name,
        stored_path=str(destination),
        sha256=sha256,
        size_bytes=size,
        media_type=media_type,
        state=ResumeState.VALIDATED,
    )


def normalize_uia_preview_text(value: str) -> str:
    normalized = value.replace("\x00", "")
    normalized = re.sub(r"[ \t]+", " ", normalized)
    normalized = re.sub(r"\r\n?", "\n", normalized)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized).strip()
    if len(normalized) > MAX_UIA_PREVIEW_TEXT_CHARS:
        raise UnsafeResume(
            "UIA 简历预览文本超过安全字符上限，拒绝截断后误判"
        )
    return normalized


def store_uia_preview_resume(
    preview: ResumePreviewContent,
    *,
    target_dir: str | Path,
    config: CandidatePipelineConfig = DEFAULT_CONFIG,
) -> ResumeParseResult:
    """Persist already-extracted UIA preview text as inert UTF-8 text.

    This path never treats the attachment as PDF/DOCX bytes and never opens
    embedded content. The source extension is retained only as provenance.
    """

    extension = Path(preview.file_name).suffix.casefold()
    if extension not in ALLOWED_EXTENSIONS:
        raise UnsafeResume(
            f"UIA 预览仅接受 PDF/DOCX 附件来源，实际为：{extension or '<none>'}"
        )
    normalized = normalize_uia_preview_text(preview.text)
    if not normalized:
        raise ResumeParseError("UIA 简历预览未暴露可解析文本")
    payload = normalized.encode("utf-8")
    if len(payload) <= 0 or len(payload) > config.max_resume_bytes:
        raise UnsafeResume(
            f"UIA 简历预览文本大小不在安全范围内：{len(payload)} bytes"
        )
    text_hash = hashlib.sha256(payload).hexdigest()
    if preview.text_hash != text_hash or preview.size_bytes != len(payload):
        raise UnsafeResume("UIA 简历预览文本哈希或大小与适配器回执不一致")

    artifact_id = stable_hash(
        preview.candidate_ref.job_key,
        preview.candidate_ref.candidate_key,
        "boss-uia-preview",
        preview.file_name,
        text_hash,
    )
    destination_dir = Path(target_dir).expanduser().resolve()
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / (
        f"{preview.candidate_ref.candidate_key[:20]}_"
        f"{artifact_id[:12]}_uia-preview.txt"
    )
    if destination.exists():
        if file_sha256(destination) != text_hash:
            raise UnsafeResume(
                "UIA 预览文本目标存在同名但哈希不同的文件，拒绝覆盖"
            )
    else:
        file_descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{destination.name}.",
            suffix=".tmp",
            dir=str(destination_dir),
        )
        try:
            with os.fdopen(file_descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, destination)
        finally:
            try:
                Path(temporary_name).unlink(missing_ok=True)
            except OSError:
                pass

    non_whitespace = len(re.sub(r"\s+", "", normalized))
    quality = min(1.0, non_whitespace / 1500) if non_whitespace else 0.0
    artifact = ResumeArtifact(
        artifact_id=artifact_id,
        job_key=preview.candidate_ref.job_key,
        candidate_key=preview.candidate_ref.candidate_key,
        source_file_name=preview.file_name,
        stored_path=str(destination),
        sha256=text_hash,
        size_bytes=len(payload),
        media_type="text/plain; charset=utf-8; source=boss-uia-preview",
        state=ResumeState.PARSED,
        parse_quality=round(quality, 4),
        text_hash=text_hash,
        error=None,
    )
    return ResumeParseResult(
        artifact=artifact,
        text=normalized,
        page_count=None,
        warnings=("source:boss-uia-semantic-preview",),
        parse_quality=round(quality, 4),
    )


def _resolved(value: Any) -> Any:
    getter = getattr(value, "get_object", None)
    if callable(getter):
        try:
            return getter()
        except Exception:
            return value
    return value


def _validate_pdf_structure(reader: Any) -> None:
    root = _resolved(reader.trailer.get("/Root", {}))
    blocked_root_keys = {"/OpenAction", "/AA"}
    if any(root.get(key) is not None for key in blocked_root_keys):
        raise UnsafeResume("PDF 含自动动作，拒绝自动解析")
    names = _resolved(root.get("/Names", {}))
    if isinstance(names, dict) and (
        names.get("/JavaScript") is not None or names.get("/EmbeddedFiles") is not None
    ):
        raise UnsafeResume("PDF 含 JavaScript 或嵌入文件，拒绝自动解析")
    for page in reader.pages:
        page_object = _resolved(page)
        if page_object.get("/AA") is not None:
            raise UnsafeResume("PDF 页面含附加动作，拒绝自动解析")
        annotations = _resolved(page_object.get("/Annots", []))
        for annotation_ref in annotations or []:
            annotation = _resolved(annotation_ref)
            action = _resolved(annotation.get("/A", {}))
            if isinstance(action, dict) and action.get("/S") in {
                "/JavaScript",
                "/Launch",
                "/SubmitForm",
                "/ImportData",
            }:
                raise UnsafeResume("PDF 注释含可执行或外发动作，拒绝自动解析")


def _parse_pdf(path: Path) -> tuple[str, int, list[str]]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ResumeParseError("缺少 pypdf；请先运行 ensure_runtime.py") from exc
    try:
        reader = PdfReader(str(path), strict=False)
        if reader.is_encrypted:
            raise UnsafeResume("加密 PDF 无法安全自动解析")
        _validate_pdf_structure(reader)
        page_text: list[str] = []
        warnings: list[str] = []
        for index, page in enumerate(reader.pages):
            try:
                text = page.extract_text() or ""
            except Exception as exc:
                warnings.append(f"page_{index + 1}_extract_failed:{type(exc).__name__}")
                text = ""
            page_text.append(text)
        return "\n\n".join(page_text), len(reader.pages), warnings
    except UnsafeResume:
        raise
    except Exception as exc:
        raise ResumeParseError(f"PDF 解析失败：{type(exc).__name__}") from exc


def _docx_text_from_xml(payload: bytes) -> str:
    root = ElementTree.fromstring(payload)
    pieces: list[str] = []
    for paragraph in root.iter(f"{WORD_NAMESPACE}p"):
        runs = [
            node.text or ""
            for node in paragraph.iter(f"{WORD_NAMESPACE}t")
        ]
        text = "".join(runs).strip()
        if text:
            pieces.append(text)
    return "\n".join(pieces)


def _parse_docx(path: Path) -> tuple[str, None, list[str]]:
    _validate_docx_container(path)
    warnings: list[str] = []
    pieces: list[str] = []
    try:
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            targets = [
                name
                for name in names
                if name == "word/document.xml"
                or re.fullmatch(r"word/(header|footer)\d+\.xml", name)
            ]
            for target in targets:
                try:
                    pieces.append(_docx_text_from_xml(archive.read(target)))
                except ElementTree.ParseError:
                    warnings.append(f"xml_parse_failed:{target}")
    except zipfile.BadZipFile as exc:
        raise ResumeParseError("DOCX 解析失败：容器损坏") from exc
    return "\n\n".join(piece for piece in pieces if piece), None, warnings


def parse_resume(artifact: ResumeArtifact) -> ResumeParseResult:
    path = Path(artifact.stored_path)
    if not path.is_file():
        raise FileNotFoundError(path)
    if file_sha256(path) != artifact.sha256:
        raise UnsafeResume("简历文件哈希与入库记录不一致")
    if artifact.media_type == "application/pdf":
        text, page_count, warnings = _parse_pdf(path)
    elif artifact.media_type.endswith(
        "wordprocessingml.document"
    ):
        text, page_count, warnings = _parse_docx(path)
    else:
        raise UnsafeResume(f"不受支持的媒体类型：{artifact.media_type}")
    normalized = re.sub(r"[ \t]+", " ", text)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized).strip()
    normalized = normalized[:200_000]
    non_whitespace = len(re.sub(r"\s+", "", normalized))
    quality = min(1.0, non_whitespace / 1500) if non_whitespace else 0.0
    parsed_artifact = ResumeArtifact(
        **{
            **artifact.as_dict(),
            "state": ResumeState.PARSED,
            "parse_quality": round(quality, 4),
            "text_hash": hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
            "error": None,
        }
    )
    return ResumeParseResult(
        artifact=parsed_artifact,
        text=normalized,
        page_count=page_count,
        warnings=tuple(warnings),
        parse_quality=round(quality, 4),
    )


def _safe_resume_line(value: str) -> str:
    line = re.sub(r"\s+", " ", value).strip(" \t|｜")
    line = re.sub(
        r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b",
        "[邮箱已省略]",
        line,
    )
    line = re.sub(r"(?<!\d)1[3-9]\d{9}(?!\d)", "[手机号已省略]", line)
    line = re.sub(
        r"(?<!\d)\d{17}[\dXx](?!\d)",
        "[证件号已省略]",
        line,
    )
    return line[:240]


def profile_from_resume_text(
    text: str,
    *,
    text_hash: str | None = None,
    parse_quality: float | None = None,
) -> dict[str, Any]:
    """Extract bounded, job-related evidence without retaining resume full text."""

    lines: list[str] = []
    for raw in re.split(r"[\r\n]+", text):
        line = _safe_resume_line(raw)
        if len(line) < 2 or line in lines:
            continue
        lines.append(line)

    education = next(
        (
            line
            for level in ("博士", "硕士", "本科", "大专")
            for line in lines
            if level in line
        ),
        None,
    )
    education_context = [
        line
        for line in lines
        if any(marker in line for marker in ("大学", "学院", "专业"))
    ][:4]
    graduation = next(
        (
            line
            for line in lines
            if any(marker in line for marker in ("毕业时间", "毕业年份", "应届", "届毕业"))
        ),
        None,
    )
    availability = [
        line
        for line in lines
        if any(
            marker in line
            for marker in (
                "每周",
                "到岗",
                "实习时长",
                "可实习",
                "连续实习",
                "个月以上",
                "天出勤",
            )
        )
    ][:4]
    desired_role = next(
        (
            line
            for line in lines
            if any(marker in line for marker in ("求职意向", "期望职位", "目标岗位"))
        ),
        None,
    )
    experience = [
        line
        for line in lines
        if any(
            marker in line
            for marker in (
                "工作经历",
                "实习经历",
                "项目经历",
                "运营",
                "文案",
                "编辑",
                "策划",
                "设计",
                "产品",
                "客户成功",
                "数据分析",
            )
        )
    ][:8]
    folded_text = text.casefold()
    skills = [
        term
        for term in RESUME_SKILL_TERMS
        if term.casefold() in folded_text
    ][:12]
    resolved_hash = text_hash or hashlib.sha256(text.encode("utf-8")).hexdigest()
    profile: dict[str, Any] = {
        "education": education,
        "major": "；".join(education_context) or None,
        "graduation": graduation,
        "availability": "；".join(availability) or None,
        "desired_role": desired_role,
        "experience_summary": "；".join(experience) or None,
        "skills": skills,
        "_resume_text_hash": resolved_hash,
    }
    if parse_quality is not None:
        profile["resume_parse_quality"] = round(float(parse_quality), 4)
    return profile
