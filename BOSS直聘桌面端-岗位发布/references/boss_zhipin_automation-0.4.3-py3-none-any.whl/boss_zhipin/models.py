from __future__ import annotations

import hashlib
import json
import re
import secrets
import unicodedata
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Literal

from .catalogs import (
    EDUCATION_OPTIONS,
    RECRUITMENT_ALIASES,
    EducationLevel,
    ExperienceLevel,
    RecruitmentType,
    SalaryUnit,
)
from .errors import ValidationError


CONTACT_PATTERN = re.compile(
    r"(?i)(?:\b(?:qq|wechat|weixin|vx)\b|微信|联系(?:方式|电话)|"
    r"(?<!\d)(?:1[3-9]\d{9}|0\d{2,3}[-\s]?\d{7,8})(?!\d))"
)


def _clean_text(value: str) -> str:
    return unicodedata.normalize("NFKC", value).strip()


def _enum_value(value: StrEnum | str) -> str:
    return value.value if isinstance(value, StrEnum) else _clean_text(str(value))


def _contains_symbol_emoji(value: str) -> bool:
    return any(unicodedata.category(char) in {"So", "Cs"} for char in value)


@dataclass(frozen=True)
class SalarySpec:
    unit: SalaryUnit | str
    minimum: int
    maximum: int

    def normalized(self) -> "SalarySpec":
        try:
            unit = SalaryUnit(_enum_value(self.unit))
        except ValueError as exc:
            raise ValidationError(f"不支持的薪资单位：{self.unit}") from exc
        minimum = int(self.minimum)
        maximum = int(self.maximum)
        if minimum >= maximum:
            raise ValidationError("薪资下限必须小于薪资上限")
        if unit is SalaryUnit.DAILY_YUAN:
            if minimum not in range(10, 1001, 10) or maximum not in range(10, 1001, 10):
                raise ValidationError("实习日薪必须是 10 到 1000 之间的 10 元倍数")
        else:
            if not 1 <= minimum <= 100 or not 1 <= maximum <= 100:
                raise ValidationError("月薪必须以 K 为单位，范围为 1 到 100")
        return SalarySpec(unit=unit, minimum=minimum, maximum=maximum)


@dataclass(frozen=True)
class InternshipSpec:
    minimum_months: int
    days_per_week: int

    def normalized(self) -> "InternshipSpec":
        months = int(self.minimum_months)
        days = int(self.days_per_week)
        if not 1 <= months <= 12:
            raise ValidationError("最少实习月数必须在 1 到 12 之间")
        if not 1 <= days <= 7:
            raise ValidationError("每周到岗天数必须在 1 到 7 之间")
        return InternshipSpec(minimum_months=months, days_per_week=days)


@dataclass(frozen=True)
class AddressSpec:
    mode: Literal["account_default", "explicit"] = "account_default"
    value: str | None = None

    def normalized(self) -> "AddressSpec":
        mode = _clean_text(self.mode)
        if mode not in {"account_default", "explicit"}:
            raise ValidationError("地址模式必须是 account_default 或 explicit")
        value = _clean_text(self.value) if self.value else None
        if mode == "explicit" and not value:
            raise ValidationError("explicit 地址模式必须提供 value")
        if mode == "explicit":
            raise ValidationError(
                "当前实习生招聘 Skill 只使用账号已有地址；"
                "不支持新增、编辑或指定其他工作地址"
            )
        return AddressSpec(mode=mode, value=value)


@dataclass(frozen=True)
class JobPostSpec:
    recruitment_type: RecruitmentType | str
    title: str
    description: str
    education: EducationLevel | str
    salary: SalarySpec
    experience: ExperienceLevel | str | None = None
    internship: InternshipSpec | None = None
    address: AddressSpec = field(default_factory=AddressSpec)
    phone_exchange: bool | None = None
    expected_company: str | None = None

    def normalized(self) -> "JobPostSpec":
        raw_type = _enum_value(self.recruitment_type)
        if raw_type in RECRUITMENT_ALIASES:
            recruitment_type = RECRUITMENT_ALIASES[raw_type]
        else:
            try:
                recruitment_type = RecruitmentType(raw_type)
            except ValueError as exc:
                raise ValidationError(f"不支持的招聘类型：{raw_type}") from exc
        if recruitment_type is not RecruitmentType.INTERNSHIP:
            raise ValidationError(
                "当前技能只支持“实习生招聘”；"
                f"收到的招聘类型是“{recruitment_type.value}”"
            )

        title = _clean_text(self.title)
        description = self.description.replace("\r\n", "\n").strip()
        expected_company = _clean_text(self.expected_company) if self.expected_company else None
        if not 2 <= len(title) <= 20:
            raise ValidationError("职位名称长度必须在 2 到 20 个字符之间")
        if CONTACT_PATTERN.search(title) or _contains_symbol_emoji(title):
            raise ValidationError("职位名称不能包含联系方式、表情或特殊符号")
        if not 10 <= len(description) <= 5000:
            raise ValidationError("职位描述长度必须在 10 到 5000 个字符之间")
        if CONTACT_PATTERN.search(description):
            raise ValidationError("职位描述不能包含 QQ、微信或电话号码等联系方式")

        education_text = _enum_value(self.education)
        if education_text not in EDUCATION_OPTIONS:
            raise ValidationError(f"不支持的学历选项：{education_text}")
        education = EducationLevel(education_text)

        salary = self.salary.normalized()
        address = self.address.normalized()
        phone_exchange = self.phone_exchange
        if phone_exchange is not None and not isinstance(phone_exchange, bool):
            raise ValidationError("phone_exchange 必须为 true、false 或 null")

        if salary.unit is not SalaryUnit.DAILY_YUAN:
            raise ValidationError("实习职位薪资单位必须为 元/天")
        internship = self.internship.normalized() if self.internship else None
        if internship is None:
            raise ValidationError("实习职位必须提供 minimum_months 与 days_per_week")
        if self.experience is not None:
            experience_text = _enum_value(self.experience)
            if experience_text != ExperienceLevel.CAMPUS.value:
                raise ValidationError("实习生招聘的经验由平台固定为“在校/应届”")
        experience = ExperienceLevel.CAMPUS

        return JobPostSpec(
            recruitment_type=recruitment_type,
            title=title,
            description=description,
            education=education,
            salary=salary,
            experience=experience,
            internship=internship,
            address=address,
            phone_exchange=phone_exchange,
            expected_company=expected_company,
        )

    def canonical_dict(self) -> dict[str, Any]:
        normalized = self.normalized()
        data = asdict(normalized)
        data["recruitment_type"] = normalized.recruitment_type.value
        data["education"] = normalized.education.value
        data["experience"] = normalized.experience.value if normalized.experience else None
        data["salary"]["unit"] = normalized.salary.unit.value
        return data

    def spec_hash(self) -> str:
        payload = json.dumps(
            self.canonical_dict(),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "JobPostSpec":
        salary = data.get("salary")
        internship = data.get("internship")
        address = data.get("address") or {}
        if not isinstance(salary, dict):
            raise ValidationError("salary 必须是对象")
        return cls(
            recruitment_type=data.get("recruitment_type", ""),
            title=data.get("title", ""),
            description=data.get("description", ""),
            education=data.get("education", ""),
            experience=data.get("experience"),
            salary=SalarySpec(**salary),
            internship=InternshipSpec(**internship) if isinstance(internship, dict) else None,
            address=AddressSpec(**address),
            phone_exchange=data.get("phone_exchange"),
            expected_company=data.get("expected_company"),
        ).normalized()


@dataclass(frozen=True)
class PrepareOptions:
    restart_for_accessibility: bool = False
    maximize_window: bool = True
    timeout_seconds: float = 30.0
    artifact_dir: str | None = None


class RunStatus(StrEnum):
    NEW = "NEW"
    PREPARING = "PREPARING"
    REVIEW_READY = "REVIEW_READY"
    SUBMITTING = "SUBMITTING"
    SUCCEEDED = "SUCCEEDED"
    FAILED_SAFE = "FAILED_SAFE"
    COMMIT_UNKNOWN = "COMMIT_UNKNOWN"


@dataclass(frozen=True)
class FieldEvidence:
    field: str
    expected: str
    actual: str
    verified: bool


@dataclass(frozen=True)
class PreparedJob:
    run_id: str
    idempotency_key: str
    status: RunStatus
    spec_hash: str
    company: str | None
    evidence: tuple[FieldEvidence, ...]
    warnings: tuple[str, ...]
    confirmation_token: str
    confirmation_expires_at: str
    artifact_dir: str | None = None

    def as_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["status"] = self.status.value
        return result


@dataclass(frozen=True)
class PublishReceipt:
    run_id: str
    status: RunStatus
    title: str
    company: str | None
    verified: bool
    submitted_at: str | None
    message: str
    artifact_dir: str | None = None

    def as_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["status"] = self.status.value
        return result


@dataclass(frozen=True)
class EnvironmentReport:
    installed: bool
    running: bool
    executable: str | None
    version: str | None
    process_ids: tuple[int, ...]
    window_count: int
    semantic_accessibility: bool
    accessible_markers: tuple[str, ...]
    recommendation: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PublishFormReady:
    app_version: str | None
    ready: bool
    republish_clicked: bool
    elapsed_seconds: float
    artifact_dir: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def new_run_id() -> str:
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    return f"boss-{stamp}-{secrets.token_hex(4)}"
