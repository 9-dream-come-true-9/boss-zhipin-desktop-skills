from __future__ import annotations

import time
from collections.abc import Callable
from typing import TypeVar

from .errors import ErrorContext, WaitTimeout


T = TypeVar("T")


def wait_until(
    predicate: Callable[[], T],
    *,
    timeout: float,
    interval: float = 0.2,
    description: str,
    retryable: tuple[type[BaseException], ...] = (),
) -> T:
    deadline = time.monotonic() + timeout
    last_error: BaseException | None = None
    while True:
        try:
            result = predicate()
            if result:
                return result
        except retryable as exc:
            last_error = exc
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            details = {"last_error": repr(last_error)} if last_error else None
            raise WaitTimeout(
                f"等待超时：{description}",
                context=ErrorContext(step=description, details=details),
            ) from last_error
        time.sleep(min(interval, remaining))


def wait_for_change(
    reader: Callable[[], str],
    previous: str,
    *,
    timeout: float,
    interval: float = 0.2,
    description: str,
) -> str:
    return wait_until(
        lambda: (value if (value := reader()) != previous else ""),
        timeout=timeout,
        interval=interval,
        description=description,
    )

