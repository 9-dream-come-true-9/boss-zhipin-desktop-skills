from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _default_state_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA")
    if base:
        return Path(base) / "Codex" / "boss-job-publishing"
    return Path.cwd() / ".boss-job-publishing"


@dataclass(frozen=True)
class BossConfig:
    state_dir: Path = _default_state_dir()
    poll_interval_seconds: float = 0.2
    default_timeout_seconds: float = 30.0
    confirmation_ttl_seconds: int = 600
    supported_versions: tuple[str, ...] = ("1.7.4.963",)
    app_title: str = "BOSS直聘"
    process_name: str = "boss-zhipin.exe"

    def ensure_directories(self) -> None:
        (self.state_dir / "runs").mkdir(parents=True, exist_ok=True)
        (self.state_dir / "artifacts").mkdir(parents=True, exist_ok=True)


DEFAULT_CONFIG = BossConfig()
