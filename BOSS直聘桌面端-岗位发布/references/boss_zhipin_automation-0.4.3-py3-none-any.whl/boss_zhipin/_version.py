from __future__ import annotations


__version__ = "0.4.3"
RUNTIME_BUILD_ID = "boss-job-publishing-20260731-semantic-publish-v5"
