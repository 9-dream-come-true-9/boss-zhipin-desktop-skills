from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ErrorContext:
    step: str | None = None
    selector: str | None = None
    artifact_dir: str | None = None
    details: dict[str, Any] | None = None


class BossAutomationError(RuntimeError):
    """Base error with machine-readable context."""

    code = "BOSS_AUTOMATION_ERROR"

    def __init__(self, message: str, *, context: ErrorContext | None = None) -> None:
        super().__init__(message)
        self.context = context or ErrorContext()

    def as_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": str(self),
            "context": {
                "step": self.context.step,
                "selector": self.context.selector,
                "artifact_dir": self.context.artifact_dir,
                "details": self.context.details,
            },
        }


class ValidationError(BossAutomationError):
    code = "VALIDATION_ERROR"


class AppNotInstalled(BossAutomationError):
    code = "APP_NOT_INSTALLED"


class AppNotRunning(BossAutomationError):
    code = "APP_NOT_RUNNING"


class WindowNotFound(BossAutomationError):
    code = "WINDOW_NOT_FOUND"


class AmbiguousWindow(BossAutomationError):
    code = "AMBIGUOUS_WINDOW"


class NotLoggedIn(BossAutomationError):
    code = "NOT_LOGGED_IN"


class UnsupportedVersion(BossAutomationError):
    code = "UNSUPPORTED_VERSION"


class AccessibilityUnavailable(BossAutomationError):
    code = "ACCESSIBILITY_UNAVAILABLE"


class ElementNotFound(BossAutomationError):
    code = "ELEMENT_NOT_FOUND"


class AmbiguousElement(BossAutomationError):
    code = "AMBIGUOUS_ELEMENT"


class WaitTimeout(BossAutomationError):
    code = "WAIT_TIMEOUT"


class FocusLost(BossAutomationError):
    code = "FOCUS_LOST"


class ReadbackMismatch(BossAutomationError):
    code = "READBACK_MISMATCH"


class FormRejected(BossAutomationError):
    code = "FORM_REJECTED"


class RunNotFound(BossAutomationError):
    code = "RUN_NOT_FOUND"


class RunStateError(BossAutomationError):
    code = "RUN_STATE_ERROR"


class ConfirmationRequired(BossAutomationError):
    code = "CONFIRMATION_REQUIRED"


class ConfirmationInvalid(BossAutomationError):
    code = "CONFIRMATION_INVALID"


class PublishOutcomeUnknown(BossAutomationError):
    code = "PUBLISH_OUTCOME_UNKNOWN"


class PublishFailed(BossAutomationError):
    code = "PUBLISH_FAILED"

