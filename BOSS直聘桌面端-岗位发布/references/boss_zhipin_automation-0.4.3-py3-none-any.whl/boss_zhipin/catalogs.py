from __future__ import annotations

from enum import StrEnum


class RecruitmentType(StrEnum):
    SOCIAL_FULL_TIME = "社招全职"
    CAMPUS = "应届校园招聘"
    INTERNSHIP = "实习生招聘"
    PART_TIME = "兼职招聘"


class EducationLevel(StrEnum):
    UNLIMITED = "不限"
    JUNIOR_OR_BELOW = "初中及以下"
    SECONDARY = "中专/中技"
    HIGH_SCHOOL = "高中"
    COLLEGE = "大专"
    BACHELOR = "本科"
    MASTER = "硕士"
    DOCTOR = "博士"


class ExperienceLevel(StrEnum):
    UNLIMITED = "不限"
    WITHIN_ONE_YEAR = "1年以内"
    ONE_TO_THREE = "1-3年"
    THREE_TO_FIVE = "3-5年"
    FIVE_TO_TEN = "5-10年"
    TEN_PLUS = "10年以上"
    CAMPUS = "在校/应届"


class SalaryUnit(StrEnum):
    MONTHLY_K = "月薪K"
    DAILY_YUAN = "元/天"


RECRUITMENT_ALIASES: dict[str, RecruitmentType] = {
    "社招全职": RecruitmentType.SOCIAL_FULL_TIME,
    "社招": RecruitmentType.SOCIAL_FULL_TIME,
    "社会招聘": RecruitmentType.SOCIAL_FULL_TIME,
    "全职": RecruitmentType.SOCIAL_FULL_TIME,
    "应届校园招聘": RecruitmentType.CAMPUS,
    "校园招聘": RecruitmentType.CAMPUS,
    "校招": RecruitmentType.CAMPUS,
    "实习生招聘": RecruitmentType.INTERNSHIP,
    "实习": RecruitmentType.INTERNSHIP,
    "兼职招聘": RecruitmentType.PART_TIME,
    "兼职": RecruitmentType.PART_TIME,
}

EDUCATION_OPTIONS = tuple(item.value for item in EducationLevel)
EXPERIENCE_OPTIONS = tuple(item.value for item in ExperienceLevel if item is not ExperienceLevel.CAMPUS)
INTERNSHIP_MONTH_OPTIONS = tuple(f"{value}个月" for value in range(1, 13))
INTERNSHIP_DAY_OPTIONS = tuple(f"{value}天" for value in range(1, 8))
DAILY_SALARY_OPTIONS = tuple(str(value) for value in range(10, 1001, 10))
MONTHLY_SALARY_OPTIONS = tuple(f"{value}k" for value in range(1, 101))

