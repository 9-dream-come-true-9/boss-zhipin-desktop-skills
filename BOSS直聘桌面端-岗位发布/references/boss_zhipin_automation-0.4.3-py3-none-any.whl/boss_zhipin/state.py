from __future__ import annotations

import hashlib
import json
import os
import time
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterator

from .config import BossConfig, DEFAULT_CONFIG
from .errors import ErrorContext, RunNotFound, RunStateError


def utc_now_iso() -> str:
    return datetime.now(UTC).isoformat()


class RunStore:
    def __init__(self, config: BossConfig = DEFAULT_CONFIG) -> None:
        self.config = config
        self.config.ensure_directories()
        self.runs_dir = self.config.state_dir / "runs"
        self.lock_path = self.config.state_dir / "runs.lock"

    def _run_path(self, run_id: str) -> Path:
        safe = "".join(char for char in run_id if char.isalnum() or char in {"-", "_"})
        if safe != run_id or not safe:
            raise RunStateError("非法 run_id")
        return self.runs_dir / f"{safe}.json"

    @contextmanager
    def locked(self, timeout: float = 10.0) -> Iterator[None]:
        import msvcrt

        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.lock_path.open("a+b")
        try:
            if handle.tell() == 0:
                handle.write(b"\0")
                handle.flush()
            handle.seek(0)
            deadline = time.monotonic() + timeout
            while True:
                try:
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise RunStateError("等待 BOSS 自动化互斥锁超时")
                    time.sleep(0.1)
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        finally:
            handle.close()

    def load(self, run_id: str) -> dict[str, Any]:
        path = self._run_path(run_id)
        if not path.is_file():
            raise RunNotFound(
                f"找不到运行记录：{run_id}",
                context=ErrorContext(details={"run_id": run_id}),
            )
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise RunStateError(f"运行记录损坏：{path}") from exc

    def save(self, record: dict[str, Any]) -> None:
        run_id = str(record.get("run_id", ""))
        path = self._run_path(run_id)
        payload = dict(record)
        payload["updated_at"] = utc_now_iso()
        temporary = path.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        os.replace(temporary, path)

    def create(self, record: dict[str, Any]) -> None:
        path = self._run_path(str(record.get("run_id", "")))
        if path.exists():
            raise RunStateError(f"run_id 已存在：{record.get('run_id')}")
        payload = dict(record)
        payload.setdefault("created_at", utc_now_iso())
        self.save(payload)

    def find_by_idempotency(self, idempotency_key: str) -> dict[str, Any] | None:
        key_hash = hashlib.sha256(idempotency_key.encode("utf-8")).hexdigest()
        for path in sorted(self.runs_dir.glob("*.json"), reverse=True):
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if record.get("idempotency_hash") == key_hash:
                return record
        return None

