from __future__ import annotations

import hashlib
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .config import BossConfig, DEFAULT_CONFIG


PHONE_RE = re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)")


class Diagnostics:
    def __init__(
        self,
        run_id: str,
        *,
        requested_dir: str | None = None,
        config: BossConfig = DEFAULT_CONFIG,
    ) -> None:
        if requested_dir:
            self.directory = Path(requested_dir).expanduser().resolve() / run_id
        else:
            stamp = datetime.now(UTC).strftime("%Y%m%d")
            self.directory = config.state_dir / "artifacts" / stamp / run_id
        self.directory.mkdir(parents=True, exist_ok=True)
        self.log_path = self.directory / "events.jsonl"

    @staticmethod
    def redact(value: str) -> str:
        return PHONE_RE.sub(lambda match: f"{match.group(0)[:3]}****{match.group(0)[-4:]}", value)

    def event(self, event: str, **fields: Any) -> None:
        safe = {"time": datetime.now(UTC).isoformat(), "event": event}
        for key, value in fields.items():
            if key == "description":
                text = str(value)
                safe["description_length"] = len(text)
                safe["description_sha256"] = hashlib.sha256(text.encode("utf-8")).hexdigest()
            elif isinstance(value, str):
                safe[key] = self.redact(value)
            else:
                safe[key] = value
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(safe, ensure_ascii=False, sort_keys=True) + "\n")

    def capture(self, window: Any, label: str) -> None:
        safe_label = re.sub(r"[^a-zA-Z0-9_-]+", "-", label).strip("-") or "capture"
        try:
            image = window.capture_as_image()
            image.save(self.directory / f"{safe_label}.png")
        except Exception as exc:  # Diagnostics must not hide the primary error.
            self.event("diagnostic_capture_failed", label=label, error=repr(exc))
        try:
            lines: list[str] = []
            for index, control in enumerate(window.descendants()):
                try:
                    info = control.element_info
                    rect = control.rectangle()
                    name = str(control.window_text() or "")
                    if str(info.control_type or "") == "Edit" and len(name) > 120:
                        name = (
                            f"<redacted edit len={len(name)} "
                            f"sha256={hashlib.sha256(name.encode('utf-8')).hexdigest()}>"
                        )
                    lines.append(
                        "\t".join(
                            (
                                str(index),
                                str(info.control_type or ""),
                                self.redact(name),
                                f"auto_id={info.automation_id or ''}",
                                f"class={info.class_name or ''}",
                                f"rect={rect.left},{rect.top},{rect.right},{rect.bottom}",
                            )
                        )
                    )
                except Exception as exc:
                    lines.append(f"{index}\t<unreadable>\t{exc!r}")
            (self.directory / f"{safe_label}-uia.txt").write_text(
                "\n".join(lines),
                encoding="utf-8",
            )
        except Exception as exc:
            self.event("diagnostic_tree_failed", label=label, error=repr(exc))
