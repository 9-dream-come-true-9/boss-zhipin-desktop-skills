from __future__ import annotations

import importlib.util
import subprocess
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

from .config import BossConfig, DEFAULT_CONFIG
from .errors import (
    AccessibilityUnavailable,
    AmbiguousWindow,
    AppNotInstalled,
    AppNotRunning,
    ErrorContext,
    FocusLost,
    NotLoggedIn,
    UnsupportedVersion,
    WindowNotFound,
)
from .models import EnvironmentReport
from .uielements import (
    ACCESSIBILITY_PROBES,
    FORM_RECRUITMENT_LABEL,
    JOBS_NAV,
    LOGIN_PROBES,
    PUBLISH_JOB,
    REPUBLISH,
)
from .waits import wait_until


@lru_cache(maxsize=1)
def _import_runtime() -> tuple[Any, Any, Any]:
    missing = [
        name
        for name in ("pywinauto", "psutil", "win32api", "win32gui")
        if importlib.util.find_spec(name) is None
    ]
    if missing:
        raise AppNotInstalled(
            "缺少自动化运行依赖，请先运行技能内 scripts/ensure_runtime.py",
            context=ErrorContext(details={"missing_modules": missing}),
        )
    import psutil
    import win32api
    import win32gui

    return psutil, win32api, win32gui


def _file_version(executable: Path, win32api: Any) -> str | None:
    try:
        info = win32api.GetFileVersionInfo(str(executable), "\\")
        ms = info["FileVersionMS"]
        ls = info["FileVersionLS"]
        return ".".join(
            str(value)
            for value in (
                win32api.HIWORD(ms),
                win32api.LOWORD(ms),
                win32api.HIWORD(ls),
                win32api.LOWORD(ls),
            )
        )
    except Exception:
        return None


def _running_processes(process_name: str) -> list[Any]:
    psutil, _, _ = _import_runtime()
    try:
        current_user = (psutil.Process().username() or "").casefold()
    except Exception:
        current_user = ""
    result: list[Any] = []
    for process in psutil.process_iter(["pid", "name", "exe", "username"]):
        try:
            if (process.info.get("name") or "").casefold() != process_name.casefold():
                continue
            owner = (process.info.get("username") or "").casefold()
            if current_user and owner and owner != current_user:
                continue
            result.append(process)
        except (psutil.AccessDenied, psutil.NoSuchProcess):
            continue
    return result


def locate_executable(config: BossConfig = DEFAULT_CONFIG) -> Path:
    processes = _running_processes(config.process_name)
    for process in processes:
        try:
            value = process.exe()
        except Exception:
            value = None
        if value and Path(value).is_file():
            return Path(value)
    candidates = (
        Path(r"C:\Program Files (x86)\boss-zhipin\boss-zhipin.exe"),
        Path(r"C:\Program Files\boss-zhipin\boss-zhipin.exe"),
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise AppNotInstalled("未找到 BOSS 直聘桌面客户端")


def _desktop_windows(config: BossConfig, backend: str = "win32") -> list[Any]:
    from pywinauto import Desktop

    processes = _running_processes(config.process_name)
    pids = {process.pid for process in processes}
    windows: list[Any] = []
    for window in Desktop(backend=backend).windows(
        title=config.app_title,
        visible_only=True,
        enabled_only=False,
    ):
        try:
            if window.process_id() in pids:
                windows.append(window)
        except Exception:
            continue
    return windows


def _semantic_texts(handle: int) -> tuple[str, ...]:
    from pywinauto import Desktop

    window = Desktop(backend="uia").window(handle=handle)
    texts: list[str] = []
    for control in window.descendants():
        try:
            value = (control.window_text() or "").strip()
        except Exception:
            continue
        if value:
            texts.append(value)
    return tuple(texts)


def _direct_exists(
    handle: int,
    selector: dict[str, Any],
    *,
    timeout: float = 0.0,
) -> bool:
    from pywinauto import Desktop

    window = Desktop(backend="uia").window(handle=handle)
    return _window_direct_exists(window, selector, timeout=timeout)


def _window_fixed_element_infos(
    window: Any,
    selector: dict[str, Any],
) -> list[Any]:
    """Use native UIA property conditions instead of a client-side tree scan."""

    criteria = dict(selector)
    criteria.pop("found_index", None)
    auto_id = criteria.pop("auto_id", None)
    framework_id = criteria.pop("framework_id", None)
    allowed = {"title", "control_type", "class_name", "content_only"}
    unknown = set(criteria) - allowed
    if unknown:
        raise ValueError(f"unsupported fixed selector keys: {sorted(unknown)}")

    root = window.wrapper_object()
    infos = list(
        root.element_info.descendants(
            cache_enable=False,
            **criteria,
        )
    )
    if auto_id is not None:
        infos = [item for item in infos if item.automation_id == auto_id]
    if framework_id is not None:
        infos = [item for item in infos if item.framework_id == framework_id]
    return infos


def _window_direct_exists(
    window: Any,
    selector: dict[str, Any],
    *,
    timeout: float = 0.0,
) -> bool:
    del timeout
    try:
        return bool(_window_fixed_element_infos(window, selector))
    except Exception:
        return False


def _direct_markers(handle: int) -> tuple[str, ...]:
    from pywinauto import Desktop

    window = Desktop(backend="uia").window(handle=handle)
    return tuple(
        label
        for label, selector in ACCESSIBILITY_PROBES
        if _window_direct_exists(window, selector)
    )


def inspect_environment(config: BossConfig = DEFAULT_CONFIG) -> EnvironmentReport:
    try:
        executable = locate_executable(config)
        installed = True
    except AppNotInstalled:
        executable = None
        installed = False
    processes = _running_processes(config.process_name) if installed else []
    running = bool(processes)
    windows = _desktop_windows(config) if running else []
    semantic = False
    markers: tuple[str, ...] = ()
    if len(windows) == 1:
        try:
            markers = _direct_markers(windows[0].handle)
            semantic = bool(markers)
        except Exception:
            semantic = False
    version = None
    if executable:
        _, win32api, _ = _import_runtime()
        version = _file_version(executable, win32api)
    if not installed:
        recommendation = "安装 BOSS 直聘桌面客户端后重试。"
    elif not running:
        recommendation = "启动并登录 BOSS 直聘桌面客户端后重试。"
    elif len(windows) != 1:
        recommendation = "确保仅有一个可见的 BOSS 直聘主窗口。"
    elif not semantic:
        recommendation = (
            "尚未检测到当前版本的固定业务控件；先等待页面完成加载。"
            "若出现未发布职位提示，open_publish_form 会自动点击“重新发布”。"
        )
    else:
        recommendation = "环境可用于固定选择器 pywinauto 自动化。"
    return EnvironmentReport(
        installed=installed,
        running=running,
        executable=str(executable) if executable else None,
        version=version,
        process_ids=tuple(process.pid for process in processes),
        window_count=len(windows),
        semantic_accessibility=semantic,
        accessible_markers=markers,
        recommendation=recommendation,
    )


@dataclass
class BossSession:
    config: BossConfig = DEFAULT_CONFIG
    timeout: float | None = None
    maximize: bool = True
    restart_for_accessibility: bool = False
    window: Any | None = None
    handle: int | None = None
    executable: Path | None = None
    version: str | None = None

    @property
    def wait_timeout(self) -> float:
        return self.timeout or self.config.default_timeout_seconds

    def connect(self) -> "BossSession":
        self.executable = locate_executable(self.config)
        _, win32api, _ = _import_runtime()
        self.version = _file_version(self.executable, win32api)
        if self.version and self.version not in self.config.supported_versions:
            raise UnsupportedVersion(
                f"当前仅验证过 BOSS 版本 {self.config.supported_versions}，检测到 {self.version}",
                context=ErrorContext(details={"version": self.version}),
            )
        if not _running_processes(self.config.process_name):
            raise AppNotRunning("BOSS 直聘未运行，请先启动并登录客户端")
        self._attach_unique_window()
        if self.maximize:
            try:
                self.window.maximize()
            except Exception:
                self.window.restore()
        self.focus()
        try:
            semantic_ready = wait_until(
                self.has_semantic_accessibility,
                timeout=min(10.0, self.wait_timeout),
                interval=0.1,
                description="等待 BOSS 固定语义控件",
                retryable=(Exception,),
            )
        except Exception:
            semantic_ready = False
        if not semantic_ready:
            if self.restart_for_accessibility:
                self._restart_accessible()
            else:
                raise AccessibilityUnavailable(
                    "BOSS 当前未向 pywinauto 暴露职位页面控件",
                    context=ErrorContext(
                        step="accessibility_probe",
                        details={
                            "version": self.version,
                            "hint": "等待页面加载；未发布职位提示会由固定函数自动点击“重新发布”",
                        },
                    ),
                )
        self._assert_logged_in()
        return self

    def _attach_unique_window(self) -> None:
        # Discover the top-level HWND through win32 first.  Electron can
        # temporarily omit the window from the UIA desktop enumeration while
        # the same visible HWND remains valid and can be rebound to UIA.
        windows = _desktop_windows(self.config, backend="win32")
        if not windows:
            raise WindowNotFound("未找到可见的 BOSS 直聘主窗口")
        if len(windows) != 1:
            raise AmbiguousWindow(
                f"找到 {len(windows)} 个 BOSS 直聘窗口，无法安全选择",
                context=ErrorContext(details={"handles": [item.handle for item in windows]}),
            )
        self.handle = windows[0].handle
        from pywinauto import Desktop

        self.window = Desktop(backend="uia").window(handle=self.handle)

    def _selector_exists(
        self,
        selector: dict[str, Any],
        *,
        timeout: float = 0.0,
    ) -> bool:
        if self.window is None:
            return False
        return _window_direct_exists(self.window, selector, timeout=timeout)

    def find_fixed_controls(self, selector: dict[str, Any]) -> list[Any]:
        if self.window is None:
            raise WindowNotFound("BOSS 会话尚未连接")
        from pywinauto.controls.uiawrapper import UIAWrapper

        return [
            UIAWrapper(element_info)
            for element_info in _window_fixed_element_infos(self.window, selector)
        ]

    def has_semantic_accessibility(self) -> bool:
        if self.handle is None:
            return False
        return any(
            self._selector_exists(selector)
            for _, selector in ACCESSIBILITY_PROBES
        )

    def _restart_accessible(self) -> None:
        if self.window is None or self.executable is None:
            raise WindowNotFound("重启前没有可用的 BOSS 窗口")
        try:
            self.window.close()
        except Exception as exc:
            raise AccessibilityUnavailable("无法安全关闭 BOSS 以启用可访问性") from exc
        wait_until(
            lambda: not _running_processes(self.config.process_name),
            timeout=self.wait_timeout,
            interval=self.config.poll_interval_seconds,
            description="等待 BOSS 退出",
        )
        subprocess.Popen(
            [str(self.executable), "--force-renderer-accessibility"],
            cwd=str(self.executable.parent),
            close_fds=True,
        )
        wait_until(
            lambda: bool(_desktop_windows(self.config, backend="uia")),
            timeout=self.wait_timeout,
            interval=self.config.poll_interval_seconds,
            description="等待 BOSS 可访问窗口",
        )
        self._attach_unique_window()
        self.focus()
        wait_until(
            self.has_semantic_accessibility,
            timeout=self.wait_timeout,
            interval=self.config.poll_interval_seconds,
            description="等待 BOSS 语义控件",
        )

    def focus(self) -> None:
        if self.window is None or self.handle is None:
            raise WindowNotFound("没有可聚焦的 BOSS 窗口")
        _, _, win32gui = _import_runtime()
        if win32gui.GetForegroundWindow() == self.handle:
            return
        self.window.set_focus()
        try:
            wait_until(
                lambda: win32gui.GetForegroundWindow() == self.handle,
                timeout=min(5.0, self.wait_timeout),
                interval=0.1,
                description="等待 BOSS 获得前台焦点",
            )
        except Exception as exc:
            raise FocusLost("BOSS 窗口未获得焦点，已停止键盘操作") from exc

    def fresh_window(self) -> Any:
        if self.handle is None or self.window is None:
            raise WindowNotFound("BOSS 会话尚未连接")
        return self.window

    def texts(self) -> tuple[str, ...]:
        if self.handle is None:
            return ()
        return _semantic_texts(self.handle)

    def _assert_logged_in(self) -> None:
        if self.handle is None:
            raise NotLoggedIn("无法确认 BOSS 账号已登录")
        # A fixed logged-in marker is stronger evidence and avoids probing
        # every possible login-page label on the normal path.
        if not any(
            self._selector_exists(selector)
            for selector in (
                JOBS_NAV,
                PUBLISH_JOB,
                REPUBLISH,
                FORM_RECRUITMENT_LABEL,
            )
        ):
            if any(self._selector_exists(selector) for selector in LOGIN_PROBES):
                raise NotLoggedIn("BOSS 直聘当前停留在登录页，请先手动登录")
            raise NotLoggedIn("无法确认 BOSS 账号已登录")
